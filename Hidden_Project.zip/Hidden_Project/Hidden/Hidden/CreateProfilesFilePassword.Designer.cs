﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 12/20/2018
 * Time: 10:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class CreateProfilesFilePassword
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateProfilesFilePassword));
			this.panel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.password = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.confirm_password = new System.Windows.Forms.TextBox();
			this.lock_file = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FloralWhite;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.lock_file);
			this.panel1.Controls.Add(this.confirm_password);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.password);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(31, 32);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(419, 324);
			this.panel1.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(31, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(347, 65);
			this.label1.TabIndex = 0;
			this.label1.Text = "Set a password for your profiles file, if you happen to forget your password you " +
			"might not be able to open your file ever!";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FloralWhite;
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.panel2.Location = new System.Drawing.Point(31, 121);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(419, 14);
			this.panel2.TabIndex = 1;
			// 
			// password
			// 
			this.password.Location = new System.Drawing.Point(176, 147);
			this.password.Name = "password";
			this.password.Size = new System.Drawing.Size(202, 20);
			this.password.TabIndex = 1;
			this.password.UseSystemPasswordChar = true;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(31, 145);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Password";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(31, 198);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(137, 23);
			this.label3.TabIndex = 3;
			this.label3.Text = "Confirm password";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// confirm_password
			// 
			this.confirm_password.Location = new System.Drawing.Point(176, 200);
			this.confirm_password.Name = "confirm_password";
			this.confirm_password.Size = new System.Drawing.Size(202, 20);
			this.confirm_password.TabIndex = 4;
			this.confirm_password.UseSystemPasswordChar = true;
			// 
			// lock_file
			// 
			this.lock_file.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lock_file.Location = new System.Drawing.Point(250, 243);
			this.lock_file.Name = "lock_file";
			this.lock_file.Size = new System.Drawing.Size(128, 34);
			this.lock_file.TabIndex = 5;
			this.lock_file.Text = "Lock file";
			this.lock_file.UseVisualStyleBackColor = true;
			this.lock_file.Click += new System.EventHandler(this.Lock_fileClick);
			// 
			// CreateProfilesFilePassword
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.ClientSize = new System.Drawing.Size(482, 389);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "CreateProfilesFilePassword";
			this.Text = "Set password";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox confirm_password;
		private System.Windows.Forms.Button lock_file;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.TextBox password;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
	}
}
