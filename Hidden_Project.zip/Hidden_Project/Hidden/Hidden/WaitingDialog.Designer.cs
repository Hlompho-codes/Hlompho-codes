﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/19/2018
 * Time: 5:46 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class WaitingDialog
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WaitingDialog));
			this.ActionLabel = new System.Windows.Forms.Label();
			this.percentProgressLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// ActionLabel
			// 
			this.ActionLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F);
			this.ActionLabel.Location = new System.Drawing.Point(12, 37);
			this.ActionLabel.Name = "ActionLabel";
			this.ActionLabel.Size = new System.Drawing.Size(320, 23);
			this.ActionLabel.TabIndex = 1;
			this.ActionLabel.Text = "Action";
			this.ActionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// percentProgressLabel
			// 
			this.percentProgressLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.percentProgressLabel.Location = new System.Drawing.Point(12, 92);
			this.percentProgressLabel.Name = "percentProgressLabel";
			this.percentProgressLabel.Size = new System.Drawing.Size(320, 23);
			this.percentProgressLabel.TabIndex = 2;
			this.percentProgressLabel.Text = "Please wait...";
			this.percentProgressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// WaitingDialog
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(344, 143);
			this.ControlBox = false;
			this.Controls.Add(this.percentProgressLabel);
			this.Controls.Add(this.ActionLabel);
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "WaitingDialog";
			this.Text = "Wait";
			this.TopMost = true;
			this.Shown += new System.EventHandler(this.WaitingDialogShown);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label percentProgressLabel;
		public System.Windows.Forms.Label ActionLabel;
	}
}
