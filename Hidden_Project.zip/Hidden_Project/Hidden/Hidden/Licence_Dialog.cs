﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/24/2018
 * Time: 8:18 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Hidden
{
	/// <summary>
	/// Description of Licence_Dialog.
	/// </summary>
	public partial class Licence_Dialog : Form
	{
		public Licence_Dialog()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
