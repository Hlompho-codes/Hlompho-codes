﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/17/2018
 * Time: 12:13 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Threading;

namespace Hidden
{
	/// <summary>
	/// Description of Add_File_Dialog.
	/// </summary>
	public partial class Add_File_Dialog : Form
	{
		public Add_File_Dialog()
		{
			this.filepath = "";
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			Encrypted_Files_file = new Files("Hidden","20002000.bin");
			Encrypted_Files_file_db = new Database(Encrypted_Files_file.FilePath);
			
			childref = new ThreadStart(LockOutTimer);
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Child thread to lockout the user
		/// </summary>
		private ThreadStart childref;
		private Thread childThread;
		
		/// <summary>
		/// Lockout the user if not active
		/// </summary>
		private void LockOutTimer()
		{
			Thread.Sleep(60000);
			
			if(InvokeRequired)
			{
				
				Invoke(new MethodInvoker(CloseTheForm));
			}
			else
			{
				CloseTheForm();
			}
		}
				
		private void CloseTheForm()
		{
			Close();
		}
		
		Files Encrypted_Files_file;
		
		Database Encrypted_Files_file_db;
		/// <summary>
		/// The file path
		/// </summary>
		public string Filepath 
		{
			get { return filepath; }
			set { this.filepath = value; }
		}
		private string filepath;
		/// <summary>
		/// Adds a file to the database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_encryption_file_to_listClick(object sender, EventArgs e)
		{
			if(
				fileNameTextBox.Text.Equals("") ||
				filePathTextBox.Text.Equals("") 
			  )
			{
				return;
			}
			else if(Filepath.Equals(""))
			{
				Encrypted_Files_file_db.query("INSERT INTO encrypted VALUES ('"+fileNameTextBox.Text+"', '"+fileDescriptionTextBox.Text+"', '"+filePathTextBox.Text+"','decrypted')");	
			}
			else
			{
				Encrypted_Files_file_db.query("DELETE FROM encrypted WHERE path = '"+Filepath+"'");	
				Encrypted_Files_file_db.query("INSERT INTO encrypted VALUES ('"+fileNameTextBox.Text+"', '"+fileDescriptionTextBox.Text+"', '"+filePathTextBox.Text+"','decrypted')");	
			}
			Close();
		}
		
		/// <summary>
		/// Fill the forms with the when window load
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_File_DialogLoad(object sender, EventArgs e)
		{
			Text = "Edit File";
			SQLiteDataReader encrypted_files_reader = Encrypted_Files_file_db.fetch("SELECT * FROM encrypted WHERE path = '"+Filepath+"'");
			
			if(encrypted_files_reader.HasRows.Equals(false))
			{
				fileNameTextBox.Text = Path.GetFileName(Filepath);
				filePathTextBox.Text = Filepath;
			}
			
			while(encrypted_files_reader.Read())
			{
				fileNameTextBox.Text = fileNameTextBox.Text + encrypted_files_reader["name"];
				fileDescriptionTextBox.Text = fileDescriptionTextBox.Text + encrypted_files_reader["description"];
				filePathTextBox.Text = filePathTextBox.Text + encrypted_files_reader["path"];
			}
			encrypted_files_reader.Close();
		}
		
		/// <summary>
		/// Closes the connection to the database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_File_DialogFormClosed(object sender, FormClosedEventArgs e)
		{
			Encrypted_Files_file_db.Close();
			childThread.Abort();
		}
	}
}
