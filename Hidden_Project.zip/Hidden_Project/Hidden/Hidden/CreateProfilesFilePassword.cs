﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 12/20/2018
 * Time: 10:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace Hidden
{
	/// <summary>
	/// Description of CreateProfilesFilePassword.
	/// </summary>
	public partial class CreateProfilesFilePassword : Form
	{
		public CreateProfilesFilePassword()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			childref = new ThreadStart(LockOutTimer);
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Child thread to lockout the user
		/// </summary>
		private ThreadStart childref;
		private Thread childThread;
		
		/// <summary>
		/// Lockout the user if not active
		/// </summary>
		private void LockOutTimer()
		{
			Thread.Sleep(60000);
			
			if(InvokeRequired)
			{
				
				Invoke(new MethodInvoker(CloseTheForm));
			}
			else
			{
				CloseTheForm();
			}
		}
				
		private void CloseTheForm()
		{
			Close();
		}
				
		private string userPassword;
		
		/// <summary>
		/// Users profile file password
		/// </summary>
		public string UserPassword 
		{
			get { return userPassword; }
			set { this.userPassword = value; }
		}
		
		/// <summary>
		/// Locks the file with a password
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Lock_fileClick(object sender, EventArgs e)
		{
			if(password.Text.Equals(confirm_password.Text))
			{
				UserPassword = password.Text;
			}
			else
			{
				MessageBox.Show("The password and the password confirmation do not match!");
			}
			Close();
			childThread.Abort();
		}
	}
}
