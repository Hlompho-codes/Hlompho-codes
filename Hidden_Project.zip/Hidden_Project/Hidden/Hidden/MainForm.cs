﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 2/23/2018
 * Time: 11:48 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.IO;
using System.Windows.Forms;
using System.Threading;
using System.Security.Principal;

namespace Hidden
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm(String TheFile)
		{
			this.my_temp_profiles_file = TheFile;
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			if(!(TheFile.Equals("")))
			{
				Profiles_Open_Cmd_Line(TheFile);
			}
		}
		private string my_temp_profiles_file;
		
		public string My_temp_profiles_file 
		{
			get { return my_temp_profiles_file; }
			set { this.my_temp_profiles_file = value; }
		}
		
		private string user_password = "";
		
		/// <summary>
		/// Open the folder browser dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void AddHiddenFolderToolStripMenuItemClick(object sender, EventArgs e)
		{
			//Select a folder to be added to the list	
			folderBrowserDialog.ShowDialog();
			
			childThread.Abort();
			
			//Open the add folder dialog
			Add_Iterm_Dialog item = new Add_Iterm_Dialog();
			item.FolderPath = folderBrowserDialog.SelectedPath;
			item.ShowDialog();
			
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Open the file browser dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void AddEncryptedFileToolStripMenuItemClick(object sender, EventArgs e)
		{
			//Select a file to be added to the list
			openFileDialog.ShowDialog();
			
			childThread.Abort();
			
			//Open the add file dialog
			Add_File_Dialog add_file = new Add_File_Dialog();
			add_file.Filepath = openFileDialog.FileName;
			add_file.ShowDialog();
			
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Open the add profile dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void AddProfileToolStripMenuItemClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			Add_Profile_Dialog add_profile = new Add_Profile_Dialog();
			add_profile.Profile = "";
			add_profile.ShowDialog();
			
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Close the application
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ExitToolStripMenuItemClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
		
		/// <summary>
		/// Display about dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void HelpToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Hidden 1.0.0.0\nCopyright by Hlompho Sebolao\nEmail : seblao.hlompho@gmail.com","Credits");
		}
		
		/// <summary>
		/// Display the Help dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void HelpToolStripMenuItem1Click(object sender, EventArgs e)
		{
			Help_Info_Dialog help = new Help_Info_Dialog();
			help.ShowDialog();
		}
		
		/// <summary>
		/// Display the licence dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void LicenceToolStripMenuItemClick(object sender, EventArgs e)
		{
			Licence_Dialog licence = new Licence_Dialog();
			licence.ShowDialog();
		}
		
		/// <summary>
		/// Direct the user to Hidden Pro download page
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ProVersionToolStripMenuItemClick(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://hidden-app.000webhostapp.com/");
		}
		
		/// <summary>
		/// Download the Hidden Android app
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void AndriodAppToolStripMenuItemClick(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://hidden-app.000webhostapp.com/");
		}
		
		/// <summary>
		/// Edit hidden folders
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void CloudBackupToolStripMenuItemClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			try
			{
				Add_Iterm_Dialog add_item_dialog = new Add_Iterm_Dialog();
				add_item_dialog.FolderPath = listView1.SelectedItems[0].SubItems[3].Text;
				add_item_dialog.Show(this);
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Before cliking on this item, please select a folder from the list");
			}
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
		}
		
		/// <summary>
		/// Edit encrypted files
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void LostFolderRecoveryToolStripMenuItemClick(object sender, EventArgs e)
		{
			Encrypted_files_listSelectedIndexChanged(sender, e);
		}
		
		/// <summary>
		/// Edit profiles
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void LostFileRecoveryToolStripMenuItemClick(object sender, EventArgs e)
		{
			Profiles_edit_buttonClick(sender, e);
		}
		
		/// <summary>
		/// Opens a profiles file from the users storage medium
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void OpenProfilesFileToolStripMenuItemClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			openFileDialog.ShowDialog();
			
			Profiles_file.FilePath = openFileDialog.FileName;
			
			if(Profiles_file.FilePath.Equals(""))
			{return;}
			
			UnlockProfilesFile password = new UnlockProfilesFile();
			password.ShowDialog();
			
			Database Profiles_database_file = new Database(Profiles_file.FilePath,password.UserPassword);
			
			user_password = password.UserPassword;
			
			String sql = "SELECT * FROM profiles";
			
			SQLiteDataReader folderReader = Profiles_database_file.fetch(sql);
			
			profiles_list_View.Items.Clear();
			
			while(folderReader.Read())
			{
				profiles_list_View.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["service"].ToString(),
							folderReader["username"].ToString(),
							folderReader["password"].ToString(),
							folderReader["id"].ToString()
						}
					)
				);
			}
			Profiles_database_file.Close();
			
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Opening profiles file from file Eplorer
		/// </summary>
		/// <param name="NewPath"></param>
		public void Profiles_Open_Cmd_Line(string path)
		{
			try
			{
				Profiles_file.FilePath = path;
				
				UnlockProfilesFile password = new UnlockProfilesFile();
				password.ShowDialog();
				
				user_password = password.UserPassword;
				
				Database Profiles_database_file = new Database(Profiles_file.FilePath,password.UserPassword);
				
				String sql = "SELECT * FROM profiles";
				
				SQLiteDataReader folderReader = Profiles_database_file.fetch(sql);
				
				profiles_list_View.Items.Clear();
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				Profiles_database_file.Close();
			}
			catch(Exception)
			{
				MessageBox.Show("The provided password does not work");
			}
		}
		
		/// <summary>
		/// When the user drops a profiles database file here
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Profiles_list_ViewDragEnter(object sender, DragEventArgs e)
		{
			DragDropEffects effects = DragDropEffects.None;
			if(e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string path = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
				
				if(File.Exists(path))
				{
					effects = DragDropEffects.Copy;
					
					childThread.Abort();
					
					Profiles_file.FilePath = path;
					
					UnlockProfilesFile password = new UnlockProfilesFile();
					password.ShowDialog();
					
					user_password = password.UserPassword;
					
					Database Profiles_database_file = new Database(Profiles_file.FilePath,password.UserPassword);
					
					String sql = "SELECT * FROM profiles";
					
					SQLiteDataReader folderReader = Profiles_database_file.fetch(sql);
					
					profiles_list_View.Items.Clear();
					
					while(folderReader.Read())
					{
						profiles_list_View.Items.Add(
							new ListViewItem(
								new string[]
								{
									folderReader["service"].ToString(),
									folderReader["username"].ToString(),
									folderReader["password"].ToString(),
									folderReader["id"].ToString()
								}
							)
						);
					}
					Profiles_database_file.Close();
					
					childThread = new Thread(childref);
					childThread.Start();
					stopwatch.Restart();
				}
				e.Effect = effects;
			}
		}
		
		/// <summary>
		/// Saves the profiles to a database file 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Save_profile_to_fileClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			saveFileDialog1.ShowDialog();
			
			if(File.Exists(saveFileDialog1.FileName))
			{
				File.Delete(saveFileDialog1.FileName);
			}
			
			Profiles_file.FilePath = saveFileDialog1.FileName;
			Database Profiles_database_file = new Database(Profiles_file.FilePath);
				
			Profiles_database_file.query("CREATE TABLE profiles (id INTEGER PRIMARY KEY AUTOINCREMENT, service VARCHAR(255), username VARCHAR(255), password VARCHAR(255))");

			for(int a = 0; a < profiles_list_View.Items.Count ;a++)
			{
				Profiles_database_file.query("INSERT INTO profiles (service,username,password) " +
				                             "VALUES ('"+profiles_list_View.Items[a].SubItems[0].Text+"', " +
				                             "'"+profiles_list_View.Items[a].SubItems[1].Text+"', " +
				                             "'"+profiles_list_View.Items[a].SubItems[2].Text+"')");
			}
			
			CreateProfilesFilePassword password = new CreateProfilesFilePassword();
			password.ShowDialog();
			
			Profiles_database_file.Lock(password.UserPassword);
			Profiles_database_file.Close();
			
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Checks if the user is running the program with Admin previlages 
		/// </summary>
		/// <returns>boolean</returns>
		public bool CheckAdminRole()
		{
			using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
			{
				WindowsPrincipal principal = new WindowsPrincipal(identity);
				
				return(principal.IsInRole(WindowsBuiltInRole.Administrator));
			}
		}
		
		/// <summary>
		/// Block all usb ports 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Block_usbClick(object sender, EventArgs e)
		{
			if(!CheckAdminRole())
			{
				MessageBox.Show("You have to run this software as Administrator for this feature to work, " +  
				                "Do that by right clicking on Hidden.exe or Hidden.ink, " +
				                "Then click 'Run as administrator' from the menu");
				return;
			}
			
			Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR","Start",4,
			                                  Microsoft.Win32.RegistryValueKind.DWord);
			USB_Status.Text = "USB Storage is disabled";
			
			Database USB_DB = new Database(USB_file.FilePath);
			SQLiteDataReader db_reader = USB_DB.fetch("SELECT * FROM status");
			
			USB_DB.query("DELETE FROM status");
			USB_DB.query("INSERT INTO STATUS(status_text) VALUES(\"USB Storage is disabled\")");
			
			db_reader.Close();
		}
		
		/// <summary>
		/// Unblock all the closed ports
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Unblock_usbClick(object sender, EventArgs e)
		{
			if(!CheckAdminRole())
			{
				MessageBox.Show("You have to run this software as Administrator for this feature to work, " +  
				                "Do that by right clicking on Hidden.exe or Hidden.ink, " +
				                "Then click 'Run as administrator' from the menu");
				return;
			}
			
			Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR","Start",3,
			                                  Microsoft.Win32.RegistryValueKind.DWord);
			USB_Status.Text = "USB Storage is enabled";
			
			
			Database USB_DB = new Database(USB_file.FilePath);
			SQLiteDataReader db_reader = USB_DB.fetch("SELECT * FROM status");
			
			USB_DB.query("DELETE FROM status");
			USB_DB.query("INSERT INTO STATUS(status_text) VALUES(\"USB Storage is enabled\")");
			
			db_reader.Close();
		}
		
		/// <summary>
		/// Reads a file then save its contents to the system database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ExportProfilesFileToolStripMenuItemClick(object sender, EventArgs e)
		{
			Save_profile_to_fileClick(sender,e);
		}
		
		/// <summary>
		/// Reads a file then save its contents to the system database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>		
		void ImportProfilesFileToolStripMenuItemClick(object sender, EventArgs e)
		{
			Files P_file = new Files("Hidden","2000400.bin");
			
			if(!(Profiles_file.FilePath.Equals(P_file.FilePath)))
			{
				Profiles_file.FilePath = P_file.FilePath;
					
				Database Profiles_database_file = new Database(Profiles_file.FilePath);
				
				int loop = 0;
				
				for(int a = 0; a < profiles_list_View.Items.Count ;a++)
				{
					Profiles_database_file.query("INSERT INTO profiles (service,username,password) " +
					                             "VALUES ('"+profiles_list_View.Items[a].SubItems[0].Text+"', " +
					                             "'"+profiles_list_View.Items[a].SubItems[1].Text+"', " +
					                             "'"+profiles_list_View.Items[a].SubItems[2].Text+"')");
					
					loop = a;
				}
				
				String sql = "SELECT * FROM profiles";
				SQLiteDataReader folderReader = Profiles_database_file.fetch(sql);
				
				profiles_list_View.Items.Clear();
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				Profiles_database_file.Close();
					
				MessageBox.Show(loop+" : items exported successfully");
			}
			
		}
		
		/// <summary>
		/// Reads a file then save its contents to the system database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>		
		void Import_profiles_fileClick(object sender, EventArgs e)
		{
			ImportProfilesFileToolStripMenuItemClick(sender,e);
		}
		
		/// <summary>
		/// Remove all the profiles from the list
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Remove_allClick(object sender, EventArgs e)
		{
			Files Profiles_file_temp = new Files("Hidden","2000400.bin");
			
			Database database1;
			
			if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
			{
				database1 = new Database(Profiles_file.FilePath,user_password);
			}
			else
			{
				database1 = new Database(Profiles_file.FilePath);
			}
			
			try
			{
				database1.query("DELETE FROM profiles");
				
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM profiles");
				profiles_list_View.Items.Clear();
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				database1.Close();		
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a profile for this operation","Error");
			}					
		}
	}
}
