﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 9/26/2018
 * Time: 8:45 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System.Data.Sql;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Hidden
{
	partial class UpdatePasswordControl
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdatePasswordControl));
			this.UpdatePasswordPanel = new System.Windows.Forms.Panel();
			this.SavePasswordButton = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.ClearButton = new System.Windows.Forms.Button();
			this.NewPasswordHintBox = new System.Windows.Forms.RichTextBox();
			this.ConfirmNewPasswordLabel = new System.Windows.Forms.Label();
			this.NewPasswordLabel = new System.Windows.Forms.Label();
			this.ConfirmNewPasswordBox = new System.Windows.Forms.TextBox();
			this.NewPasswordBox = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.OldPasswordBox = new System.Windows.Forms.TextBox();
			this.UpdatePasswordLabel = new System.Windows.Forms.Label();
			this.UpdatePasswordPanel.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// UpdatePasswordPanel
			// 
			this.UpdatePasswordPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("UpdatePasswordPanel.BackgroundImage")));
			this.UpdatePasswordPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.UpdatePasswordPanel.Controls.Add(this.SavePasswordButton);
			this.UpdatePasswordPanel.Controls.Add(this.groupBox2);
			this.UpdatePasswordPanel.Controls.Add(this.groupBox1);
			this.UpdatePasswordPanel.Controls.Add(this.UpdatePasswordLabel);
			this.UpdatePasswordPanel.Location = new System.Drawing.Point(-3, 1);
			this.UpdatePasswordPanel.Name = "UpdatePasswordPanel";
			this.UpdatePasswordPanel.Size = new System.Drawing.Size(724, 493);
			this.UpdatePasswordPanel.TabIndex = 7;
			// 
			// SavePasswordButton
			// 
			this.SavePasswordButton.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.SavePasswordButton.FlatAppearance.BorderSize = 10;
			this.SavePasswordButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.SavePasswordButton.Location = new System.Drawing.Point(138, 427);
			this.SavePasswordButton.Name = "SavePasswordButton";
			this.SavePasswordButton.Size = new System.Drawing.Size(147, 23);
			this.SavePasswordButton.TabIndex = 4;
			this.SavePasswordButton.Text = "Save password";
			this.SavePasswordButton.UseVisualStyleBackColor = true;
			this.SavePasswordButton.Click += new System.EventHandler(this.SavePasswordButtonClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.ClearButton);
			this.groupBox2.Controls.Add(this.NewPasswordHintBox);
			this.groupBox2.Controls.Add(this.ConfirmNewPasswordLabel);
			this.groupBox2.Controls.Add(this.NewPasswordLabel);
			this.groupBox2.Controls.Add(this.ConfirmNewPasswordBox);
			this.groupBox2.Controls.Add(this.NewPasswordBox);
			this.groupBox2.Location = new System.Drawing.Point(138, 183);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(438, 220);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "New Password";
			// 
			// ClearButton
			// 
			this.ClearButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearButton.BackgroundImage")));
			this.ClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ClearButton.Location = new System.Drawing.Point(394, 117);
			this.ClearButton.Name = "ClearButton";
			this.ClearButton.Size = new System.Drawing.Size(38, 33);
			this.ClearButton.TabIndex = 5;
			this.ClearButton.UseVisualStyleBackColor = true;
			this.ClearButton.Click += new System.EventHandler(this.ClearButtonClick);
			// 
			// NewPasswordHintBox
			// 
			this.NewPasswordHintBox.Location = new System.Drawing.Point(6, 117);
			this.NewPasswordHintBox.Name = "NewPasswordHintBox";
			this.NewPasswordHintBox.Size = new System.Drawing.Size(382, 85);
			this.NewPasswordHintBox.TabIndex = 4;
			this.NewPasswordHintBox.Text = "Pasword hint (type any information that could remind you the password)";
			// 
			// ConfirmNewPasswordLabel
			// 
			this.ConfirmNewPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ConfirmNewPasswordLabel.Location = new System.Drawing.Point(6, 78);
			this.ConfirmNewPasswordLabel.Name = "ConfirmNewPasswordLabel";
			this.ConfirmNewPasswordLabel.Size = new System.Drawing.Size(141, 23);
			this.ConfirmNewPasswordLabel.TabIndex = 3;
			this.ConfirmNewPasswordLabel.Text = "Confirm password";
			// 
			// NewPasswordLabel
			// 
			this.NewPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NewPasswordLabel.Location = new System.Drawing.Point(11, 26);
			this.NewPasswordLabel.Name = "NewPasswordLabel";
			this.NewPasswordLabel.Size = new System.Drawing.Size(100, 23);
			this.NewPasswordLabel.TabIndex = 2;
			this.NewPasswordLabel.Text = "New password";
			this.NewPasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ConfirmNewPasswordBox
			// 
			this.ConfirmNewPasswordBox.Location = new System.Drawing.Point(164, 78);
			this.ConfirmNewPasswordBox.Name = "ConfirmNewPasswordBox";
			this.ConfirmNewPasswordBox.Size = new System.Drawing.Size(268, 20);
			this.ConfirmNewPasswordBox.TabIndex = 1;
			this.ConfirmNewPasswordBox.UseSystemPasswordChar = true;
			// 
			// NewPasswordBox
			// 
			this.NewPasswordBox.Location = new System.Drawing.Point(164, 26);
			this.NewPasswordBox.Name = "NewPasswordBox";
			this.NewPasswordBox.Size = new System.Drawing.Size(268, 20);
			this.NewPasswordBox.TabIndex = 0;
			this.NewPasswordBox.UseSystemPasswordChar = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.OldPasswordBox);
			this.groupBox1.Location = new System.Drawing.Point(138, 82);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(438, 53);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Old Password";
			// 
			// OldPasswordBox
			// 
			this.OldPasswordBox.Location = new System.Drawing.Point(6, 19);
			this.OldPasswordBox.Name = "OldPasswordBox";
			this.OldPasswordBox.Size = new System.Drawing.Size(426, 20);
			this.OldPasswordBox.TabIndex = 1;
			this.OldPasswordBox.UseSystemPasswordChar = true;
			// 
			// UpdatePasswordLabel
			// 
			this.UpdatePasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.UpdatePasswordLabel.Location = new System.Drawing.Point(226, 24);
			this.UpdatePasswordLabel.Name = "UpdatePasswordLabel";
			this.UpdatePasswordLabel.Size = new System.Drawing.Size(251, 31);
			this.UpdatePasswordLabel.TabIndex = 0;
			this.UpdatePasswordLabel.Text = "Update Your Password";
			// 
			// UpdatePasswordControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FloralWhite;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.ClientSize = new System.Drawing.Size(720, 494);
			this.Controls.Add(this.UpdatePasswordPanel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "UpdatePasswordControl";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Update Password";
			this.UpdatePasswordPanel.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label UpdatePasswordLabel;
		private System.Windows.Forms.TextBox OldPasswordBox;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox NewPasswordBox;
		private System.Windows.Forms.TextBox ConfirmNewPasswordBox;
		private System.Windows.Forms.Label NewPasswordLabel;
		private System.Windows.Forms.Label ConfirmNewPasswordLabel;
		private System.Windows.Forms.RichTextBox NewPasswordHintBox;
		private System.Windows.Forms.Button ClearButton;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button SavePasswordButton;
		private System.Windows.Forms.Panel UpdatePasswordPanel;
		
		/**
		 * The database file that will hold the user profile information.
		 * The file name is supposed to be 'Password.sqlite' but for
		 * security puposes it shall be named '2000100.bin'
		 */
		Files Password_file = new Files("Hidden","2000100.bin");
		
		public string folder_path;
		
		public string Folder_path 
		{
			get { return folder_path; }
			set { this.folder_path = value; }
		}
		
		void ClearButtonClick(object sender, System.EventArgs e)
		{
			NewPasswordHintBox.Text = "";
		}
		
		void SavePasswordButtonClick(object sender, System.EventArgs e)
		{
			/**
			 * Check if the user has typed in the new password
			 */
			if(NewPasswordBox.Text.Equals(""))
			{
				MessageBox.Show("Please type your new password","Error");
				return;
			}
			
			/**
			 * Check if the user has typed in the password confirmation
			 */
			if(ConfirmNewPasswordBox.Text.Equals(""))
			{
				MessageBox.Show("Please confirm your new password","Error");
				return;
			}
			
			if(!NewPasswordBox.Text.Equals(ConfirmNewPasswordBox.Text.ToString()))
			{
				MessageBox.Show("The password and password confirmation do not match","Error");
				return;
			}
						
			/**
			 * Check if the user has put in a password hint
			 */
			if
			(
				NewPasswordHintBox.Text.Equals("") || 
				NewPasswordHintBox.Text.Equals("Pasword hint (type any information that could remind you the password)")
			)
			{
				MessageBox.Show("Please type password hint to remind you in case you forget","Error");
				return;
			}
			
			Files Encrypted_Files_file = new Files("Hidden","20002000.bin");
			Database database1 = new Database(Encrypted_Files_file.FilePath);

			SQLiteDataReader db1reader = database1.fetch("SELECT * FROM encrypted");
			bool found_encrypt = false;
			while(db1reader.Read())
			{
				if(db1reader["status"].ToString().Equals("encrypted"))
				{
					found_encrypt = true;
				}
			}
			
			if(found_encrypt)
			{
				MessageBox.Show("You have files that are encrypted, please decrypt all your files, then you can change your password","Warning",
					                   MessageBoxButtons.OK,MessageBoxIcon.Warning,
					                   MessageBoxDefaultButton.Button1,MessageBoxOptions.RightAlign,false);
				return;
			}
			
			//Create a password db file
			Database Password_file_db = new Database(Password_file.FilePath);
			
			string stringBuild = "";
			SQLiteDataReader reader =  Password_file_db.fetch("SELECT * FROM password WHERE password = \""+OldPasswordBox.Text.ToString()+"\"");
			while(reader.Read())
			{
				stringBuild = stringBuild + "Password : " + reader["password"].ToString() + " Hint : " + reader["hint"].ToString() +"\n";
			}
			
			if(stringBuild.Equals(""))
			{
				MessageBox.Show("The old password that you have provided is not recognised");
				return;
			}
			
			//Read information from the database
			Password_file_db.query("DELETE FROM password");
			Password_file_db.query("INSERT INTO password VALUES(\""+NewPasswordBox.Text+"\",\""+NewPasswordHintBox.Text+"\")");
			Password_file_db.Close();

			this.Close();
		}
	}
}
