﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/24/2018
 * Time: 7:55 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class Help_Info_Dialog
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Help_Info_Dialog));
			this.help_text = new System.Windows.Forms.Label();
			this.help_link = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// help_text
			// 
			this.help_text.Location = new System.Drawing.Point(12, 9);
			this.help_text.Name = "help_text";
			this.help_text.Size = new System.Drawing.Size(416, 88);
			this.help_text.TabIndex = 0;
			this.help_text.Text = resources.GetString("help_text.Text");
			// 
			// help_link
			// 
			this.help_link.Cursor = System.Windows.Forms.Cursors.Hand;
			this.help_link.Font = new System.Drawing.Font("Arial Narrow", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.help_link.ForeColor = System.Drawing.Color.RoyalBlue;
			this.help_link.Location = new System.Drawing.Point(12, 97);
			this.help_link.Name = "help_link";
			this.help_link.Size = new System.Drawing.Size(415, 29);
			this.help_link.TabIndex = 1;
			this.help_link.Text = "Click here for the help pdf";
			this.help_link.Click += new System.EventHandler(this.Help_linkClick);
			// 
			// Help_Info_Dialog
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.ClientSize = new System.Drawing.Size(430, 203);
			this.Controls.Add(this.help_link);
			this.Controls.Add(this.help_text);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Help_Info_Dialog";
			this.Text = "Read me";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label help_link;
		private System.Windows.Forms.Label help_text;
	}
}
