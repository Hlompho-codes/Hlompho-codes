﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/8/2018
 * Time: 7:19 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Hidden
{
	/// <summary>
	/// Description of MyListControl.
	/// </summary>
	public partial class MyListControl : UserControl
	{
		
		public MyListControl()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
