﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/19/2018
 * Time: 5:46 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Hidden
{
	/// <summary>
	/// Description of WaitingDialog.
	/// </summary>
	public partial class WaitingDialog : Form
	{
		public WaitingDialog()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			ActionLabel.Text = ActionText;
						
		}
		
		/// <summary>
		/// Tell the user if they are either encrypting or decrypting
		/// </summary>
		public string ActionText 
		{
			get { return actionText; }
			set { this.actionText = value; }
		}
		public string Path 
		{
			get { return path; }
			set { path = value; }
		}
		public string Filename 
		{
			get { return filename; }
			set { filename = value; }
		}
		public string Password 
		{
			get { return password; }
			set { password = value; }
		}
		private string actionText;
		private string path;
		private string filename;
		private string password;	
		
		/// <summary>
		/// Start working here
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void WaitingDialogShown(object sender, EventArgs e)
		{
			try
			{
				if(ActionLabel.Text.Equals("Encrypting"))
				{
					/*************** Run a commannd to run the file encryptor program now *******************/
					System.Diagnostics.Process process = new System.Diagnostics.Process();
					System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
					startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
					startInfo.FileName = "aescrypt.exe";
					startInfo.Arguments = "-e -p \""+Password+"\" \""+Path+"\"";
					process.StartInfo = startInfo;
					process.Start();
					
					while(!process.HasExited){}
					/********************************* Delete the unencrypted file now ***********************/
					File.Delete(Path);
					
					/********************************* Move the encrypted file to new destination ************/
					Files files = new Files("Hidden\\Encrypted",Filename+".aes");
					File.Move(Path+".aes",files.FilePath);
					
					/*****************************************************************************************/
				}
				else if(ActionLabel.Text.Equals("Decrypting"))
				{
					/********************************* Move the encrypted file to new destination ************/
					Files files = new Files("Hidden\\Encrypted",Filename+".aes");
					File.Move(files.FilePath,Path+".aes");
					
					/*************** Run a commannd to run the file decryptor program now *******************/
					System.Diagnostics.Process process = new System.Diagnostics.Process();
					System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
					startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
					startInfo.FileName = "aescrypt.exe";
					startInfo.Arguments = "-d -p \""+Password+"\" \""+Path+".aes\"";
					process.StartInfo = startInfo;
					process.Start();
					
					while(!process.HasExited){}
					
					/********************************* Delete the unencrypted file now ***********************/
					File.Delete(Path+".aes");
					/*****************************************************************************************/
				}
				
			}
			catch(FileNotFoundException fne)
			{
				MessageBox.Show(fne.Message);
			}
			Close();
		}
	}
}
