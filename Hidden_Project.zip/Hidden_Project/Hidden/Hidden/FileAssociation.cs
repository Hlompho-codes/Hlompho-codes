﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 1/21/2019
 * Time: 1:59 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Hidden
{
	/// <summary>
	/// FileAssociation class helps the user associate the file extension ".hddn" with Hidden.exe
	/// </summary>
	public class FileAssociation
	{
		private string filePath;
		
		public string FilePath 
		{
			get { return filePath; }
		}
		
		public FileAssociation()
		{
			
			
			string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
			
			if(appDataPath.Equals(""))
			{
				appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
			}
			
            string dataPath = Path.Combine(appDataPath, "Hidden");

            this.filePath = "";
            filePath = Path.Combine(dataPath, "Hidden.exe");
			//SetAssociation(".hidden","Hidden_Profiles_File",Application.ExecutablePath,"Hidden Profiles File");
		}
		
		public static void SetAssociation(string Extension, string KeyName, string OpenWith, string FileDescription)
		{
			RegistryKey BaseKey;
			RegistryKey OpenMethod;
			RegistryKey Shell;
			RegistryKey CurrentUser;
			
			BaseKey = Registry.ClassesRoot.CreateSubKey(Extension);
			BaseKey.SetValue("",KeyName);
			
			OpenMethod = Registry.ClassesRoot.CreateSubKey(KeyName);
			OpenMethod.SetValue("", FileDescription);
			OpenMethod.CreateSubKey("DefaultIcon").SetValue("", "\"" + OpenWith + "\",0");
				
			Shell = OpenMethod.CreateSubKey("Shell");
			Shell.CreateSubKey("edit").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
			Shell.CreateSubKey("open").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");	
			
			BaseKey.Close();
			OpenMethod.Close();
			Shell.Close();
			
			//CurrentUser = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\" + Extension);
			//CurrentUser = CurrentUser.OpenSubKey("UserChoice", RegistryKeyPermissionCheck.ReadWriteSubTree, System.Security.AccessControl.RegistryRights.FullControl);
			//CurrentUser.SetValue("Progid", KeyName, RegistryValueKind.String);
			
			CurrentUser = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\" + Extension, true);
			CurrentUser.DeleteSubKey("UserChoice",false);
			CurrentUser.Close();
			
			SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
		}
		
		[DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
	}
}
