﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 3/22/2018
 * Time: 8:28 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Hidden
{
	/// <summary>
	/// Description of Visibility.
	/// </summary>
	public class Visibility
	{
		public String Folder;
		
		public Visibility(String folder)
		{
			this.Folder = folder;
		}
		
		/// <summary>
		/// Makes a hidden folder visible 
		/// </summary>
		/// <param name="file"></param>
		public static void Show(String folder)
		{
			System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/K attrib -s -h \"" + folder + ".\"";
            process.StartInfo = startInfo;
            process.Start();
		}
		
		/// <summary>
		/// Makes a visible folder hidden
		/// </summary>
		/// <param name="folder"></param>
		public static void Hide(String folder)
		{
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/K attrib +s +h \"" + folder + ".\"";
            process.StartInfo = startInfo;
            process.Start();		
		}
	}
}
