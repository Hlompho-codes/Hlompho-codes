﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/17/2018
 * Time: 12:13 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class Add_File_Dialog
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_File_Dialog));
			this.panel1 = new System.Windows.Forms.Panel();
			this.add_encryption_file_to_list = new System.Windows.Forms.Button();
			this.filePathTextBox = new System.Windows.Forms.RichTextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.fileDescriptionTextBox = new System.Windows.Forms.RichTextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.fileNameTextBox = new System.Windows.Forms.RichTextBox();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FloralWhite;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.add_encryption_file_to_list);
			this.panel1.Controls.Add(this.filePathTextBox);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.fileDescriptionTextBox);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.fileNameTextBox);
			this.panel1.Location = new System.Drawing.Point(41, 39);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(449, 387);
			this.panel1.TabIndex = 0;
			// 
			// add_encryption_file_to_list
			// 
			this.add_encryption_file_to_list.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.add_encryption_file_to_list.FlatAppearance.BorderSize = 5;
			this.add_encryption_file_to_list.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.add_encryption_file_to_list.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.add_encryption_file_to_list.Location = new System.Drawing.Point(115, 339);
			this.add_encryption_file_to_list.Name = "add_encryption_file_to_list";
			this.add_encryption_file_to_list.Size = new System.Drawing.Size(114, 33);
			this.add_encryption_file_to_list.TabIndex = 6;
			this.add_encryption_file_to_list.Text = "Save file";
			this.add_encryption_file_to_list.UseVisualStyleBackColor = true;
			this.add_encryption_file_to_list.Click += new System.EventHandler(this.Add_encryption_file_to_listClick);
			// 
			// filePathTextBox
			// 
			this.filePathTextBox.Location = new System.Drawing.Point(115, 241);
			this.filePathTextBox.Name = "filePathTextBox";
			this.filePathTextBox.Size = new System.Drawing.Size(310, 60);
			this.filePathTextBox.TabIndex = 5;
			this.filePathTextBox.Text = "";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(9, 241);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 60);
			this.label3.TabIndex = 4;
			this.label3.Text = "Path";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// fileDescriptionTextBox
			// 
			this.fileDescriptionTextBox.Location = new System.Drawing.Point(115, 120);
			this.fileDescriptionTextBox.Name = "fileDescriptionTextBox";
			this.fileDescriptionTextBox.Size = new System.Drawing.Size(310, 90);
			this.fileDescriptionTextBox.TabIndex = 3;
			this.fileDescriptionTextBox.Text = "";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(4, 120);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(105, 42);
			this.label2.TabIndex = 2;
			this.label2.Text = "Description";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(4, 37);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(105, 37);
			this.label1.TabIndex = 1;
			this.label1.Text = "File name";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// fileNameTextBox
			// 
			this.fileNameTextBox.Location = new System.Drawing.Point(115, 37);
			this.fileNameTextBox.Name = "fileNameTextBox";
			this.fileNameTextBox.Size = new System.Drawing.Size(310, 37);
			this.fileNameTextBox.TabIndex = 0;
			this.fileNameTextBox.Text = "";
			// 
			// Add_File_Dialog
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.ClientSize = new System.Drawing.Size(539, 472);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Add_File_Dialog";
			this.Text = "Add Files";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Add_File_DialogFormClosed);
			this.Load += new System.EventHandler(this.Add_File_DialogLoad);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.RichTextBox filePathTextBox;
		private System.Windows.Forms.Button add_encryption_file_to_list;
		private System.Windows.Forms.RichTextBox fileNameTextBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.RichTextBox fileDescriptionTextBox;
		private System.Windows.Forms.Panel panel1;
	}
}
