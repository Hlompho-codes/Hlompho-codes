﻿using System.Windows.Forms;
/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/8/2018
 * Time: 7:19 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class MyListControl
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the control.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{	
			this.seperator = new System.Windows.Forms.Panel();
			this.details = new System.Windows.Forms.Panel();
			this.statusLabel = new System.Windows.Forms.Label();
			this.pathLabel = new System.Windows.Forms.Label();
			this.contentsTextBox = new System.Windows.Forms.RichTextBox();
			this.item_name = new System.Windows.Forms.Label();
			this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
			this.details.SuspendLayout();
			this.SuspendLayout();
			// 
			// seperator
			// 
			this.seperator.BackColor = System.Drawing.Color.LightBlue;
			this.seperator.Location = new System.Drawing.Point(0, 0);
			this.seperator.Name = "seperator";
			this.seperator.Size = new System.Drawing.Size(909, 10);
			this.seperator.TabIndex = 1;
			// 
			// details
			// 
			this.details.BackColor = System.Drawing.Color.GhostWhite;
			this.details.Controls.Add(this.statusLabel);
			this.details.Controls.Add(this.pathLabel);
			this.details.Controls.Add(this.contentsTextBox);
			this.details.Controls.Add(this.item_name);
			this.details.Controls.Add(this.seperator);
			this.details.Location = new System.Drawing.Point(-1, 139);
			this.details.Name = "details";
			this.details.Size = new System.Drawing.Size(909, 186);
			this.details.TabIndex = 3;
			// 
			// statusLabel
			// 
			this.statusLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.statusLabel.Location = new System.Drawing.Point(753, 58);
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(152, 23);
			this.statusLabel.TabIndex = 5;
			this.statusLabel.Text = "status : ";
			this.statusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pathLabel
			// 
			this.pathLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pathLabel.Location = new System.Drawing.Point(16, 132);
			this.pathLabel.Name = "pathLabel";
			this.pathLabel.Size = new System.Drawing.Size(889, 23);
			this.pathLabel.TabIndex = 4;
			this.pathLabel.Text = "path";
			this.pathLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// contentsTextBox
			// 
			this.contentsTextBox.BackColor = System.Drawing.Color.GhostWhite;
			this.contentsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.contentsTextBox.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.contentsTextBox.Location = new System.Drawing.Point(16, 58);
			this.contentsTextBox.Name = "contentsTextBox";
			this.contentsTextBox.Size = new System.Drawing.Size(731, 62);
			this.contentsTextBox.TabIndex = 3;
			this.contentsTextBox.Text = "contents";
			// 
			// item_name
			// 
			this.item_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.item_name.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.item_name.Location = new System.Drawing.Point(16, 17);
			this.item_name.Name = "item_name";
			this.item_name.Size = new System.Drawing.Size(889, 29);
			this.item_name.TabIndex = 2;
			this.item_name.Text = "item name";
			this.item_name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// vScrollBar1
			// 
			this.vScrollBar1.Location = new System.Drawing.Point(890, 0);
			this.vScrollBar1.Name = "vScrollBar1";
			this.vScrollBar1.Size = new System.Drawing.Size(17, 136);
			this.vScrollBar1.TabIndex = 4;
			this.vScrollBar1.ValueChanged += new System.EventHandler(this.VScrollBar1ValueChanged);
			// 
			// MyListControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.vScrollBar1);
			this.Controls.Add(this.details);
			this.Name = "MyListControl";
			this.Size = new System.Drawing.Size(907, 324);
			this.details.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.RichTextBox contentsTextBox;
		private System.Windows.Forms.Label statusLabel;
		private System.Windows.Forms.Label item_name;
		private System.Windows.Forms.Label pathLabel;
		private System.Windows.Forms.VScrollBar vScrollBar1;
		private System.Windows.Forms.Panel details;
		private System.Windows.Forms.Panel seperator;

		/// <summary>
		/// Move the items up as you scroll
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void VScrollBar1ValueChanged(object sender, System.EventArgs e)
		{
			MessageBox.Show(vScrollBar1.Bounds.Y.ToString());
		}
	}
	
	/// <summary>
	/// Each item that is painted on the control is created here
	/// </summary>
	public class Item : Panel
	{
		public Item()
		{
			this.item_back.SuspendLayout();
			this.item_text_label = new System.Windows.Forms.Label();
			// 
			// item_border
			// 
			this.BackColor = System.Drawing.Color.LightBlue;
			this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Controls.Add(this.item_back);
			this.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.Location = new System.Drawing.Point(22, (Y + 17));
			this.Name = "item_border";
			this.Size = new System.Drawing.Size(854, 42);
			this.TabIndex = 0;
			// 
			// item_back
			// 
			this.item_back.BackColor = System.Drawing.Color.White;
			this.item_back.Controls.Add(this.item_text_label);
			this.item_back.Location = new System.Drawing.Point(3, 3);
			this.item_back.Name = "item_back";
			this.item_back.Size = new System.Drawing.Size(844, 31);
			this.item_back.TabIndex = 0;
			// 
			// item_text_label
			// 
			this.item_text_label.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.item_text_label.Location = new System.Drawing.Point(0, 0);
			this.item_text_label.Name = this.Name;
			this.item_text_label.Size = new System.Drawing.Size(806, 31);
			this.item_text_label.TabIndex = 0;
			this.item_text_label.Text = this.Name;
			this.item_text_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.ResumeLayout(false);
			this.item_back.ResumeLayout(false);
		}
		private System.Windows.Forms.Panel item_back;
		private System.Windows.Forms.Label item_text_label;	
		
		private string contents;
		private string name;
		private string status;
		private string path;
		private int x,y;
		
		public string Contents 
		{
			get { return contents; }
			set { contents = value; }
		}
		
		
		public string Status 
		{
			get { return status; }
			set { status = value; }
		}
		
		
		public string Path 
		{
			get { return path; }
		}
		
		
		public string Name 
		{
			get { return name; }
			set { name = value; }
		}
				
		public int Y
		{
			get { return y; }
			set { y = value; }
		}
		
		public int X 
		{
			get { return x; }
			set { x = value; }
		}
	}
}
