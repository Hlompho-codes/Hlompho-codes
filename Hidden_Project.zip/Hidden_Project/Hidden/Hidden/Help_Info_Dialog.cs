﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/24/2018
 * Time: 7:55 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Hidden
{
	/// <summary>
	/// Description of Help_Info_Dialog.
	/// </summary>
	public partial class Help_Info_Dialog : Form
	{
		public Help_Info_Dialog()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			help_text.Text = "After signing in, Drag and drop a folder on the app to add a folder to the list\n\n" +
			                 "Then click refresh button to refresh the list of folders that as been added to the app\n\n" +
			                 "If you have any folders on the list, double click the folder that you wish to open to open it";
		}
		
		/// <summary>
		/// Open the help pdf
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Help_linkClick(object sender, EventArgs e)
		{
			try
			{
				System.Diagnostics.Process.Start("Help_english.pdf");
			}
			catch(System.ComponentModel.Win32Exception)
			{
				MessageBox.Show("File not found! You may have deleted it, Reinstall this program, to create a new one");
			}
		}
	}
}
