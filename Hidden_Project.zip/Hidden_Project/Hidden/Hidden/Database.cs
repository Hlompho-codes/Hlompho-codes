﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 3/22/2018
 * Time: 8:25 PM
 */
using System;
using System.Data.SQLite;
using System.IO;
using System.Windows.Forms;

namespace Hidden
{

    /** 
     * Wrapper for sqlite library to make it easy to use the library
     */
    public class Database
    {
        /**
         * determines the affected rows on each query
         */
        private int affected_rows;

        /**
         * The SQLite connection object
         */
        private SQLiteConnection m_dbConnection;

        /**
         * Accessor for the affected rows
         */
        public int Affected_rows
        {
            get { return this.affected_rows; }
            set { affected_rows = value; }
        }
        
        /// <summary>
        /// Initialises the database and opens it
        /// </summary>
        /// <param name="database_file">The file name of the database</param>
        public Database(String database_file)
        {
            try
            {
            	if(!File.Exists(database_file))
            	{
                    SQLiteConnection.CreateFile(database_file);
            	}
            	SQLiteConnection.ClearAllPools();
				m_dbConnection = new SQLiteConnection("Data Source=" + database_file + ";Version=3;");
                m_dbConnection.Open();
            }
            catch (SQLiteException sqlite)
            {
                MessageBox.Show(sqlite.Message);
            }
        }

        /// <summary>
        /// Opens the database with a password
        /// </summary>
        /// <param name="database_file"></param>
        /// <param name="password"></param>
        public Database(String database_file, string password)
        {
            try
            {
            	if(!File.Exists(database_file))
            	{
                    SQLiteConnection.CreateFile(database_file);
            	}
            	SQLiteConnection.ClearAllPools();
				m_dbConnection = new SQLiteConnection("Data Source=" + database_file + ";Version=3;");
				m_dbConnection.SetPassword(password);
                m_dbConnection.Open();
            }
            catch (SQLiteException sqlite)
            {
                MessageBox.Show(sqlite.Message);
            }
        }
                
        /// <summary>
        /// Locks the database file with a password
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public void Lock(string password)
        {
        	m_dbConnection.ChangePassword(password);
        }
        
        /// <summary>
        /// Unlocks a password protected file
        /// </summary>
        /// <param name="password"></param>
        public void Unlock(string password)
        {
        	m_dbConnection.SetPassword(password);
        }
        
        /// <summary>
        /// Excecutes a query without the results
        /// </summary>
        /// <param name="query">SQL query</param>
        /// <returns>the number of rows affected</returns>
        public int query(string query)
        {
            try
            { 
                SQLiteCommand command = new SQLiteCommand(query, m_dbConnection);
                Affected_rows = command.ExecuteNonQuery();
            }
            catch (SQLiteException sqlite)
            {
                MessageBox.Show(sqlite.Message);
            }
            catch(InvalidOperationException IOE)
            {
            	MessageBox.Show(IOE.Message);
            }
            return (Affected_rows);
        }
 
        /// <summary>
        /// Excecutes a query an returns a results set
        /// </summary>
        /// <param name="query">SQL query</param>
        /// <returns>the array of the results fetched</returns>
        public SQLiteDataReader fetch(string query)
        {
        	SQLiteCommand command = new SQLiteCommand(query, m_dbConnection);
            try
            {
                SQLiteDataReader reader = command.ExecuteReader();
                return(reader);
            }
            catch (SQLiteException sqlite)
            {
                MessageBox.Show(sqlite.Message);
            }
            catch(InvalidOperationException)
            {
            	MessageBox.Show("The password that you have provided is not valid!");
            }
            return(null);
        }

        /// <summary>
        /// Closes the connection to the database
        /// </summary>
        public void Close()
        {
        	m_dbConnection.Close();
        }
        
        /**
         * Closes the sqlite connection
         */
        ~Database()
        {
            m_dbConnection.Close();
        }
    }

}
