﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 9/22/2018
 * Time: 8:09 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Threading;

namespace Hidden
{
	/// <summary>
	/// Description of Add_Iterm_Dialog.
	/// </summary>
	public partial class Add_Iterm_Dialog : Form
	{
		public Add_Iterm_Dialog()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			childref = new ThreadStart(LockOutTimer);
			childThread = new Thread(childref);
			childThread.Start();
		}
		

		/// <summary>
		/// Child thread to lockout the user
		/// </summary>
		private ThreadStart childref;
		private Thread childThread;
		
		/// <summary>
		/// Lockout the user if not active
		/// </summary>
		private void LockOutTimer()
		{
			Thread.Sleep(60000);
			
			if(InvokeRequired)
			{
				
				Invoke(new MethodInvoker(CloseTheForm));
			}
			else
			{
				CloseTheForm();
			}
		}
				
		private void CloseTheForm()
		{
			Close();
		}
		
		/**
		 * The database file that will hold the hidden files
		 * The file name is supposed to be 'Hidden_Files.sqlite ' but for
		 * security purposes it shall be named 2000300.bin
		 */
		Files Hidden_Files_file = new Files("Hidden","2000300.bin");
		
		void Save_buttonClick(object sender, EventArgs e)
		{
			Database Hidden_Files_file_db = new Database(Hidden_Files_file.FilePath);
			
			if(!file_or_folder_contents.Text.Equals(""))
			{
				Hidden_Files_file_db.query("DELETE FROM folder WHERE path = '"+this.FolderPath+"'");
			}
			
			Hidden_Files_file_db.query("INSERT INTO folder VALUES ('"+file_or_folder_name.Text+"', '"+file_or_folder_contents.Text+"', '"+file_or_folder_path.Text+"','visible')");
			Hidden_Files_file_db.Close();
			
			this.Close();
			childThread.Abort();
		}

		private string folderpath;
		
		public string FolderPath
		{
			get { return folderpath; }
			set { folderpath = value; }
		}
		private string save_what;
		
		public string Save_what {
			get { return save_what; }
			set { save_what = value; }
		}
		
		/// <summary>
		/// Creating a form or window
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_Iterm_DialogLoad(object sender, EventArgs e)
		{
			file_or_folder_name.Text = Path.GetFileName(this.FolderPath);
			file_or_folder_path.Text = this.FolderPath;
			
			Database Hidden_Files_file_db = new Database(Hidden_Files_file.FilePath);
			
			SQLiteDataReader reader = Hidden_Files_file_db.fetch("SELECT contents FROM folder WHERE path = '"+this.FolderPath+"'");
			while(reader.Read())
			{
				file_or_folder_contents.Text = reader["contents"].ToString();
			}
			
			Hidden_Files_file_db.Close();
		}
	}
}
