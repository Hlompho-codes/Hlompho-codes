﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 9/19/2018
 * Time: 7:25 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Security.AccessControl;
using System.Windows.Forms;

namespace Hidden
{
	/// <summary>
	/// Description of Class1.
	/// </summary>
	public class Files
	{
		private String filePath = "";
		
		private String folderPath = "";
		
		public string FilePath 
		{
			get { return filePath; }
			set {this.filePath = value;}
		}
		
		private String FolderPath
		{
			get { return(folderPath); }
			set { this.folderPath = value; }
		}
		
		public Files(string folder, String file_name)
		{
			//Saves a new password
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

            string dataPath = Path.Combine(appDataPath, folder);

            string database_file = Path.Combine(dataPath, file_name);

            if (!Directory.Exists(dataPath))
            {
                Directory.CreateDirectory(dataPath);
            }
            
            this.FolderPath = dataPath;
			this.FilePath = database_file;
		}
		
		/// <summary>
		/// Encrypts a file
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public static bool Encrypt(string path)
		{
			return(true);
		}
		
		/// <summary>
		/// Decrypts a file
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public static bool Decrypt(string path)
		{
			return(true);			
		}
		
		/// <summary>
		/// Checks whether the file exits or not
		/// </summary>
		/// <returns></returns>
		public bool Exist()
		{
			return(System.IO.File.Exists(this.FilePath));
		}
	}
}
