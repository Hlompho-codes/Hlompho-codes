﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 9/26/2018
 * Time: 8:45 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Hidden
{
	/// <summary>
	/// Description of UpdatePasswordControl.
	/// </summary>
	public partial class UpdatePasswordControl : Form
	{
		public UpdatePasswordControl()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
