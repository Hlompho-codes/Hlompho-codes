﻿using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data.Sql;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.AccessControl;
using System.Windows.Forms;
using System.Threading;

/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 2/23/2018
 * Time: 11:48 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Hidden
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{	
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.passwordPanel1 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.Button10 = new System.Windows.Forms.Button();
			this.NewPasswordHint = new System.Windows.Forms.RichTextBox();
			this.ConfirmNewPassword = new System.Windows.Forms.TextBox();
			this.NewPassword = new System.Windows.Forms.TextBox();
			this.Login = new System.Windows.Forms.TextBox();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.remove_all = new System.Windows.Forms.Button();
			this.import_profiles_file = new System.Windows.Forms.Button();
			this.Save_profile_to_file = new System.Windows.Forms.Button();
			this.profilesSearchTextBox = new System.Windows.Forms.TextBox();
			this.profiles_search_label = new System.Windows.Forms.Label();
			this.profiles_add_button = new System.Windows.Forms.Button();
			this.profiles_remove_button = new System.Windows.Forms.Button();
			this.profiles_edit_button = new System.Windows.Forms.Button();
			this.refresh_profiles_button = new System.Windows.Forms.Button();
			this.profiles_list_View = new System.Windows.Forms.ListView();
			this.service_name_columnHeader = new System.Windows.Forms.ColumnHeader();
			this.user_name_column_Header = new System.Windows.Forms.ColumnHeader();
			this.password_column_Header = new System.Windows.Forms.ColumnHeader();
			this.numberColumnHeader = new System.Windows.Forms.ColumnHeader();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.openEncryptionFileButton = new System.Windows.Forms.Button();
			this.add_file_button = new System.Windows.Forms.Button();
			this.remove_file_button = new System.Windows.Forms.Button();
			this.encrypt_file_button = new System.Windows.Forms.Button();
			this.decrypt_file_button = new System.Windows.Forms.Button();
			this.encryption_refresh_button = new System.Windows.Forms.Button();
			this.encrypted_files_textBox = new System.Windows.Forms.TextBox();
			this.encrypted_files_search_label = new System.Windows.Forms.Label();
			this.encrypted_files_list = new System.Windows.Forms.ListView();
			this.file_name_column_Header = new System.Windows.Forms.ColumnHeader();
			this.file_description_column_Header = new System.Windows.Forms.ColumnHeader();
			this.file_path_column_Header = new System.Windows.Forms.ColumnHeader();
			this.file_status_column_Header = new System.Windows.Forms.ColumnHeader();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label6 = new System.Windows.Forms.Label();
			this.search_box = new System.Windows.Forms.TextBox();
			this.open_folder = new System.Windows.Forms.Button();
			this.refresh = new System.Windows.Forms.Button();
			this.remove = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.listFolderName = new System.Windows.Forms.ColumnHeader();
			this.listFolderContents = new System.Windows.Forms.ColumnHeader();
			this.status = new System.Windows.Forms.ColumnHeader();
			this.listFolderPath = new System.Windows.Forms.ColumnHeader();
			this.add_folder = new System.Windows.Forms.Button();
			this.show = new System.Windows.Forms.Button();
			this.hide = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.USB_Status = new System.Windows.Forms.Label();
			this.unblock_usb = new System.Windows.Forms.Button();
			this.block_usb = new System.Windows.Forms.Button();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.openProfilesFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.importProfilesFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exportProfilesFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.addHiddenFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.addEncryptedFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.addProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cloudBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.lostFolderRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.lostFileRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.licenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.andriodAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.passwordPanel1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// passwordPanel1
			// 
			this.passwordPanel1.BackColor = System.Drawing.Color.FloralWhite;
			this.passwordPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passwordPanel1.BackgroundImage")));
			this.passwordPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.passwordPanel1.Controls.Add(this.label3);
			this.passwordPanel1.Controls.Add(this.panel1);
			this.passwordPanel1.Controls.Add(this.Login);
			this.passwordPanel1.Controls.Add(this.button9);
			this.passwordPanel1.Controls.Add(this.button8);
			this.passwordPanel1.Controls.Add(this.button7);
			this.passwordPanel1.Controls.Add(this.label4);
			this.passwordPanel1.Location = new System.Drawing.Point(-2, 0);
			this.passwordPanel1.Name = "passwordPanel1";
			this.passwordPanel1.Size = new System.Drawing.Size(936, 469);
			this.passwordPanel1.TabIndex = 1;
			// 
			// label3
			// 
			this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
			this.label3.Location = new System.Drawing.Point(427, 12);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(97, 122);
			this.label3.TabIndex = 9;
			this.toolTip1.SetToolTip(this.label3, "hidden-app.000webhostapp.com/");
			this.label3.Click += new System.EventHandler(this.Label3Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FloralWhite;
			this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
			this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.Button10);
			this.panel1.Controls.Add(this.NewPasswordHint);
			this.panel1.Controls.Add(this.ConfirmNewPassword);
			this.panel1.Controls.Add(this.NewPassword);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(934, 469);
			this.panel1.TabIndex = 7;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(142, 254);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(74, 23);
			this.label5.TabIndex = 6;
			this.label5.Text = "Password hint";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(142, 198);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(90, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "Confirm password";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(142, 151);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(90, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "Password";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// Button10
			// 
			this.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.Button10.Location = new System.Drawing.Point(237, 380);
			this.Button10.Name = "Button10";
			this.Button10.Size = new System.Drawing.Size(136, 23);
			this.Button10.TabIndex = 3;
			this.Button10.Text = "Save Password";
			this.Button10.UseVisualStyleBackColor = true;
			this.Button10.Click += new System.EventHandler(this.Button10Click);
			// 
			// NewPasswordHint
			// 
			this.NewPasswordHint.Location = new System.Drawing.Point(237, 256);
			this.NewPasswordHint.Name = "NewPasswordHint";
			this.NewPasswordHint.Size = new System.Drawing.Size(466, 96);
			this.NewPasswordHint.TabIndex = 2;
			this.NewPasswordHint.Text = "";
			// 
			// ConfirmNewPassword
			// 
			this.ConfirmNewPassword.Location = new System.Drawing.Point(238, 201);
			this.ConfirmNewPassword.Name = "ConfirmNewPassword";
			this.ConfirmNewPassword.Size = new System.Drawing.Size(466, 20);
			this.ConfirmNewPassword.TabIndex = 1;
			this.ConfirmNewPassword.UseSystemPasswordChar = true;
			// 
			// NewPassword
			// 
			this.NewPassword.Location = new System.Drawing.Point(237, 151);
			this.NewPassword.Name = "NewPassword";
			this.NewPassword.Size = new System.Drawing.Size(466, 20);
			this.NewPassword.TabIndex = 0;
			this.NewPassword.UseSystemPasswordChar = true;
			// 
			// Login
			// 
			this.Login.AcceptsReturn = true;
			this.Login.AcceptsTab = true;
			this.Login.Location = new System.Drawing.Point(304, 163);
			this.Login.Name = "Login";
			this.Login.Size = new System.Drawing.Size(352, 20);
			this.Login.TabIndex = 8;
			this.Login.UseSystemPasswordChar = true;
			this.Login.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LoginKeyPress);
			// 
			// button9
			// 
			this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button9.Location = new System.Drawing.Point(405, 203);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(119, 23);
			this.button9.TabIndex = 3;
			this.button9.Text = "Forgot password?";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.Button9Click);
			// 
			// button8
			// 
			this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button8.Location = new System.Drawing.Point(530, 203);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(131, 23);
			this.button8.TabIndex = 2;
			this.button8.Text = "Sign up";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.Button8Click);
			// 
			// button7
			// 
			this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button7.Location = new System.Drawing.Point(238, 203);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(155, 23);
			this.button7.TabIndex = 1;
			this.button7.Text = "Sign in";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.Button7Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(238, 163);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(60, 23);
			this.label4.TabIndex = 10;
			this.label4.Text = "Password :";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tabPage4
			// 
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new System.Drawing.Size(907, 393);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Settings";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.BackColor = System.Drawing.Color.FloralWhite;
			this.tabPage3.Controls.Add(this.remove_all);
			this.tabPage3.Controls.Add(this.import_profiles_file);
			this.tabPage3.Controls.Add(this.Save_profile_to_file);
			this.tabPage3.Controls.Add(this.profilesSearchTextBox);
			this.tabPage3.Controls.Add(this.profiles_search_label);
			this.tabPage3.Controls.Add(this.profiles_add_button);
			this.tabPage3.Controls.Add(this.profiles_remove_button);
			this.tabPage3.Controls.Add(this.profiles_edit_button);
			this.tabPage3.Controls.Add(this.refresh_profiles_button);
			this.tabPage3.Controls.Add(this.profiles_list_View);
			this.tabPage3.Location = new System.Drawing.Point(4, 34);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(926, 404);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Profiles";
			// 
			// remove_all
			// 
			this.remove_all.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.remove_all.Location = new System.Drawing.Point(468, 371);
			this.remove_all.Name = "remove_all";
			this.remove_all.Size = new System.Drawing.Size(72, 23);
			this.remove_all.TabIndex = 10;
			this.remove_all.Text = "Remove all";
			this.remove_all.UseVisualStyleBackColor = true;
			this.remove_all.Click += new System.EventHandler(this.Remove_allClick);
			// 
			// import_profiles_file
			// 
			this.import_profiles_file.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.import_profiles_file.Location = new System.Drawing.Point(644, 370);
			this.import_profiles_file.Name = "import_profiles_file";
			this.import_profiles_file.Size = new System.Drawing.Size(84, 23);
			this.import_profiles_file.TabIndex = 9;
			this.import_profiles_file.Text = "Import";
			this.import_profiles_file.UseVisualStyleBackColor = true;
			this.import_profiles_file.Click += new System.EventHandler(this.Import_profiles_fileClick);
			// 
			// Save_profile_to_file
			// 
			this.Save_profile_to_file.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.Save_profile_to_file.Location = new System.Drawing.Point(734, 370);
			this.Save_profile_to_file.Name = "Save_profile_to_file";
			this.Save_profile_to_file.Size = new System.Drawing.Size(86, 23);
			this.Save_profile_to_file.TabIndex = 8;
			this.Save_profile_to_file.Text = "Export";
			this.Save_profile_to_file.UseVisualStyleBackColor = true;
			this.Save_profile_to_file.Click += new System.EventHandler(this.Save_profile_to_fileClick);
			// 
			// profilesSearchTextBox
			// 
			this.profilesSearchTextBox.Location = new System.Drawing.Point(70, 6);
			this.profilesSearchTextBox.Name = "profilesSearchTextBox";
			this.profilesSearchTextBox.Size = new System.Drawing.Size(408, 20);
			this.profilesSearchTextBox.TabIndex = 7;
			this.profilesSearchTextBox.TextChanged += new System.EventHandler(this.ProfilesSearchTextBoxTextChanged);
			// 
			// profiles_search_label
			// 
			this.profiles_search_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.profiles_search_label.Location = new System.Drawing.Point(6, 6);
			this.profiles_search_label.Name = "profiles_search_label";
			this.profiles_search_label.Size = new System.Drawing.Size(57, 20);
			this.profiles_search_label.TabIndex = 6;
			this.profiles_search_label.Text = "Search : ";
			this.profiles_search_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// profiles_add_button
			// 
			this.profiles_add_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.profiles_add_button.Location = new System.Drawing.Point(283, 371);
			this.profiles_add_button.Name = "profiles_add_button";
			this.profiles_add_button.Size = new System.Drawing.Size(86, 23);
			this.profiles_add_button.TabIndex = 5;
			this.profiles_add_button.Text = "Add";
			this.profiles_add_button.UseVisualStyleBackColor = true;
			this.profiles_add_button.Click += new System.EventHandler(this.Profiles_add_buttonClick);
			// 
			// profiles_remove_button
			// 
			this.profiles_remove_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.profiles_remove_button.Location = new System.Drawing.Point(376, 371);
			this.profiles_remove_button.Name = "profiles_remove_button";
			this.profiles_remove_button.Size = new System.Drawing.Size(86, 23);
			this.profiles_remove_button.TabIndex = 4;
			this.profiles_remove_button.Text = "Remove";
			this.profiles_remove_button.UseVisualStyleBackColor = true;
			this.profiles_remove_button.Click += new System.EventHandler(this.Profiles_remove_buttonClick);
			// 
			// profiles_edit_button
			// 
			this.profiles_edit_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.profiles_edit_button.Location = new System.Drawing.Point(546, 371);
			this.profiles_edit_button.Name = "profiles_edit_button";
			this.profiles_edit_button.Size = new System.Drawing.Size(92, 23);
			this.profiles_edit_button.TabIndex = 2;
			this.profiles_edit_button.Text = "Edit";
			this.profiles_edit_button.UseVisualStyleBackColor = true;
			this.profiles_edit_button.Click += new System.EventHandler(this.Profiles_edit_buttonClick);
			// 
			// refresh_profiles_button
			// 
			this.refresh_profiles_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.refresh_profiles_button.Location = new System.Drawing.Point(826, 370);
			this.refresh_profiles_button.Name = "refresh_profiles_button";
			this.refresh_profiles_button.Size = new System.Drawing.Size(90, 23);
			this.refresh_profiles_button.TabIndex = 1;
			this.refresh_profiles_button.Text = "Refresh";
			this.refresh_profiles_button.UseVisualStyleBackColor = true;
			this.refresh_profiles_button.Click += new System.EventHandler(this.Refresh_profiles_buttonClick);
			// 
			// profiles_list_View
			// 
			this.profiles_list_View.AllowDrop = true;
			this.profiles_list_View.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
									this.service_name_columnHeader,
									this.user_name_column_Header,
									this.password_column_Header,
									this.numberColumnHeader});
			this.profiles_list_View.Font = new System.Drawing.Font("Bookman Old Style", 9.75F);
			this.profiles_list_View.FullRowSelect = true;
			this.profiles_list_View.GridLines = true;
			this.profiles_list_View.Location = new System.Drawing.Point(9, 32);
			this.profiles_list_View.MultiSelect = false;
			this.profiles_list_View.Name = "profiles_list_View";
			this.profiles_list_View.Size = new System.Drawing.Size(907, 327);
			this.profiles_list_View.TabIndex = 0;
			this.profiles_list_View.UseCompatibleStateImageBehavior = false;
			this.profiles_list_View.View = System.Windows.Forms.View.Details;
			this.profiles_list_View.DragEnter += new System.Windows.Forms.DragEventHandler(this.Profiles_list_ViewDragEnter);
			this.profiles_list_View.DoubleClick += new System.EventHandler(this.Profiles_list_ViewSelectedIndexChanged);
			// 
			// service_name_columnHeader
			// 
			this.service_name_columnHeader.Text = "Service";
			this.service_name_columnHeader.Width = 231;
			// 
			// user_name_column_Header
			// 
			this.user_name_column_Header.Text = "Username, email or phone number";
			this.user_name_column_Header.Width = 428;
			// 
			// password_column_Header
			// 
			this.password_column_Header.Text = "Password";
			this.password_column_Header.Width = 248;
			// 
			// numberColumnHeader
			// 
			this.numberColumnHeader.Text = "#";
			// 
			// tabPage2
			// 
			this.tabPage2.BackColor = System.Drawing.Color.FloralWhite;
			this.tabPage2.Controls.Add(this.openEncryptionFileButton);
			this.tabPage2.Controls.Add(this.add_file_button);
			this.tabPage2.Controls.Add(this.remove_file_button);
			this.tabPage2.Controls.Add(this.encrypt_file_button);
			this.tabPage2.Controls.Add(this.decrypt_file_button);
			this.tabPage2.Controls.Add(this.encryption_refresh_button);
			this.tabPage2.Controls.Add(this.encrypted_files_textBox);
			this.tabPage2.Controls.Add(this.encrypted_files_search_label);
			this.tabPage2.Controls.Add(this.encrypted_files_list);
			this.tabPage2.Location = new System.Drawing.Point(4, 34);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(926, 404);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Encrypted Files";
			// 
			// openEncryptionFileButton
			// 
			this.openEncryptionFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.openEncryptionFileButton.Location = new System.Drawing.Point(348, 370);
			this.openEncryptionFileButton.Name = "openEncryptionFileButton";
			this.openEncryptionFileButton.Size = new System.Drawing.Size(113, 23);
			this.openEncryptionFileButton.TabIndex = 8;
			this.openEncryptionFileButton.Text = "Open file";
			this.openEncryptionFileButton.UseVisualStyleBackColor = true;
			this.openEncryptionFileButton.Click += new System.EventHandler(this.OpenEncryptionFileButtonClick);
			// 
			// add_file_button
			// 
			this.add_file_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.add_file_button.Location = new System.Drawing.Point(239, 370);
			this.add_file_button.Name = "add_file_button";
			this.add_file_button.Size = new System.Drawing.Size(103, 23);
			this.add_file_button.TabIndex = 7;
			this.add_file_button.Text = "Add file";
			this.add_file_button.UseVisualStyleBackColor = true;
			this.add_file_button.Click += new System.EventHandler(this.Add_file_buttonClick);
			// 
			// remove_file_button
			// 
			this.remove_file_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.remove_file_button.Location = new System.Drawing.Point(467, 370);
			this.remove_file_button.Name = "remove_file_button";
			this.remove_file_button.Size = new System.Drawing.Size(112, 23);
			this.remove_file_button.TabIndex = 6;
			this.remove_file_button.Text = "Remove";
			this.remove_file_button.UseVisualStyleBackColor = true;
			this.remove_file_button.Click += new System.EventHandler(this.Remove_file_buttonClick);
			// 
			// encrypt_file_button
			// 
			this.encrypt_file_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.encrypt_file_button.Location = new System.Drawing.Point(585, 370);
			this.encrypt_file_button.Name = "encrypt_file_button";
			this.encrypt_file_button.Size = new System.Drawing.Size(111, 23);
			this.encrypt_file_button.TabIndex = 5;
			this.encrypt_file_button.Text = "Encrypt";
			this.encrypt_file_button.UseVisualStyleBackColor = true;
			this.encrypt_file_button.Click += new System.EventHandler(this.Encrypt_file_buttonClick);
			// 
			// decrypt_file_button
			// 
			this.decrypt_file_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.decrypt_file_button.Location = new System.Drawing.Point(702, 370);
			this.decrypt_file_button.Name = "decrypt_file_button";
			this.decrypt_file_button.Size = new System.Drawing.Size(111, 23);
			this.decrypt_file_button.TabIndex = 4;
			this.decrypt_file_button.Text = "Decrypt";
			this.decrypt_file_button.UseVisualStyleBackColor = true;
			this.decrypt_file_button.Click += new System.EventHandler(this.Decrypt_file_buttonClick);
			// 
			// encryption_refresh_button
			// 
			this.encryption_refresh_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.encryption_refresh_button.Location = new System.Drawing.Point(819, 370);
			this.encryption_refresh_button.Name = "encryption_refresh_button";
			this.encryption_refresh_button.Size = new System.Drawing.Size(97, 23);
			this.encryption_refresh_button.TabIndex = 3;
			this.encryption_refresh_button.Text = "Refresh";
			this.encryption_refresh_button.UseVisualStyleBackColor = true;
			this.encryption_refresh_button.Click += new System.EventHandler(this.Encryption_refresh_buttonClick);
			// 
			// encrypted_files_textBox
			// 
			this.encrypted_files_textBox.Location = new System.Drawing.Point(72, 6);
			this.encrypted_files_textBox.Name = "encrypted_files_textBox";
			this.encrypted_files_textBox.Size = new System.Drawing.Size(379, 20);
			this.encrypted_files_textBox.TabIndex = 2;
			this.encrypted_files_textBox.TextChanged += new System.EventHandler(this.Encrypted_files_textBoxTextChanged);
			// 
			// encrypted_files_search_label
			// 
			this.encrypted_files_search_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.encrypted_files_search_label.Location = new System.Drawing.Point(7, 6);
			this.encrypted_files_search_label.Name = "encrypted_files_search_label";
			this.encrypted_files_search_label.Size = new System.Drawing.Size(59, 21);
			this.encrypted_files_search_label.TabIndex = 1;
			this.encrypted_files_search_label.Text = "Search : ";
			this.encrypted_files_search_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// encrypted_files_list
			// 
			this.encrypted_files_list.AllowDrop = true;
			this.encrypted_files_list.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
									this.file_name_column_Header,
									this.file_description_column_Header,
									this.file_path_column_Header,
									this.file_status_column_Header});
			this.encrypted_files_list.Font = new System.Drawing.Font("Bookman Old Style", 9.75F);
			this.encrypted_files_list.FullRowSelect = true;
			this.encrypted_files_list.GridLines = true;
			this.encrypted_files_list.Location = new System.Drawing.Point(9, 31);
			this.encrypted_files_list.MultiSelect = false;
			this.encrypted_files_list.Name = "encrypted_files_list";
			this.encrypted_files_list.Size = new System.Drawing.Size(907, 327);
			this.encrypted_files_list.TabIndex = 0;
			this.encrypted_files_list.UseCompatibleStateImageBehavior = false;
			this.encrypted_files_list.View = System.Windows.Forms.View.Details;
			this.encrypted_files_list.DragEnter += new System.Windows.Forms.DragEventHandler(this.Encrypted_files_listDragEnter);
			this.encrypted_files_list.DoubleClick += new System.EventHandler(this.Encrypted_files_listSelectedIndexChanged);
			// 
			// file_name_column_Header
			// 
			this.file_name_column_Header.Text = "File name";
			this.file_name_column_Header.Width = 137;
			// 
			// file_description_column_Header
			// 
			this.file_description_column_Header.Text = "File description";
			this.file_description_column_Header.Width = 303;
			// 
			// file_path_column_Header
			// 
			this.file_path_column_Header.Text = "File path";
			this.file_path_column_Header.Width = 376;
			// 
			// file_status_column_Header
			// 
			this.file_status_column_Header.Text = "Status";
			this.file_status_column_Header.Width = 86;
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.Color.FloralWhite;
			this.tabPage1.Controls.Add(this.label6);
			this.tabPage1.Controls.Add(this.search_box);
			this.tabPage1.Controls.Add(this.open_folder);
			this.tabPage1.Controls.Add(this.refresh);
			this.tabPage1.Controls.Add(this.remove);
			this.tabPage1.Controls.Add(this.listView1);
			this.tabPage1.Controls.Add(this.add_folder);
			this.tabPage1.Controls.Add(this.show);
			this.tabPage1.Controls.Add(this.hide);
			this.tabPage1.Location = new System.Drawing.Point(4, 34);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(926, 404);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Hidden Folders";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(6, 4);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(57, 23);
			this.label6.TabIndex = 12;
			this.label6.Text = "Search : ";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// search_box
			// 
			this.search_box.Location = new System.Drawing.Point(69, 6);
			this.search_box.Name = "search_box";
			this.search_box.Size = new System.Drawing.Size(373, 20);
			this.search_box.TabIndex = 10;
			this.search_box.TextChanged += new System.EventHandler(this.Search_boxTextChanged);
			// 
			// open_folder
			// 
			this.open_folder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.open_folder.Location = new System.Drawing.Point(398, 370);
			this.open_folder.Name = "open_folder";
			this.open_folder.Size = new System.Drawing.Size(88, 23);
			this.open_folder.TabIndex = 9;
			this.open_folder.Text = "Open";
			this.open_folder.UseVisualStyleBackColor = true;
			this.open_folder.Click += new System.EventHandler(this.Open_folderClick);
			// 
			// refresh
			// 
			this.refresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.refresh.Location = new System.Drawing.Point(823, 371);
			this.refresh.Name = "refresh";
			this.refresh.Size = new System.Drawing.Size(94, 22);
			this.refresh.TabIndex = 8;
			this.refresh.Text = "Refresh";
			this.refresh.UseVisualStyleBackColor = true;
			this.refresh.Click += new System.EventHandler(this.RefreshClick);
			// 
			// remove
			// 
			this.remove.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.remove.Location = new System.Drawing.Point(492, 370);
			this.remove.Name = "remove";
			this.remove.Size = new System.Drawing.Size(89, 23);
			this.remove.TabIndex = 7;
			this.remove.Text = "Remove";
			this.remove.UseVisualStyleBackColor = true;
			this.remove.Click += new System.EventHandler(this.RemoveClick);
			// 
			// listView1
			// 
			this.listView1.AllowDrop = true;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
									this.listFolderName,
									this.listFolderContents,
									this.status,
									this.listFolderPath});
			this.listView1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.listView1.FullRowSelect = true;
			this.listView1.GridLines = true;
			this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.Location = new System.Drawing.Point(10, 32);
			this.listView1.MultiSelect = false;
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(907, 326);
			this.listView1.TabIndex = 6;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.ListView1DragEnter);
			this.listView1.DoubleClick += new System.EventHandler(this.ListView1DoubleClick);
			// 
			// listFolderName
			// 
			this.listFolderName.Text = "Folder name";
			this.listFolderName.Width = 139;
			// 
			// listFolderContents
			// 
			this.listFolderContents.Text = "Folder contents";
			this.listFolderContents.Width = 303;
			// 
			// status
			// 
			this.status.DisplayIndex = 3;
			this.status.Text = "Status";
			this.status.Width = 91;
			// 
			// listFolderPath
			// 
			this.listFolderPath.DisplayIndex = 2;
			this.listFolderPath.Text = "Folder path";
			this.listFolderPath.Width = 370;
			// 
			// add_folder
			// 
			this.add_folder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.add_folder.Location = new System.Drawing.Point(296, 370);
			this.add_folder.Name = "add_folder";
			this.add_folder.Size = new System.Drawing.Size(96, 23);
			this.add_folder.TabIndex = 5;
			this.add_folder.Text = "Add folder";
			this.add_folder.UseVisualStyleBackColor = true;
			this.add_folder.Click += new System.EventHandler(this.Add_folderClick);
			// 
			// show
			// 
			this.show.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.show.Location = new System.Drawing.Point(706, 370);
			this.show.Name = "show";
			this.show.Size = new System.Drawing.Size(111, 23);
			this.show.TabIndex = 2;
			this.show.Text = "Show";
			this.show.UseVisualStyleBackColor = true;
			this.show.Click += new System.EventHandler(this.Button4Click);
			// 
			// hide
			// 
			this.hide.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.hide.Location = new System.Drawing.Point(587, 370);
			this.hide.Name = "hide";
			this.hide.Size = new System.Drawing.Size(113, 23);
			this.hide.TabIndex = 1;
			this.hide.Text = "Hide";
			this.hide.UseVisualStyleBackColor = true;
			this.hide.Click += new System.EventHandler(this.Button3Click);
			// 
			// tabControl1
			// 
			this.tabControl1.AllowDrop = true;
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage5);
			this.tabControl1.ItemSize = new System.Drawing.Size(60, 30);
			this.tabControl1.Location = new System.Drawing.Point(-2, 27);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.Padding = new System.Drawing.Point(10, 3);
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.ShowToolTips = true;
			this.tabControl1.Size = new System.Drawing.Size(934, 442);
			this.tabControl1.TabIndex = 2;
			// 
			// tabPage5
			// 
			this.tabPage5.BackColor = System.Drawing.Color.FloralWhite;
			this.tabPage5.Controls.Add(this.USB_Status);
			this.tabPage5.Controls.Add(this.unblock_usb);
			this.tabPage5.Controls.Add(this.block_usb);
			this.tabPage5.Location = new System.Drawing.Point(4, 34);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage5.Size = new System.Drawing.Size(926, 404);
			this.tabPage5.TabIndex = 3;
			this.tabPage5.Text = "USB Security";
			// 
			// USB_Status
			// 
			this.USB_Status.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.USB_Status.Location = new System.Drawing.Point(136, 195);
			this.USB_Status.Name = "USB_Status";
			this.USB_Status.Size = new System.Drawing.Size(627, 121);
			this.USB_Status.TabIndex = 2;
			this.USB_Status.Text = "All ports are not blocked";
			this.USB_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// unblock_usb
			// 
			this.unblock_usb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.unblock_usb.Location = new System.Drawing.Point(526, 89);
			this.unblock_usb.Name = "unblock_usb";
			this.unblock_usb.Size = new System.Drawing.Size(237, 77);
			this.unblock_usb.TabIndex = 1;
			this.unblock_usb.Text = "Unblock USB Ports";
			this.unblock_usb.UseVisualStyleBackColor = true;
			this.unblock_usb.Click += new System.EventHandler(this.Unblock_usbClick);
			// 
			// block_usb
			// 
			this.block_usb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.block_usb.Location = new System.Drawing.Point(136, 89);
			this.block_usb.Name = "block_usb";
			this.block_usb.Size = new System.Drawing.Size(233, 77);
			this.block_usb.TabIndex = 0;
			this.block_usb.Text = "Block USB Ports";
			this.block_usb.UseVisualStyleBackColor = true;
			this.block_usb.Click += new System.EventHandler(this.Block_usbClick);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.fileToolStripMenuItem,
									this.settingsToolStripMenuItem,
									this.aboutToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
			this.menuStrip1.Size = new System.Drawing.Size(930, 24);
			this.menuStrip1.TabIndex = 3;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.openProfilesFileToolStripMenuItem,
									this.importProfilesFileToolStripMenuItem,
									this.exportProfilesFileToolStripMenuItem,
									this.toolStripSeparator1,
									this.addHiddenFolderToolStripMenuItem,
									this.addEncryptedFileToolStripMenuItem,
									this.addProfileToolStripMenuItem,
									this.exitToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// openProfilesFileToolStripMenuItem
			// 
			this.openProfilesFileToolStripMenuItem.Name = "openProfilesFileToolStripMenuItem";
			this.openProfilesFileToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.openProfilesFileToolStripMenuItem.Text = "Open profiles file";
			this.openProfilesFileToolStripMenuItem.Click += new System.EventHandler(this.OpenProfilesFileToolStripMenuItemClick);
			// 
			// importProfilesFileToolStripMenuItem
			// 
			this.importProfilesFileToolStripMenuItem.Name = "importProfilesFileToolStripMenuItem";
			this.importProfilesFileToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.importProfilesFileToolStripMenuItem.Text = "Import profiles file";
			this.importProfilesFileToolStripMenuItem.Click += new System.EventHandler(this.ImportProfilesFileToolStripMenuItemClick);
			// 
			// exportProfilesFileToolStripMenuItem
			// 
			this.exportProfilesFileToolStripMenuItem.Name = "exportProfilesFileToolStripMenuItem";
			this.exportProfilesFileToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.exportProfilesFileToolStripMenuItem.Text = "Export profiles file";
			this.exportProfilesFileToolStripMenuItem.Click += new System.EventHandler(this.ExportProfilesFileToolStripMenuItemClick);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(171, 6);
			// 
			// addHiddenFolderToolStripMenuItem
			// 
			this.addHiddenFolderToolStripMenuItem.Name = "addHiddenFolderToolStripMenuItem";
			this.addHiddenFolderToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.addHiddenFolderToolStripMenuItem.Text = "Add Hidden Folder";
			this.addHiddenFolderToolStripMenuItem.Click += new System.EventHandler(this.AddHiddenFolderToolStripMenuItemClick);
			// 
			// addEncryptedFileToolStripMenuItem
			// 
			this.addEncryptedFileToolStripMenuItem.Name = "addEncryptedFileToolStripMenuItem";
			this.addEncryptedFileToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.addEncryptedFileToolStripMenuItem.Text = "Add Encrypted File";
			this.addEncryptedFileToolStripMenuItem.Click += new System.EventHandler(this.AddEncryptedFileToolStripMenuItemClick);
			// 
			// addProfileToolStripMenuItem
			// 
			this.addProfileToolStripMenuItem.Name = "addProfileToolStripMenuItem";
			this.addProfileToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.addProfileToolStripMenuItem.Text = "Add Profile";
			this.addProfileToolStripMenuItem.Click += new System.EventHandler(this.AddProfileToolStripMenuItemClick);
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
			this.exitToolStripMenuItem.Text = "Exit";
			this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
			// 
			// settingsToolStripMenuItem
			// 
			this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.cloudBackupToolStripMenuItem,
									this.lostFolderRecoveryToolStripMenuItem,
									this.lostFileRecoveryToolStripMenuItem});
			this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
			this.settingsToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
			this.settingsToolStripMenuItem.Text = "Edit";
			// 
			// cloudBackupToolStripMenuItem
			// 
			this.cloudBackupToolStripMenuItem.Name = "cloudBackupToolStripMenuItem";
			this.cloudBackupToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.cloudBackupToolStripMenuItem.Text = "Hidden folders";
			this.cloudBackupToolStripMenuItem.Click += new System.EventHandler(this.CloudBackupToolStripMenuItemClick);
			// 
			// lostFolderRecoveryToolStripMenuItem
			// 
			this.lostFolderRecoveryToolStripMenuItem.Name = "lostFolderRecoveryToolStripMenuItem";
			this.lostFolderRecoveryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.lostFolderRecoveryToolStripMenuItem.Text = "Encrypted files";
			this.lostFolderRecoveryToolStripMenuItem.Click += new System.EventHandler(this.LostFolderRecoveryToolStripMenuItemClick);
			// 
			// lostFileRecoveryToolStripMenuItem
			// 
			this.lostFileRecoveryToolStripMenuItem.Name = "lostFileRecoveryToolStripMenuItem";
			this.lostFileRecoveryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.lostFileRecoveryToolStripMenuItem.Text = "Profiles";
			this.lostFileRecoveryToolStripMenuItem.Click += new System.EventHandler(this.LostFileRecoveryToolStripMenuItemClick);
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.helpToolStripMenuItem1,
									this.licenceToolStripMenuItem,
									this.andriodAppToolStripMenuItem,
									this.helpToolStripMenuItem});
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
			this.aboutToolStripMenuItem.Text = "Help";
			// 
			// helpToolStripMenuItem1
			// 
			this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
			this.helpToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
			this.helpToolStripMenuItem1.Text = "Read me...";
			this.helpToolStripMenuItem1.Click += new System.EventHandler(this.HelpToolStripMenuItem1Click);
			// 
			// licenceToolStripMenuItem
			// 
			this.licenceToolStripMenuItem.Name = "licenceToolStripMenuItem";
			this.licenceToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
			this.licenceToolStripMenuItem.Text = "Licence";
			this.licenceToolStripMenuItem.Click += new System.EventHandler(this.LicenceToolStripMenuItemClick);
			// 
			// andriodAppToolStripMenuItem
			// 
			this.andriodAppToolStripMenuItem.Name = "andriodAppToolStripMenuItem";
			this.andriodAppToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
			this.andriodAppToolStripMenuItem.Text = "Android app";
			this.andriodAppToolStripMenuItem.Click += new System.EventHandler(this.AndriodAppToolStripMenuItemClick);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
			this.helpToolStripMenuItem.Text = "About";
			this.helpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItemClick);
			// 
			// openFileDialog
			// 
			this.openFileDialog.Title = "Select a file";
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.AddExtension = false;
			this.saveFileDialog1.DefaultExt = "hidden";
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.ClientSize = new System.Drawing.Size(930, 467);
			this.Controls.Add(this.passwordPanel1);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.menuStrip1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Hidden";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainFormFormClosing);
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.passwordPanel1.ResumeLayout(false);
			this.passwordPanel1.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage5.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button remove_all;
		private System.Windows.Forms.ToolStripMenuItem importProfilesFileToolStripMenuItem;
		private System.Windows.Forms.Button import_profiles_file;
		private System.Windows.Forms.ToolStripMenuItem exportProfilesFileToolStripMenuItem;
		private System.Windows.Forms.Label USB_Status;
		private System.Windows.Forms.Button block_usb;
		private System.Windows.Forms.Button unblock_usb;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button Save_profile_to_file;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripMenuItem openProfilesFileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem andriodAppToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
		private System.Windows.Forms.ToolStripMenuItem licenceToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem lostFileRecoveryToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem lostFolderRecoveryToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cloudBackupToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem addProfileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem addEncryptedFileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem addHiddenFolderToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ColumnHeader numberColumnHeader;
		private System.Windows.Forms.Button openEncryptionFileButton;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.ColumnHeader password_column_Header;
		private System.Windows.Forms.ColumnHeader user_name_column_Header;
		private System.Windows.Forms.ColumnHeader service_name_columnHeader;
		private System.Windows.Forms.ListView profiles_list_View;
		private System.Windows.Forms.Button refresh_profiles_button;
		private System.Windows.Forms.Button profiles_edit_button;
		private System.Windows.Forms.Button profiles_remove_button;
		private System.Windows.Forms.Button profiles_add_button;
		private System.Windows.Forms.Label profiles_search_label;
		private System.Windows.Forms.TextBox profilesSearchTextBox;
		private System.Windows.Forms.Button decrypt_file_button;
		private System.Windows.Forms.Button encrypt_file_button;
		private System.Windows.Forms.Button remove_file_button;
		private System.Windows.Forms.Button add_file_button;
		private System.Windows.Forms.Button encryption_refresh_button;
		private System.Windows.Forms.ColumnHeader file_status_column_Header;
		private System.Windows.Forms.ColumnHeader file_path_column_Header;
		private System.Windows.Forms.ColumnHeader file_description_column_Header;
		private System.Windows.Forms.ColumnHeader file_name_column_Header;
		private System.Windows.Forms.ListView encrypted_files_list;
		private System.Windows.Forms.Label encrypted_files_search_label;
		private System.Windows.Forms.TextBox encrypted_files_textBox;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox search_box;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button open_folder;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ColumnHeader status;
		private System.Windows.Forms.Button refresh;
		private System.Windows.Forms.Button remove;
		private System.Windows.Forms.ColumnHeader listFolderPath;
		private System.Windows.Forms.ColumnHeader listFolderContents;
		private System.Windows.Forms.ColumnHeader listFolderName;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button Button10;
		private System.Windows.Forms.TextBox ConfirmNewPassword;
		private System.Windows.Forms.RichTextBox NewPasswordHint;
		private System.Windows.Forms.TextBox NewPassword;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button add_folder;
		private System.Windows.Forms.TextBox Login;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Panel passwordPanel1;
		private System.Windows.Forms.Button hide;
		private System.Windows.Forms.Button show;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl tabControl1;
		
		/// <summary>
		/// The database file that will hold the user profile information.
		/// The file name is supposed to be 'Password.sqlite' but for
		/// security puposes it shall be named '2000100.bin'
		/// </summary>
		Files Password_file = new Files("Hidden","2000100.bin");

		/// <summary>
		/// The database file that contains the list of encrypted files
		/// </summary>
		Files Encrypted_Files_file = new Files("Hidden","20002000.bin");
		
		/// <summary>
		/// The database file that will hold the hidden files
		/// The file name is supposed to be 'Hidden_Files.sqlite ' but for
		/// security purposes it shall be named 2000300.bin
		/// </summary>
		Files Hidden_Files_file = new Files("Hidden","2000300.bin");
		
		/// <summary>
		/// The database file that contains the list of profile information for 
		/// internet services, like facebook and google. Takes password and username or email
		/// </summary>
		Files Profiles_file = new Files("Hidden","2000400.bin");

		/// <summary>
		/// Keeps track of users USB Block status
		/// </summary>
		Files USB_file = new Files("Hidden","2000500.bin");
		
		/// <summary>
		/// Child thread to lockout the user
		/// </summary>
		private ThreadStart childref;
		private Thread childThread;
		
		private Stopwatch stopwatch;
		
		/// <summary>
		/// Lockout the user if not active
		/// </summary>
		private void LockOutTimer()
		{
			Thread.Sleep(120000);
			
			if(InvokeRequired)
			{
				
				Invoke(new MethodInvoker(OpenThePasswordPanel));
			}
			else
			{
				OpenThePasswordPanel();
			}
		}
		
		/// <summary>
		/// Opens the password panel to the new thread and refreshesh all the Lists 
		/// </summary>
		public void OpenThePasswordPanel()
		{
			Login.Text = "";
			passwordPanel1.Visible = true;
			MessageBox.Show("You have been locked out due to inactivity");
			childThread.Abort();
			
		}
				
		/// <summary>
		/// Hide the folders from the user
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button3Click(object sender, System.EventArgs e)
		{
			try
			{
				Database database1 = new Database(Hidden_Files_file.FilePath);
				database1.query("UPDATE folder SET status = 'hidden' WHERE path = '"+listView1.SelectedItems[0].SubItems[3].Text+"'");
				Visibility.Hide(listView1.SelectedItems[0].SubItems[3].Text);
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
				listView1.Items.Clear();
				while(folderReader.Read())
				{
					listView1.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["name"].ToString(),
								folderReader["contents"].ToString(),
								folderReader["status"].ToString(),
								folderReader["path"].ToString()
							}
						)
					);
					
				}
				database1.Close();
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a folder for this operation","Error");
			}
		}
		
		/// <summary>
		/// Make the hidden folders visible
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button4Click(object sender, System.EventArgs e)
		{
			try
			{
				Database database1 = new Database(Hidden_Files_file.FilePath);
				database1.query("UPDATE folder SET status = 'visible' WHERE path = '"+listView1.SelectedItems[0].SubItems[3].Text+"'");
				Visibility.Show(listView1.SelectedItems[0].SubItems[3].Text);
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
				listView1.Items.Clear();
				while(folderReader.Read())
				{
					listView1.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["name"].ToString(),
								folderReader["contents"].ToString(),
								folderReader["status"].ToString(),
								folderReader["path"].ToString()
							}
						)
					);
					
				}
				database1.Close();
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a folder for this operation","Error");
			}
		}
		
		/// <summary>
		/// Sign in button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button7Click(object sender, System.EventArgs e)
		{
			/**
			 * Check if the password box has the password
			 */
			if(Login.Text.Equals("") || Login.Text.Equals("Enter Password"))
			{
				MessageBox.Show("Please type in your password","Error");
				return;
			}
			
			/**
			 * holds password from the database
			 */
			string db_password = "";
			
			/**
			 * Get the password from the database 
			 */
			Database Password_file_db = new Database(Password_file.FilePath);
			SQLiteDataReader reader = Password_file_db.fetch("SELECT * FROM password");
			
			try
			{
				while(reader.Read())
				{
					db_password = reader["password"].ToString();
				}
			}
			catch(NullReferenceException nullEx)
			{
				MessageBox.Show(nullEx.Message+" : "+nullEx.StackTrace.ToString());
			}
			
			Password_file_db.Close();
			
			if(Login.Text.Equals(db_password))
			{
				passwordPanel1.Visible = false;
				Database database1 = new Database(Hidden_Files_file.FilePath);
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
					
				listView1.Items.Clear();
				
				while(folderReader.Read())
				{
					listView1.Items.Add(
						new ListViewItem(
							new string[]
							{
					        	folderReader["name"].ToString(),
					            folderReader["contents"].ToString(),
					            folderReader["status"].ToString(),
					            folderReader["path"].ToString()
							}
						)
					);
				}
				database1.Close();
				
				Database database2 = new Database(Encrypted_Files_file.FilePath);
				SQLiteDataReader encryptedFilesReader = database2.fetch("SELECT * FROM encrypted");
				
				encrypted_files_list.Items.Clear();
				
				while(encryptedFilesReader.Read())
				{
					encrypted_files_list.Items.Add(
						new ListViewItem(
							new string[]
							{
								encryptedFilesReader["name"].ToString(),
								encryptedFilesReader["description"].ToString(),
								encryptedFilesReader["path"].ToString(),
								encryptedFilesReader["status"].ToString()
							}
						)
					);
				}
				database2.Close();
				
				try
				{
					Database database3;
					
					if(!(My_temp_profiles_file.Equals("")))
					{
						database3 = new Database(My_temp_profiles_file,user_password);
					}
					else
					{
						database3 = new Database(Profiles_file.FilePath);
					}
					
					SQLiteDataReader profilesFilesReader = database3.fetch("SELECT * FROM profiles");
					
					profiles_list_View.Items.Clear();
					
					while(profilesFilesReader.Read())
					{
						profiles_list_View.Items.Add(
							new ListViewItem(
								new string[]
								{
									profilesFilesReader["service"].ToString(),
									profilesFilesReader["username"].ToString(),
									profilesFilesReader["password"].ToString(),
									profilesFilesReader["id"].ToString()
								}
							)
						);
					}
					database3.Close();
				}
				catch(Exception){}
				
				/// <summary>
				/// USB Security status text
				/// </summary>
				Database USB_DB = new Database(USB_file.FilePath);
				SQLiteDataReader db_reader = USB_DB.fetch("SELECT * FROM status");
				
				while(db_reader.Read())
				{
					USB_Status.Text = db_reader["status_text"].ToString();
				}
				
				db_reader.Close();
				
				/// <summary>
				/// Start counting the time to lock out the user
				/// </summary>
				/// <param name="sender"></param>
				/// <param name="e"></param>
				childref = new ThreadStart(LockOutTimer);
				childThread = new Thread(childref);
				childThread.Start();
				
				/// <summary>
				/// start the stopwatch to kill childthread if windows closes early
				/// </summary>
				/// <param name="sender"></param>
				/// <param name="e"></param>
				stopwatch = new Stopwatch();
				stopwatch.Start();
			}
			else
			{
				MessageBox.Show("The password that you have provided is not recognised\nPlease click forgot password","Error");
			}
		}
		
		/// <summary>
		/// Forgot password button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button9Click(object sender, System.EventArgs e)
		{
			/**
			 * holds password hint from the database;
			 */
			string db_password_hint = "";

			/**
			 * Get the password from the database 
			 */
			Database Password_file_db = new Database(Password_file.FilePath);
			SQLiteDataReader reader = Password_file_db.fetch("SELECT * FROM password");
			while(reader.Read())
			{
				db_password_hint = (string)reader["hint"];
			}
			Password_file_db.Close();
			
			MessageBox.Show("Password hint : "+db_password_hint);
		}
		
		/// <summary>
		/// sign up button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button8Click(object sender, System.EventArgs e)
		{
			UpdatePasswordControl upc = new UpdatePasswordControl();
			upc.ShowDialog(this);
		}
		
		/// <summary>
		/// Sign up button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Button10Click(object sender, System.EventArgs e)
		{
			/**
			 * Check if the user has typed in the new password
			 */
			if(NewPassword.Text.Equals("") || NewPassword.Text.Equals("Password"))
			{
				MessageBox.Show("Please type your password","Error");
				return;
			}
			
			/**
			 * Check if the user has typed in the password confirmation
			 */
			if(ConfirmNewPassword.Text.Equals("") || ConfirmNewPassword.Text.Equals("Confirm password"))
			{
				MessageBox.Show("Please type your new password","Error");
				return;
			}
			
			if(!(NewPassword.Text.Equals(ConfirmNewPassword.Text.ToString())))
			{
				MessageBox.Show("The password and password confirmation do not match","Error");
				return;
			}
			
			/**
			 * Check if the user has put in a password hint
			 */
			if
			(
				NewPasswordHint.Text.Equals("") || 
				NewPasswordHint.Text.Equals("Pasword hint (type any information that could remind you the password)")
			)
			{
				MessageBox.Show("Please type password hint to remind you in case you forget","Error");
				return;
			}
			
			//Create a password db
			Database Password_file_db = new Database(Password_file.FilePath);
			Password_file_db.query("CREATE TABLE password (password VARCHAR(255), hint VARCHAR(255))");
			Password_file_db.query("INSERT INTO password VALUES(\""+NewPassword.Text+"\",\""+NewPasswordHint.Text+"\")");
			Password_file_db.Close();
			
			//Hidden folders database
			Database Hidden_Files_file_db = new Database(Hidden_Files_file.FilePath);
			Hidden_Files_file_db.query("CREATE TABLE folder (name VARCHAR(255), contents VARCHAR(255), path VARCHAR(255), status VARCHAR(255))");
			Hidden_Files_file_db.Close();
			
			//Encrypted files databse
			Database Encrypted_Files_file_db = new Database(Encrypted_Files_file.FilePath);
			Encrypted_Files_file_db.query("CREATE TABLE encrypted (name VARCHAR(255), description VARCHAR(255), path VARCHAR(255), status VARCHAR(255))");
			Encrypted_Files_file_db.Close();
			
			//Profiles databse
			Database Profiles_db = new Database(Profiles_file.FilePath);
			Profiles_db.query("CREATE TABLE profiles (id INTEGER PRIMARY KEY AUTOINCREMENT, service VARCHAR(255), username VARCHAR(255), password VARCHAR(255))");
			Profiles_db.Close();
			
			//USB Protect database
			Database USB_DB = new Database(USB_file.FilePath);
			USB_DB.query("CREATE TABLE status (id INTEGER PRIMARY KEY AUTOINCREMENT, status_text TEXT)");
			USB_DB.query("INSERT INTO STATUS(status_text) VALUES(\"USB Storage is enabled\")");
			USB_DB.Close();
			          
			// File association
			try
			{
				if(!CheckAdminRole())
				{
					
					MessageBox.Show("You have to run this software as Administrator before installing it, " +
					                "Do that by right clicking on Hidden Setup.exe, " +
					                "Then click 'Run as administrator' from the menu");
				}
				else
				{
					FileAssociation fileassoc = new FileAssociation();
					FileAssociation.SetAssociation(".hidden","Hidden_Profiles_File",fileassoc.FilePath,"Hidden Profiles File");
				}
			}
			catch(Exception)
			{
				MessageBox.Show("Oops! something just went wrong.");
			}
			
			//Now the user no longer has to see the registration pannel no more
			passwordPanel1.Visible = false;
		}
		
		/// <summary>
		/// when the window is loaded
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void MainFormLoad(object sender, System.EventArgs e)
		{
			if(Password_file.Exist() && Hidden_Files_file.Exist())
			{
				//Hide the sign up panel if it is the user's first time using the app  
				panel1.Visible = false;
			}
			else
			{
				panel1.Visible = true;
			}
			childref = new ThreadStart(LockOutTimer);
			childThread = new Thread(childref);
		}
		
		/// <summary>
		/// Adds a folder to the database
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_folderClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			Add_Iterm_Dialog add_item_dialog = new Add_Iterm_Dialog();
			add_item_dialog.Save_what = "folders";
			add_item_dialog.ShowDialog(this);
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
			
			listView1.Items.Clear();
			Database database1 = new Database(Hidden_Files_file.FilePath);
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
			
			while(folderReader.Read())
			{
				listView1.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["contents"].ToString(),
							folderReader["status"].ToString(),
							folderReader["path"].ToString()
						}
					)
				);
				
			}
			database1.Close();
		}
		
		/// <summary>
		/// Refresh a list of folders
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void RefreshClick(object sender, EventArgs e)
		{
			listView1.Items.Clear();
			Database database1 = new Database(Hidden_Files_file.FilePath);
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
			
			while(folderReader.Read())
			{
				listView1.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["contents"].ToString(),
							folderReader["status"].ToString(),
							folderReader["path"].ToString()
						}
					)
				);
				
			}
			database1.Close();
		}
		
		/// <summary>
		/// Remove an item from the list of folders
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void RemoveClick(object sender, EventArgs e)
		{
			Database database1 = new Database(Hidden_Files_file.FilePath);
			try
			{
				SQLiteDataReader reader = database1.fetch("SELECT * FROM folder WHERE path = '"+listView1.SelectedItems[0].SubItems[3].Text+"'");
				while(reader.Read())
				{
					if(reader["status"].ToString().Equals("hidden"))
					{
						if(MessageBox.Show("You are about to remove a hidden object\nYou might not be able to recover it ","Warning",
						                   MessageBoxButtons.OKCancel,MessageBoxIcon.Warning,
						                   MessageBoxDefaultButton.Button1,MessageBoxOptions.RightAlign,false).Equals(DialogResult.Cancel))
						{
							return;
						}
					}
				}
				database1.query("DELETE FROM folder WHERE path = '"+listView1.SelectedItems[0].SubItems[3].Text+"'");
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a folder for this operation","Error");
			}
			
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
			listView1.Items.Clear();
			while(folderReader.Read())
			{
				listView1.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["contents"].ToString(),
							folderReader["status"].ToString(),
							folderReader["path"].ToString()
						}
					)
				);
			}
			database1.Close();
		}
		
		/// <summary>
		/// Open the folder that the user clicked on
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ListView1DoubleClick(object sender, EventArgs e)
		{
			try
			{
				System.Diagnostics.Process process = new System.Diagnostics.Process();
            	System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            	startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
            	startInfo.FileName = "explorer.exe";
            	startInfo.Arguments = listView1.SelectedItems[0].SubItems[3].Text;
            	process.StartInfo = startInfo;
            	process.Start();
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a folder for this operation","Error");
			}			
		}
		
		/// <summary>
		/// DROP IT LIKE IT'S HOT
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ListView1DragEnter(object sender, DragEventArgs e)
		{
			DragDropEffects effects = DragDropEffects.None;
			if(e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string path = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
				
				if(Directory.Exists(path))
				{
					effects = DragDropEffects.Copy;
					
					childThread.Abort();
					
					Add_Iterm_Dialog add_item_dialog = new Add_Iterm_Dialog();
					add_item_dialog.FolderPath = path;
					add_item_dialog.Show(this);
					
					childThread = new Thread(childref);
					childThread.Start();
					stopwatch.Restart();
				}
				e.Effect = effects;
			}
			
			listView1.Items.Clear();
			Database database1 = new Database(Hidden_Files_file.FilePath);
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM folder");
			
			while(folderReader.Read())
			{
				listView1.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["contents"].ToString(),
							folderReader["status"].ToString(),
							folderReader["path"].ToString()
						}
					)
				);
				
			}
			database1.Close();
		}
		
		/// <summary>
		/// Open the folder that the user selected
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Open_folderClick(object sender, EventArgs e)
		{
			try
			{
				System.Diagnostics.Process process = new System.Diagnostics.Process();
            	System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            	startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
            	startInfo.FileName = "explorer.exe";
            	startInfo.Arguments = listView1.SelectedItems[0].SubItems[3].Text;
            	process.StartInfo = startInfo;
            	process.Start();
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a folder for this operation","Error");
			}			
		}
		
		/// <summary>
		/// Open our home page
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Label3Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://hidden-app.000webhostapp.com/");
		}
		
		/// <summary>
		/// Searches for items from the database that have a similar sound to 
		/// The key words that have been inserted
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Search_boxTextChanged(object sender, EventArgs e)
		{
			Database database1 = new Database(Hidden_Files_file.FilePath);
			
			String sql = "SELECT * FROM folder " +
				"WHERE name LIKE '%"+search_box.Text+"%'" +
				"OR contents LIKE '%"+search_box.Text+"%'" +
				"OR status LIKE '%"+search_box.Text+"%'" +
				"OR path LIKE '%"+search_box.Text+"%'";
				
			SQLiteDataReader folderReader = database1.fetch(sql);
			listView1.Items.Clear();
			while(folderReader.Read())
			{
				listView1.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["contents"].ToString(),
							folderReader["status"].ToString(),
							folderReader["path"].ToString()
						}
					)
				);
			}
			database1.Close();			
		}
		
		/// <summary>
		/// When user clicks the 'ENTER' or 'Return' button the event handler 
		/// triggered by the login button is triggered by this event 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void LoginKeyPress(object sender, KeyPressEventArgs e)
		{
			if(e.KeyChar.Equals('\r'))
			{
				Button7Click(sender,e);
			}
		}
		
		/// <summary>
		/// Search for the files on the list encrypted 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Encrypted_files_textBoxTextChanged(object sender, EventArgs e)
		{
			Database database1 = new Database(Encrypted_Files_file.FilePath);
			
			String sql = "SELECT * FROM encrypted " +
				"WHERE name LIKE '%"+encrypted_files_textBox.Text+"%'" +
				"OR description LIKE '%"+encrypted_files_textBox.Text+"%'" +
				"OR path LIKE '%"+encrypted_files_textBox.Text+"%'" +
				"OR status LIKE '%"+encrypted_files_textBox.Text+"%'";
				
			SQLiteDataReader folderReader = database1.fetch(sql);
			encrypted_files_list.Items.Clear();
			while(folderReader.Read())
			{
				encrypted_files_list.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["description"].ToString(),
							folderReader["path"].ToString(),
							folderReader["status"].ToString()
						}
					)
				);
			}
			database1.Close();			
		}
		
		/// <summary>
		/// Add the files to be encrypted to the list 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_file_buttonClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			Add_File_Dialog addFile = new Add_File_Dialog();
			addFile.ShowDialog(this);
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
			
			encrypted_files_list.Items.Clear();
			Database database1 = new Database(Encrypted_Files_file.FilePath);
			String sql = "SELECT * FROM encrypted";
			
			SQLiteDataReader folderReader = database1.fetch(sql);
			
			while(folderReader.Read())
			{
				encrypted_files_list.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["description"].ToString(),
							folderReader["path"].ToString(),
							folderReader["status"].ToString()
						}
					)
				);
			}
			database1.Close();	
		}
		
		/// <summary>
		/// Remove a file from the list of encrypted files
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Remove_file_buttonClick(object sender, EventArgs e)
		{
			Database database1 = new Database(Encrypted_Files_file.FilePath);
			try
			{
				SQLiteDataReader reader = database1.fetch("SELECT * FROM encrypted WHERE path = '"+encrypted_files_list.SelectedItems[0].SubItems[2].Text+"'");
				while(reader.Read())
				{
					if(reader["status"].ToString().Equals("encrypted"))
					{
						if(MessageBox.Show("You are about to remove an encrypted object from the list\nYou might not be able to recover it ","Warning",
						                   MessageBoxButtons.OKCancel,MessageBoxIcon.Warning,
						                   MessageBoxDefaultButton.Button1,MessageBoxOptions.RightAlign,false).Equals(DialogResult.Cancel))
						{
							return;
						}
					}
				}
				database1.query("DELETE FROM encrypted WHERE path = '"+encrypted_files_list.SelectedItems[0].SubItems[2].Text+"'");
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a file for this operation","Error");
			}
			
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM encrypted");
			encrypted_files_list.Items.Clear();
			while(folderReader.Read())
			{
				encrypted_files_list.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["description"].ToString(),
							folderReader["path"].ToString(),
							folderReader["status"].ToString()
						}
					)
				);
			}
			database1.Close();			
		}
		
		/// <summary>
		/// Button encrypts the selected file
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Encrypt_file_buttonClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			try
			{	
				WaitingDialog wait = new WaitingDialog();
				
				wait.ActionLabel.Text = "Encrypting";
				wait.Filename = encrypted_files_list.SelectedItems[0].SubItems[0].Text;
				wait.Path = encrypted_files_list.SelectedItems[0].SubItems[2].Text;
				wait.Password = Login.Text;
				wait.ShowDialog();
				
				
				Database database1 = new Database(Encrypted_Files_file.FilePath);
				database1.query("UPDATE encrypted SET status = 'encrypted' WHERE path = '"
				                +encrypted_files_list.SelectedItems[0].SubItems[2].Text+"'");
				
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM encrypted");
				encrypted_files_list.Items.Clear();
				while(folderReader.Read())
				{
					encrypted_files_list.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["name"].ToString(),
								folderReader["description"].ToString(),
								folderReader["path"].ToString(),
								folderReader["status"].ToString()
							}
						)
					);
					
				}
				database1.Close();
			}
			catch (ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a file to complete this operation");
			}
			catch(FileNotFoundException fnfe)
			{
				MessageBox.Show(fnfe.Message);
			}
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
		}
		
		/// <summary>
		/// Button decrypts the selected file
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Decrypt_file_buttonClick(object sender, EventArgs e)
		{
			
			childThread.Abort();
			
			try
			{
				WaitingDialog wait = new WaitingDialog();
				
				wait.ActionLabel.Text = "Decrypting";
				wait.Filename = encrypted_files_list.SelectedItems[0].SubItems[0].Text;
				wait.Path = encrypted_files_list.SelectedItems[0].SubItems[2].Text;
				wait.Password = Login.Text;
				
				wait.ShowDialog();
				
				Database database1 = new Database(Encrypted_Files_file.FilePath);
				database1.query("UPDATE encrypted SET status = 'decrypted' WHERE path = '"
				                +encrypted_files_list.SelectedItems[0].SubItems[2].Text+"'");
				
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM encrypted");
				encrypted_files_list.Items.Clear();
				while(folderReader.Read())
				{
					encrypted_files_list.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["name"].ToString(),
								folderReader["description"].ToString(),
								folderReader["path"].ToString(),
								folderReader["status"].ToString()
							}
						)
					);
					
				}
				database1.Close();
			}
			catch (ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a file to complete this operation");
			}
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
		}
		
		/// <summary>
		/// Refresh the list of encrypted files
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Encryption_refresh_buttonClick(object sender, EventArgs e)
		{
			encrypted_files_list.Items.Clear();
			Database database1 = new Database(Encrypted_Files_file.FilePath);
			String sql = "SELECT * FROM encrypted";
			
			SQLiteDataReader folderReader = database1.fetch(sql);
			
			while(folderReader.Read())
			{
				encrypted_files_list.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["name"].ToString(),
							folderReader["description"].ToString(),
							folderReader["path"].ToString(),
							folderReader["status"].ToString()
						}
					)
				);
			}
			database1.Close();			
		}
		
		/// <summary>
		/// Refresh a profiles list
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Refresh_profiles_buttonClick(object sender, EventArgs e)
		{
			profiles_list_View.Items.Clear();
			
			Files Profiles_file_temp = new Files("Hidden","2000400.bin");
			
			Database database1;
			
			if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
			{
				database1 = new Database(Profiles_file.FilePath,user_password);
			}
			else
			{
				database1 = new Database(Profiles_file.FilePath);
			}
			
			String sql = "SELECT * FROM profiles";
			
			try
			{
				SQLiteDataReader folderReader = database1.fetch(sql);
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				
			}
			catch(NullReferenceException)
			{
				return;
			}
			database1.Close();				
		}
		
		/// <summary>
		/// Edit a selected item from the list of profiles 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Profiles_edit_buttonClick(object sender, EventArgs e)
		{
			try 
			{
				childThread.Abort();
				
				Add_Profile_Dialog add_profile_dialog = new Add_Profile_Dialog();
				add_profile_dialog.Profile = profiles_list_View.SelectedItems[0].SubItems[3].Text;
				add_profile_dialog.ShowDialog(this);
				
				profiles_list_View.Items.Clear();
				
				Files Profiles_file_temp = new Files("Hidden","2000400.bin");
				
				Database database1;
				
				if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
				{
					database1 = new Database(Profiles_file.FilePath,user_password);
				}
				else
				{
					database1 = new Database(Profiles_file.FilePath);
				}
				
				String sql = "SELECT * FROM profiles";
				
				SQLiteDataReader folderReader = database1.fetch(sql);
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				
				childThread = new Thread(childref);
				childThread.Start();
				stopwatch.Restart();
			} 
			catch (ArgumentOutOfRangeException) 
			{	
				MessageBox.Show("Please select a profile to complete this operation");
			}
		}
		
		/// <summary>
		/// Remove a selected item from the list of profiles
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Profiles_remove_buttonClick(object sender, EventArgs e)
		{
			Files Profiles_file_temp = new Files("Hidden","2000400.bin");
			
			Database database1;
			
			if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
			{
				database1 = new Database(Profiles_file.FilePath,user_password);
			}
			else
			{
				database1 = new Database(Profiles_file.FilePath);
			}
			
			try
			{
				database1.query("DELETE FROM profiles WHERE id = '"+profiles_list_View.SelectedItems[0].SubItems[3].Text+"'");
				
				SQLiteDataReader folderReader = database1.fetch("SELECT * FROM profiles");
				profiles_list_View.Items.Clear();
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
				database1.Close();		
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a profile for this operation","Error");
			}		
		}
		
		/// <summary>
		/// Add profile information to the list of profiles
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Profiles_add_buttonClick(object sender, EventArgs e)
		{
			childThread.Abort();
			
			Add_Profile_Dialog add_profile_dialog = new Add_Profile_Dialog();
			add_profile_dialog.Profile = "";
			add_profile_dialog.ShowDialog(this);
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
			
			Files Profiles_file_temp = new Files("Hidden","2000400.bin");
			
			Database database1;
			
			if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
			{
				database1 = new Database(Profiles_file.FilePath,user_password);
			}
			else
			{
				database1 = new Database(Profiles_file.FilePath);
			}
			
			SQLiteDataReader folderReader = database1.fetch("SELECT * FROM profiles");
			profiles_list_View.Items.Clear();
			
			while(folderReader.Read())
			{
				profiles_list_View.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["service"].ToString(),
							folderReader["username"].ToString(),
							folderReader["password"].ToString(),
							folderReader["id"].ToString()
						}
					)
				);
			}
			database1.Close();
		}
		
		/// <summary>
		/// Opens an non encrypted file
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Encrypted_files_listSelectedIndexChanged(object sender, EventArgs e)
		{
			childThread.Abort();
			
			try
			{
				Add_File_Dialog add_file_dialog = new Add_File_Dialog();
				add_file_dialog.Filepath = encrypted_files_list.SelectedItems[0].SubItems[2].Text;
				add_file_dialog.ShowDialog(this);
				
				encrypted_files_list.Items.Clear();
				Database database1 = new Database(Encrypted_Files_file.FilePath);
				String sql = "SELECT * FROM encrypted";
				
				SQLiteDataReader folderReader = database1.fetch(sql);
				
				while(folderReader.Read())
				{
					encrypted_files_list.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["name"].ToString(),
								folderReader["description"].ToString(),
								folderReader["path"].ToString(),
								folderReader["status"].ToString()
							}
						)
					);
				}
				database1.Close();
				
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Before cliking on this item, please select a file from the list");
			}
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
		}
		
		/// <summary>
		/// When a file is draged to the list of files for encryption then open the dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Encrypted_files_listDragEnter(object sender, DragEventArgs e)
		{
			DragDropEffects effects = DragDropEffects.None;
			if(e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string path = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
				
				if(File.Exists(path))
				{
					effects = DragDropEffects.Copy;
					
					childThread.Abort();
					
					Add_File_Dialog add_file_dialog = new Add_File_Dialog();
					add_file_dialog.Filepath = path;
					add_file_dialog.ShowDialog(this);
					
					encrypted_files_list.Items.Clear();
					Database database1 = new Database(Encrypted_Files_file.FilePath);
					String sql = "SELECT * FROM encrypted";
					
					SQLiteDataReader folderReader = database1.fetch(sql);
					
					while(folderReader.Read())
					{
						encrypted_files_list.Items.Add(
							new ListViewItem(
								new string[]
								{
									folderReader["name"].ToString(),
									folderReader["description"].ToString(),
									folderReader["path"].ToString(),
									folderReader["status"].ToString()
								}
							)
						);
					}
					database1.Close();
			
					childThread = new Thread(childref);
					childThread.Start();
					stopwatch.Restart();
				}
				e.Effect = effects;
			}			
		}
		
		/// <summary>
		/// Open an edit dialog
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Profiles_list_ViewSelectedIndexChanged(object sender, EventArgs e)
		{
			childThread.Abort();
			try 
			{
				Add_Profile_Dialog add_profile_dialog = new Add_Profile_Dialog();
				add_profile_dialog.Profile = profiles_list_View.SelectedItems[0].SubItems[3].Text;
				add_profile_dialog.ShowDialog(this);
				
				profiles_list_View.Items.Clear();
				
				Files Profiles_file_temp = new Files("Hidden","2000400.bin");
				
				Database database1;
				
				if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
				{
					database1 = new Database(Profiles_file.FilePath,user_password);
				}
				else
				{
					database1 = new Database(Profiles_file.FilePath);
				}
				
				String sql = "SELECT * FROM profiles";
				
				SQLiteDataReader folderReader = database1.fetch(sql);
				
				while(folderReader.Read())
				{
					profiles_list_View.Items.Add(
						new ListViewItem(
							new string[]
							{
								folderReader["service"].ToString(),
								folderReader["username"].ToString(),
								folderReader["password"].ToString(),
								folderReader["id"].ToString()
							}
						)
					);
				}
			} 
			catch (ArgumentOutOfRangeException) 
			{	
				MessageBox.Show("Please select a profile to complete this operation");
			}
			catch (Exception){}
			
			childThread = new Thread(childref);
			childThread.Start();
			stopwatch.Restart();
		}
		
		/// <summary>
		/// Search for the items that the user is looking for
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void ProfilesSearchTextBoxTextChanged(object sender, EventArgs e)
		{
			Files Profiles_file_temp = new Files("Hidden","2000400.bin");
			
			Database database1;
			
			if(!Profiles_file.FilePath.Equals(Profiles_file_temp.FilePath))
			{
				database1 = new Database(Profiles_file.FilePath,user_password);
			}
			else
			{
				database1 = new Database(Profiles_file.FilePath);
			}
			
			String sql = "SELECT * FROM profiles " +
				"WHERE service LIKE '%"+profilesSearchTextBox.Text+"%'" +
				" OR username LIKE '%"+profilesSearchTextBox.Text+"%'" +
				" OR password LIKE '%"+profilesSearchTextBox.Text+"%'";
				
			SQLiteDataReader folderReader = database1.fetch(sql);
			profiles_list_View.Items.Clear();
			
			while(folderReader.Read())
			{
				profiles_list_View.Items.Add(
					new ListViewItem(
						new string[]
						{
							folderReader["service"].ToString(),
							folderReader["username"].ToString(),
							folderReader["password"].ToString(),
							folderReader["id"].ToString()
						}
					)
				);
			}
			database1.Close();				
		}
		
		/// <summary>
		/// Opens a file that is to be encrypted
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void OpenEncryptionFileButtonClick(object sender, EventArgs e)
		{
			try
			{
				System.Diagnostics.Process.Start(encrypted_files_list.SelectedItems[0].SubItems[2].Text);
			}
			catch(ArgumentOutOfRangeException)
			{
				MessageBox.Show("Please select a file for this operation","Error");
			}		
			catch(Win32Exception)
			{
				MessageBox.Show("Error opening the file, the file might be encrypted or deleted","Error");
			}			
		}
		
		/// <summary>
		/// Close the baby thread here
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void MainFormFormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				if(childThread.IsAlive && (stopwatch.ElapsedMilliseconds <= 120000))
				{
					childThread.Abort();
				}
			}
			catch(ThreadStateException tse)
			{
				MessageBox.Show(tse.Message);
			}
		}
	}
}