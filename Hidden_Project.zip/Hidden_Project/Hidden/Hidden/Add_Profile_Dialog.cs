﻿/*
 * Created by SharpDevelop.
 * User: USER
 * Date: 11/19/2018
 * Time: 12:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace Hidden
{
	/// <summary>
	/// Description of Add_Profile_Dialog.
	/// </summary>
	public partial class Add_Profile_Dialog : Form
	{
		public Add_Profile_Dialog()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			Profiles_list_database = new Database(Profiles_file.FilePath);
			
			this.profile = "";
			
			childref = new ThreadStart(LockOutTimer);
			childThread = new Thread(childref);
			childThread.Start();
		}
		
		/// <summary>
		/// Child thread to lockout the user
		/// </summary>
		private ThreadStart childref;
		private Thread childThread;
		
		/// <summary>
		/// Lockout the user if not active
		/// </summary>
		private void LockOutTimer()
		{
			Thread.Sleep(60000);
			
			if(InvokeRequired)
			{
				
				Invoke(new MethodInvoker(CloseTheForm));
			}
			else
			{
				CloseTheForm();
			}
		}
				
		private void CloseTheForm()
		{
			Close();
		}
		
		/// <summary>
		/// The profile that the user has selected from the main form
		/// </summary>
		public string Profile 
		{
			get { return profile; }
			set { this.profile = value; }
		}
		private string profile;
		/// <summary>
		/// The database file that contains the list of profile information for 
		/// internet services, like facebook and google. Takes password and username or email
		/// </summary>
		Files Profiles_file = new Files("Hidden","2000400.bin");
		
		/// <summary>
		/// Open the database when the window is initialised
		/// </summary>
		Database Profiles_list_database;
		
		/// <summary>
		/// Add a profile to the list of profiles
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Save_profileClick(object sender, EventArgs e)
		{
			if(
				serviceNameTextBox.Text.Equals("") ||
			  	usernameTextBox.Text.Equals("") ||
			  	passwordTextBox.Text.Equals("")
			  )
			{
				return;
			}
			if(Profile.Equals(""))
			{
				Profiles_list_database.query("INSERT INTO profiles (service,username,password) " +
				                             "VALUES ('"+serviceNameTextBox.Text+"', '"+usernameTextBox.Text+"', '"+passwordTextBox.Text+"')");
			}
			else
			{
				Profiles_list_database.query("DELETE FROM profiles WHERE id = '"+Profile+"'");
				Profiles_list_database.query("INSERT INTO profiles (service,username,password) " +
				                             "VALUES ('"+serviceNameTextBox.Text+"', '"+usernameTextBox.Text+"', '"+passwordTextBox.Text+"')");
			}
			Close();
		}
		
		/// <summary>
		/// Edit items that are in the list of profiles
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_Profile_DialogLoad(object sender, EventArgs e)
		{
			if(!Profile.Equals(""))
			{
				Text = "Edit Profile";
				SQLiteDataReader profiles_reader = Profiles_list_database.fetch("SELECT * FROM profiles WHERE id = '"+Profile+"'");
				
				while(profiles_reader.Read())
				{
					serviceNameTextBox.Text = serviceNameTextBox.Text + profiles_reader["service"];
					usernameTextBox.Text = usernameTextBox.Text + profiles_reader["username"];
					passwordTextBox.Text = passwordTextBox.Text + profiles_reader["password"];
				}
				profiles_reader.Close();
			}
		}
		
		/// <summary>
		/// Close the database as the window closes
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void Add_Profile_DialogFormClosed(object sender, FormClosedEventArgs e)
		{
			Profiles_list_database.Close();
			childThread.Abort();
		}
	}
}
