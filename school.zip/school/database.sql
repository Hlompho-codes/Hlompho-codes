/** To import statements from sql file type : (\.) Execute an SQL script file. Takes a file name as an argument.**/
CREATE TABLE users
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    firstname VARCHAR(50), 
    lastname VARCHAR(50), 
    email VARCHAR(50),
    password VARCHAR(50),
    verification VARCHAR(50),
    user_type VARCHAR(20),
    PRIMARY KEY(id) 
);

CREATE TABLE school
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    school_name VARCHAR(50),
    school_type VARCHAR(50),
    email VARCHAR(50),
    postal_address VARCHAR(50),
    physical_address VARCHAR(50),
    phone_numbers VARCHAR(50),
    coordinates VARCHAR(50),
    PRIMARY KEY(id) 
);

CREATE TABLE users_schools
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    user_email VARCHAR(50),
    user_type VARCHAR(50),
    school_name VARCHAR(50),
    PRIMARY KEY(id)
);

CREATE TABLE staff
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    firstname VARCHAR(50), 
    lastname VARCHAR(50), 
    email VARCHAR(50),
    phone VARCHAR(50),
    school VARCHAR(50),
    job VARCHAR(50),
    employed_since VARCHAR(50),
    highest_qulifications VARCHAR(50),
    PRIMARY KEY(id) 
);

CREATE TABLE sessions
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    email VARCHAR(50),
    time_logged VARCHAR(4),
    PRIMARY KEY(id)
);
CREATE TABLE user_time_out_settings
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    email VARCHAR(50),
    time_out VARCHAR(4),
    PRIMARY KEY(id)
);
CREATE TABLE user_message_settings
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    email VARCHAR(50),
    email_mailbox VARCHAR(4),
    website_mailbox VARCHAR(4),
    PRIMARY KEY(id)
);
CREATE TABLE levels
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    level_name VARCHAR(50),
    duration VARCHAR(50),
    school VARCHAR(50),
    PRIMARY KEY(id)
);
CREATE TABLE courses
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    course_name VARCHAR(50),
    level_name VARCHAR(50),
    school_name VARCHAR(50),
    teacher_name VARCHAR(50),
    PRIMARY KEY(id)
);
CREATE TABLE students_personal_information
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    student_first_name VARCHAR(50),
    student_middle_name VARCHAR(50),
    student_last_name VARCHAR(50),
    student_maiden_names VARCHAR(50),
    date_of_birth VARCHAR(50),
    citizenship VARCHAR(50),
    country VARCHAR(50),
    Gender VARCHAR(15),
    user_that_makes_application VARCHAR(50),
    school_names VARCHAR(50),
    student_national_identity VARCHAR(50),
    student_national_identity_type VARCHAR(50),
    student_school_identity VARCHAR(50),
    student_phone VARCHAR(50),
    student_email VARCHAR(50),
    student_physical_address VARCHAR(50),
    next_of_kin_names VARCHAR(50),
    next_of_kin_student_relationship VARCHAR(50),
    next_of_kin_address VARCHAR(50),
    next_of_kin_email VARCHAR(50),
    next_of_kin_phone VARCHAR(50),
    disablities VARCHAR(5),
    disablities_nature VARCHAR(255),
    disabled_needs VARCHAR(255),
    PRIMARY KEY(id)
);
CREATE TABLE programmes_the_student_applied_for
(
    id MEDIUMINT NOT NULL,
    programme_of_choice VARCHAR(255),
    PRIMARY KEY(id)
);
CREATE TABLE qualifications_of_the_student
(
    id MEDIUMINT NOT NULL,
    last_school_name VARCHAR(50),
    last_class VARCHAR(50),
    certificate_obtained VARCHAR(50),
    PRIMARY KEY(id)
);
CREATE TABLE students_references
(
    id MEDIUMINT NOT NULL,
    reference_name VARCHAR(50),
    reference_Occupation VARCHAR(50),
    reference_phone_numbers VARCHAR(50),
    reference_email VARCHAR(50),
    PRIMARY KEY(id)
);
CREATE TABLE students_sponsor
(
    id MEDIUMINT NOT NULL,
    sponsor_type VARCHAR(50),
    sponsor_name VARCHAR(50),
    sponsor_phone VARCHAR(50),
    sponsor_email VARCHAR(50),
    student_enrol_date VARCHAR(50),
    status VARCHAR(50),
    PRIMARY KEY(id)
);
CREATE TABLE marks
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    course_name VARCHAR(50),
    levels_name VARCHAR(50),
    marks_list VARCHAR(255),
    assessment_name VARCHAR(255),
    PRIMARY KEY(id)
);
CREATE TABLE groups
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    group_name TEXT,
    group_leader_teacher TEXT,
    group_leader_student TEXT,
    current_year TEXT,
    school_name TEXT,
    level_name TEXT,
    PRIMARY KEY(id)
);
CREATE TABLE messages
(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    recipient TEXT,
    sender TEXT,
    subject TEXT,
    message TEXT,
    dates TEXT,
    read_status TEXT,
    PRIMARY KEY(id)
);