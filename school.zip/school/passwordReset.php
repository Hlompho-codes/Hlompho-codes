<?php
$GLOBALS['message'] = "";
$GLOBALS['mail'] = "";

include("assets/classes/Database.php");
$database = Connect();

if(filter_input(INPUT_GET, "m") !== null)
{
    $GLOBALS['mail'] = $database->Fetch("users", "verification", filter_input(INPUT_GET, "m"), "email");
}
if(filter_input(INPUT_POST, "submit") === "Reset password")
{
    if(filter_input(INPUT_POST, "password") === filter_input(INPUT_POST, "passwordConfirmation"))
    {
        $GLOBALS['message'] = $database->Update("users", "email", filter_input(INPUT_POST, "email"), "password", filter_input(INPUT_POST, "passsword")) ? "You have successfully reset your password, sign in <a href='index.php'>here</a>" : "Your password reset was not successfull, please try again";
    }
    else 
    {
        $GLOBALS['message'] = "Password and password confirmation do not match, please try again";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="assets/img/logo.png" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
        <title>reset your password here</title>
    </head>
    <body>
        <div class="container">
            <div class="col-lg-4 col-md-4 col-sm-4"></div>
            <div class="col-lg-4 col-md-4 col-sm-4" style="padding-top:10%">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Reset your password here<?php echo($GLOBALS['mail']); ?>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" action="passwordReset.php" method="post">
                            <div class="form-group-lg" style="padding:20px">
                                <input class="hidden" type="hidden" name="email" value="<?php echo($GLOBALS['mail']); ?>"/>
                                <input class="form-control" type="password" placeholder="password" name="password" title="Enter your new password here"/>
                            </div>
                            <div class="form-group-lg" style="padding:20px">
                                <input class="form-control" type="password" placeholder="passwordConfirmation" name="passwordConfirmation" title="Renter your password here" required/>
                            </div>
                            <div class="form-group-sm" style="padding:20px">
                                <input class="form-control btn-group-lg btn-info" style="width: 105px;" type="submit" name="submit" value="Reset password" required/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4"></div>
        </div>
        <!-----------Info modal----------------->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Information</h4>
                    </div>
                    <div class="modal-body" id="infoModalText"><?php echo($GLOBALS['message']) ?></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-----------reminder modal----------------->        
    </body>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.min.js">
    </script><script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <script type="text/javascript">
        $('document').ready(function(){
            if($('#infoModalText').text()!=="")
            {
                $('#infoModal').modal('show'); 
            }
        });
    </script>
</html>