<?php
session_start();
session_destroy();
unset($_SESSION['email']);
unset($_SESSION['password']);

if(session_status() == PHP_SESSION_ACTIVE)
{
    echo("<script>alert('Log off unsuccessful')</script>");
    echo("<script>window.history.back()</script>");
}
else 
{
    settype($header_str, "string");
    $header_str = (string)@$_GET['msg'];
    if($header_str === "")
    {
        echo("<script>document.location = './'</script>");
    }
    else
    {
        echo("<script>document.location = './?msg=".$header_str."'</script>");
    }
}
