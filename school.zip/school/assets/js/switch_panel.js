$("a[@data-toggle=switch_panel_toggle]").on("click tapstart",function(){
    //if()
    $("div[.switch_panel]").fadeOut(250);
    $("div[id="+$(this).attr("id")+"]").fadeIn(250);
});

