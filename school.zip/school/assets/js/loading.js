window.addEventListener("beforeunload",function(e)
{
    //e.preventDefault();
    document.getElementById("load").style.display = "block";
    delete e['returnValue'];
});