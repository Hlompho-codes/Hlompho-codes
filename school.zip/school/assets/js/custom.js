/**
 * Affix
 */
$('#student_application_nav').affix({
    offset: 
    {
        top: 1
    }
}).on("affix.bs.affix",function()
{ 
    $('#student_application_nav').width($('#student_application_nav').parent().innerWidth()-10);
});

/**
 * closes panels
 */
$(".close").on("click tapstart",function(){
    $("#ajax_response").fadeOut(500);
});
/**
 * Gets the value of a query variable that as been provided as a parameter to the function
 * @param {string} variable
 * @returns {GetQueryVariable.pair|String}
 */
function GetQueryVariable(variable)
{
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for(var i=0;i<vars.length;i++)
    {
        var pair = vars[i].split("=");
        if(pair[0] === variable)
        {
            return pair[1];
        }
    }
    return("");
}

function My_Ajax(Selector, URL)
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState === 4 && this.status === 200) {
        document.getElementById(Selector).innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", URL, true);
    xhttp.send();
}