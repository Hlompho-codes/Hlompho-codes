<?php
//sample7_10.php
//Copyright 2005, Lee Babin (lee@thecodeshoppe.com) 
//This code may be used and redistributed without charge 
//under the terms of the GNU General Public 
//License version 2.0 or later -- www.gnu.org 
//Subject to the retention of this copyright 
//and GPL Notice in all copies or derived works
class File 
{
    
    //The path to the file you want to work with. 
    protected $thepath;

    //Error messages in the form of constants for ease of use. 
    const FOUNDERROR = "Sorry, the file in question does not exist."; 
    const PERMERROR = "Sorry, you do not have the proper permissions on this file"; 
    const OPENERROR = "Sorry, the file in question could not be opened."; 
    const CLOSEERROR = "Sorry, the file could not be closed.";

    //Instead of printing text we can just store it in this variable
    protected $Message = "";
    
    /**
     * Points to a file
     * @var type file handler
     */
    protected $filepointer;
    
    //The constructor function. 
    public function __construct ()
    {
        $num_args = func_num_args();
        if($num_args > 0)
        {
            $args = func_get_args(); 
            $this->thepath = $args[0]; 
        }
        $this->filepointer = null;
    }

    //A function to open the file.
    private function openfile ($readorwrite)
    { 
        //First, ensure the file exists. 
        try 
        { 
            if(file_exists ($this->thepath))
            { 
                //Now, you need to see if you are reading or writing or both. 
                $proceed = false; 
                if ($readorwrite == "r")
                { 
                    if (is_readable($this->thepath))
                    { 
                        $proceed = true; 
                    } 
                } 
                elseif ($readorwrite == "w")
                { 
                    if (is_writable($this->thepath))
                    { 
                        $proceed = true;
                    }
                }
                else
                { 
                    if(is_readable($this->thepath) && is_writable($this->thepath))
                    {
                        $proceed = true;
                    }
                } 
                try 
                { 
                    if ($proceed)
                    { 
                        //You can now attempt to open the file. 
                        try 
                        { 
                            if($this->filepointer = fopen ($this->thepath, $readorwrite))
                            { 
                                return $this->filepointer; 
                            } 
                            else 
                            { 
                                throw new exception (self::OPENERROR); 
                                return false; 
                            }
                            
                        }
                        catch (exception $e) 
                        { 
                            $this->SetMessage($e->getmessage()); 
                        }
                    } 
                    else 
                    { 
                        throw new exception (self::PERMERROR); 
                    } 
                } 
                catch (exception $e) 
                { 
                    $this->SetMessage($e->getmessage()); 
                } 
            } 
            else 
            { 
                throw new exception (self::FOUNDERROR); 
            } 
        } 
        catch (exception $e) 
        { 
            $this->SetMessage($e->getmessage()); 
        }
    }

    //A function to close a file. 
    function closefile ()
    {
        if($this->filepointer !== NULL)
        {
            try 
            { 
                if (!fclose($this->filepointer))
                { 
                    throw new exception (self::CLOSEERROR); 
                } 
            } 
            catch (exception $e) 
            { 
                $this->SetMessage($e->getmessage());
            }
        }
    }
    
    //A function to read a file, then return the results of the read in a string. 
    public function read () 
    { 
        //First, attempt to open the file. 
        $this->filepointer = $this->openfile ("r");
        
        //Now, return a string with the read data.
        if ($this->filepointer != false)
        { 
            //Then you can read the file.
            return fread($this->filepointer,filesize ($this->thepath));
        }
        //Lastly, close the file. 
        $this->closefile ();
    }

    //A function to write to a file. 
    public function write ($towrite) 
    {   
        //First, attempt to open the file. 
        $this->filepointer = $this->openfile ("w");
        //Now, return a string with the read data. 
        if ($this->filepointer != false)
        { 
            //Then you can read the file. 
            return fwrite($this->filepointer, $towrite);
        }
        //Lastly, close the file. 
        $this->closefile ();
    }
    
    //A function to append to a file. 
    public function append ($toappend) 
    { 
        //First, attempt to open the file. 
        $this->filepointer = $this->openfile ("a");
        //Now, return a string with the read data. 
        if ($this->filepointer != false)
        { 
            //Then you can read the file. 
            return fwrite ($this->filepointer, $toappend); 
        }
        
        //Lastly, close the file. 
        $this->closefile ();
    }
    public function ListFilesInDir($thedir)
    {
        $array = array();
        if(is_dir($thedir))
        {
            $scanarray = scandir($thedir);
            for ($i = 0; $i < count($scanarray); $i++)
            {
                if((count(str_split($scanarray[$i])) > 3) and is_file ($thedir."/".$scanarray[$i]))
                {
                    array_push($array,$thedir."/".$scanarray[$i]);
                }
            }
            return($array);
        }
        else 
        {
            return(array("-1"));
        }
    }
    public function ListFoldersInDir($thedir)
    {
        $array = array();
        if(is_dir($thedir))
        {
            $scanarray = scandir($thedir);
            for ($i = 0; $i < count($scanarray); $i++)
            {
                if(is_dir($thedir."/".$scanarray[$i]))
                {
                    array_push($array,$thedir."/".$scanarray[$i]);
                }
            }
            return($array);
        }
        else 
        {
            return(array("-1"));
        }
    }
    //A function to set the path to a new file. 
    public function setpath ($newpath) 
    { 
        $this->thepath = $newpath; 
    }
    public final function GetPath() 
    {
        return($this->filepointer);
    }
    /**
     * Retrieves the text of the message string
     * @return type String
     */
    public final function GetMessage() 
    {
        return($this->Message);
    }
    
    /**
     * Sets a message text
     * @param type String
     */
    public function SetMessage($message)
    {
        $this->Message = $message;
    }
    
    /**
     * Closes the file
     */
    public function __destruct() 
    {
        $this->closefile();
    }
}