<?php
/**
 * The class extends MySqli class
 * @author USER
 */
class Database extends mysqli
{
    /**
     * Connects to mysql database
     * the name of the database to connect to
     * @param type $host
     * @param type $user
     * @param type $password
     * @param type $database
     */
    function __construct($host = "",$user = "",$password = "",$database = "")
    {
        parent::__construct($host, $user, $password, $database);
    }
    
    /**
     * Closes the connection to the database
     */
    function __destruct()
    {
        parent::close();
    }
    
    /**
     * Inserts values into the table $values is string array 
     * @param type $table
     * @param type $values
     * @return boolean
     */
    function Insert($table, $values)
    {
        $str_values = "";
        foreach ($values as $value)
        {
            $str_values = $str_values."'$value',";
        }
        $str = substr_replace($str_values, "", strlen($str_values) - 1);
        $res_string = parent::query("INSERT INTO $table VALUES (0,$str)");
        return($res_string);
    }
    
    /**
     * Fetches one row of a table from the database
     * @param type $table
     * @param type $where
     * @param type $whereValue
     * @param type $what
     * @return string array
     */
    function Fetch($table, $where = "", $whereValue = "", $what = "*")
    {
        $arr = array(array());
        if($where == "")
        {
            $result = parent::query("SELECT $what FROM $table");
        }
        else
        {            
            $result = parent::query("SELECT $what FROM $table WHERE $where = '$whereValue'");
        }
        
        if($result === false)
        {
            echo($this->error);
        }
        
        while($data = $result->fetch_array())
        {
            $arr = array_merge($data);
        }
        return($arr);
    }
    
    /**
     * Executes a MYSQL query
     * @param type String
     * @return type mixed
     */
    function Query($query_str, $resultmode = NULL)
    {
        return(parent::query($query_str, $resultmode = NULL));
    }   
    
    /**
     * Updates fields on the table
     * @param type $table
     * @param type $where
     * @param type $whereValue
     * @param type $what
     * @param type $whatValue
     * @return boolean
     */
    function Update($table,$where,$whereValue,$what,$whatValue)
    {
        if($where == "")
        {
            return(parent::query("UPDATE FROM $table SET $what = $whatValue"));
        }
        else
        {
            return(parent::query("UPDATE FROM $table WHERE $where = $whereValue SET $what = $whatValue"));
        }
    }
    
    /**
     * Deletes a row from the database
     * @param type $table
     * @param type $where
     * @param type $whereValue
     * @return boolean
     */
    function Delete($table,$where,$whereValue)
    {
        if($where == "")
        {
            return(parent::query("DELETE FROM $table"));
        }
        else
        {
            return(parent::query("DELETE FROM $table WHERE $where = $whereValue"));
        }
    }
    
    /**
     * Returns the number of rows from the table
     * @param type $table
     * @return integer
     */
    function RowCount($table)
    {
        $rows = 0;
        $result = parent::query("SELECT * FROM $table");
        while($data = $result->fetch_array())
        {
            $rows = $rows + 1;
        }
        return($rows);
    }
}

/**
 * Create a database connection to avoid having 
 * to instantiate the class in every file
 * @return type mysqli
 */
function Connect() 
{
    return(new Database("localhost","root","","school"));
}

/**
 * Create a database connection for the first time
 * @return type mysqli
 */
function Connect_For_The_First_Time() 
{
    return(new Database("localhost","root","",""));
}