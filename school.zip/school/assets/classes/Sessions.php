 <?php
class Sessions
{
    static function SetSession() 
    {
        $mysqli = Connect();
        $mysqli->Query("SELECT email FROM sessions where email = '".@$_SESSION['email']."'");
        if($mysqli->affected_rows != 1)
        {
            $mysqli->Query("INSERT INTO sessions VALUES(0,'".@$_SESSION['email']."','".date("i")."')");
            if($mysqli->affected_rows >= 1) {return(TRUE);} else {return(FALSE);}
        }
        else 
        {
           $mysqli->Query("UPDATE sessions SET time_logged = '".date("i")."' WHERE email = '".@$_SESSION['email']."'");
            if($mysqli->affected_rows >= 1){return(TRUE);}else{return(FALSE);}}
    }
    static function ResetTimeout()
    {
        $mysqli = Connect();
        $mysqli->Query("SELECT email FROM sessions where email = '".@$_SESSION['email']."'");
        if($mysqli->affected_rows >= 1)
        {
            $mysqli->Query("UPDATE sessions SET time_logged = '".date("i")."' WHERE email = '".@$_SESSION['email']."'");
            if($mysqli->affected_rows >= 1){return(TRUE);}else{return(FALSE);}
        }
        else 
        {
            return(FALSE);
        }
    }
    static function IsTimeOut()
    {
        $mysqli = Connect();
        $result1 = $mysqli->Query("SELECT time_logged FROM sessions WHERE email = '".@$_SESSION['email']."'");
        $data = $result1->fetch_array()['time_logged'];
        $difference = intval(date("i")) - intval($data);
        if($difference >= 10)
        {
            return(TRUE);
        }
        else 
        {
            return(FALSE);
        }
    }
    static function DeleteSession()
    {
        $mysqli = Connect();
        $mysqli->Query("SELECT email FROM sessions where email = '".@$_SESSION['email']."'");
        if($mysqli->affected_rows >= 1)
        {
            $mysqli->Query("DELETE FROM sessions WHERE email = '".@$_SESSION['email']."'");
            if($mysqli->affected_rows > 1)   
            {return(TRUE);}else{return(FALSE);}
        }
        else
        {
            return(FALSE);
        }
    }
}
/**
 * Creates a new session for the user
 */
function CreateSession()
{
    return(Sessions::SetSession());
}
/**
 * Checks weather to kill the session or not
 * @return type Boolean
 */
function KillSession()
{
    
    if(Sessions::IsTimeOut())
    {
        return(TRUE);
    }
    else
    {
        Sessions::ResetTimeout();
        return(FALSE);
    }
}