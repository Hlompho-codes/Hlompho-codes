<?php
/**
 * C_print allows the user to print "echo()" printed string as an overlay dialog
 * @author Hlompho Sebolao
 */
class Modal_print 
{
   function Print_String($heading = "",$string)
   {
   $string_default = <<<eof
        <div id="overlay_modal" style="padding:10px;position: fixed;display: none;width: 100%;height: 100%;top: 0;left: 0;right: 0;bottom: 0;background-color: rgba(0,0,0,0.5);z-index: 10;cursor:  progress;">
            <div style="position: absolute;top: 50%;left: 46%;color: black;transform: translate(-50%,-50%);-ms-transform: translate(-50%,-50%);">
                <div style="background-color:white;width: 150%;height: 50%;padding: 10px;">
                    <center>
                    <div><h4>$heading</h4></div>
                    <hr/>
                    $string
                    <br/>
                    <hr/>
                    
                    </center>
                    <button style="width:50px;hight:30px;margin-left: 85%" onclick="RemoveDialog()">Close</button>
                </div> 
            </div>
        </div>
        <script>
            document.getElementById("overlay_modal").style.display = "block";
            function RemoveDialog()
            {
                document.getElementById("overlay_modal").style.display = "none";
            }
        </script>
eof;
       return($string_default);
   }
}
function modal_print($heading,$string)
{
    $print = new Modal_print($string);
    echo($print->Print_String($heading,$string));
}