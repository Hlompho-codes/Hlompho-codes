<?php
session_start();
$GLOBALS['message'] = "";
$GLOBALS['$proceed_menu_text'] = "";

include("assets/classes/Database.php");
include("assets/classes/Sessions.php");
if(isset($_SESSION['email']) and isset($_SESSION['password']))
{
    $GLOBALS['message'] = "You are still logged on, procced to <a href='member_area/'>members area</a>";
    $GLOBALS['$proceed_menu_text'] = $_SESSION['email'];
}

$GLOBALS['message'] = @$_GET['msg'];

$database = @Connect();
if(Connect()->connect_errno >= 1)
{
    header("location:install.php");
}

//If login button is clicked
if(filter_input(INPUT_POST, "login") == "login")
{
    $MyPasswordResult = $database->Query("SELECT password FROM users WHERE email = '".filter_input(INPUT_POST, "email")."'");
    $MyEmailResult = $database->Query("SELECT email FROM users WHERE password = '".filter_input(INPUT_POST, "password")."'");
    
    $email = $MyEmailResult->fetch_array()['email'];
    $password = $MyPasswordResult->fetch_array()['password'];
    
    if(gettype($email) != "string")
    {
        $GLOBALS['message'] = "Email not found";
    }
    if(gettype($password) != "string")
    {
        $GLOBALS['message'] = "Password not found";
    }
    
    if($email == filter_input(INPUT_POST, "email") and $password == filter_input(INPUT_POST, "password"))        
    {
        $_SESSION['email'] = filter_input(INPUT_POST, "email");
        $_SESSION['password'] = filter_input(INPUT_POST, "password");
        $GLOBALS['message'] = "Redirecting to members area";
        CreateSession();
        echo("<script>document.location = 'member_area/'</script>");
    }
    else
    {
        $GLOBALS['message'] = "Email and(or) password not found";
    }
}

//if sign up button is clicked
if(filter_input(INPUT_POST, "signup") == "signup")
{
    if(filter_input(INPUT_POST, "password") == filter_input(INPUT_POST, "confirm_password"))
    {
        $arr = array
        (
            filter_input(INPUT_POST, "firstname"),
            filter_input(INPUT_POST, "lastname"),
            filter_input(INPUT_POST, "email"),
            filter_input(INPUT_POST, "password"),
            "USCH". rand(1000, 99000),
            "simple_user"
        );
        $GLOBALS['message'] = $database->Insert("users", $arr) ? "Successfully registered your accound please check you email for verification code" : "$database->error Oops! sign up failed, please try again";
    }
}

//If reset password request is made
if(filter_input(INPUT_POST, "sendEmail") == "Send Email")
{
    $name = $database->Fetch("users", "email", mail(filter_input(INPUT_POST, "sendEmail"), "firstname"))['firstname'];
    $mailMessage = "Dear $name \r\n This message was send to you in response\r\n"
            . "to the password reset request that you have made on Primary.com\r\n"
            . "Bellow is a link to help you get started with resetting your password\r\n"
            . "<a href=\"Primary.com/passwordReset.php?m=USCH".rand(1000, 99000)."\">Primary.com/passwordReset.php?m=USCH". rand(1000, 99000)."\"</a>"
            . "If you do not remember sending this request, then please do not ignore\r\n"
            . "this message because someone might have tried to hack in to your account\r\n"
            . "You can contact us at <email@mail.com> if you feel like there is a suspicious\r\n"
            . "behaviour regarding regarding your aacount.\r\n"
            . "Regards\r\n"
            . "Megegethe Team";
    $GLOBALS['message'] = mail(filter_input(INPUT_POST, "sendEmail"), "Reset your password", $mailMessage) ? "Email send" : "Error sending your email";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="assets/img/logo_brand_no_bg.png" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="assets/css/custom.css" rel="stylesheet"/>
        <script src="assets/js/jquery-1.10.2.js"></script>       
        <script src="assets/js/pace.min.js"></script>        
        <link href="assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
        <!-- MORRIS CHART STYLES-->
        <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- FONTAWESOME STYLES-->
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <link href="assets/css/loading.css" type="text/css" rel="stylesheet">
        <title>Primary : School information management system</title>
    </head>
    <body id="body" style="background-repeat: no-repeat; background-image: url('assets/img/Magegethe_Banner.png');background-size: 100%;">
        <div class="cover"></div>
        <div class="load">
            <div class="loading_gif">
                <img alt="loading" src="assets/img/loading.gif"/>
            </div>
        </div>
        <div class="container">
            <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="./">
                            <u style="color: white;">Magegethe</u>
                        </a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                            <li>
                                <a href="./">Home</a>
                            </li>
                            <li><a href="about.php">About us</a></li>          
                            <li><a class="panel-back" href="contact.php">Contact us</a></li>
                            <li class="divider"></li>
                            <?php if($GLOBALS['$proceed_menu_text'] !== ""): ?>
                            <li class="active">
                                <form class="navbar-form form-inline" id="login_button">
                                    <a class="btn btn-default popover-toggle" data-container="body" 
                                       data-toggle="popover" data-placement="bottom" 
                                       data-content="Proceed as <?php echo($GLOBALS['$proceed_menu_text']); ?>" 
                                       href="member_area/"
                                       style="background-color: #9999ff;
                                       color: #E0E0E0; border: solid white 2px;">
                                        <i class="fa fa-user"></i>&nbsp;Login / Register
                                    </a>
                                </form>
                            </li>
                            <?php endif; ?>
                            <?php if($GLOBALS['$proceed_menu_text'] === ""): ?>
                            <li>
                                <form class="navbar-form form-inline" id="login_button">
                                    <a class="btn btn-default popover-toggle" id="toggleLoginPanel" 
                                       data-content="Login or sign up here" data-placement="bottom" 
                                       data-container="body" data-toggle="popover"
                                       style="background-color: #9999ff;
                                       color: #E0E0E0; border: solid white 2px;">
                                        <i class="fa fa-user"></i>&nbsp;Login / Register
                                    </a>
                                </form>
                            </li>
                            <?php endif; ?>
                        </ul>           
                    </div>
                </div>     
            </nav>
        </div>     
        <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 200px;">
            <div class="col-lg-1 col-md-1 col-sm-12"></div>
            <div class="col-lg-10 col-md-10 col-sm-12">
                <div class="panel panel-default panel-back">
                    <div class="panel-heading text-center">
                        <h4>Get in touch</h4>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="panel panel-default panel-back">
                                <div class="panel-body" id="the_length_i_need">
                                    <div class="text-center">
                                        <i class="fa fa-4x fa-envelope-square"></i>
                                    </div>
                                    <ul class="list-group" style="padding: 25px">
                                        <li>magegethe@gmail.com</li>
                                        <li>magegethe.marketing@gmail.com</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="panel panel-default panel-back">
                                <div class="panel-body" id="the_new_length">
                                    <div class="text-center">
                                        <i class="fa fa-4x fa-phone-square"></i>
                                    </div>
                                    <ul class="list-group" style="padding: 25px">
                                        <li>+266 59 865 676</li>
                                        <li>+266 63 579 819</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="panel panel-default panel-back">
                                <div class="panel-body"id="the_new_length">
                                    <div class="text-center">
                                        <i class="fa fa-4x fa-map-marker"></i>
                                    </div>
                                    <ul class="list-group" style="padding: 25px">
                                        <li>Mapeleng, Ha Mabote 29</li>
                                        <li>Maseru 100, Lesotho</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="panel panel-info panel-back">
                                <div class="panel-heading">
                                    <h3 class="text-center panel-title">Contact us by filling the form bellow</h3>
                                </div>
                                <div class="panel-body">
                                    <!--------------------------------------------------------------------------------------------------------------
                                           For this ajax form to work please download an add this scripts
                                           --------------------------------------------------------------
                                        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.js"></script>
                                        <script src="http://malsup.github.com/jquery.form.js"></script>
                                                   ------------------------------------
                                                   Then add this script to the document
                                                   ------------------------------------
                                                <script src="../assets/js/custom.js"></script>
                                                    -----------------------------------
                                                            Then call the function
                                                    -----------------------------------
                                                    My_JQuery_Form_Ajax('#formId') 
                                    --------------------------------------------------------------------------------------------------------------->
                                    <div id="ajax_response" style="display:none" class="well well-lg">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <div class="progress progress-striped" style="width:100%">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="70"  aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                                <span class="sr-only">0%</span>
                                            </div>
                                        </div>         
                                        <div id="status1"></div>	
                                   </div>
                                    <form class="form-horizontal" style="padding-left: 20%;padding-right: 20%">
                                        <input style="display: none;" type="text" name="recipient" value="admin@magegethe.com"/>
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="email" placeholder="Email"/>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name" placeholder="Name"/>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="subject" placeholder="Subject"/>
                                        </div>
                                        <div class="form-group">
                                            <textarea class="form-control" style="height:200px;" placeholder="Message"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                <input type="submit" class="form-control btn btn-block btn-info" name="submit_from_non_user_message" value="Send message"/>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-1 col-md-1 col-sm-12"></div>
        </div>
        <!------------------------------Footer-------------------------------------->
        <div class=" text-center">
            <div>&copy; 2019 - 2020 Magegethe</div>
            <div>
                <a href="about.php">About us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="contact.php">Contact us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#">Help</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#">Terms of privacy</a>
            </div>
            <div>
                <a href="#"><i class="fa fa-facebook"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#"><i class="fa fa-instagram"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#"><i class="fa fa-twitter"></i></a>
            </div>
        </div> 
        <!----------------------------- Login / signup Modal [new] ----------------------->
        <div class="modal fade" id="LogInModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">
                            <span id="signInHeader">Sign in</span>
                        </h4>
                    </div>
                    <div class="modal-body" id="infoModalText">
                        <div id="signIn" style="padding:20px">
                            <form method="post" class="form-horizontal">
                                <div class="form-group"><input class="form-control" type="text" name="email" placeholder="email" required/></div>
                                <div class="form-group input-group"><input class="form-control" type="password" name="password" id="Password" placeholder="password" autocomplete="off" required/>
                                    <span class="input-group-addon" id="Eye">
                                        <i id="the_eye" class="fa fa-eye"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="Keep_me_logged_in"/>
                                    <span>Keep me logged in</span>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <input class="form-control btn btn-info btn-block" type="submit" name="login" value="login"/>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div id="signUp" style="padding:20px">
                            <form method="post" class="form-horizontal">
                                <div class="form-group"><input class="form-control" type="text" name="firstname" placeholder="firstname" required/></div>
                                <div class="form-group"><input class="form-control" type="text" name="lastname" placeholder="lastname" required/></div>
                                <div class="form-group"><input class="form-control" type="text" name="email" placeholder="email" required/></div>
                                <div class="form-group input-group">
                                    <input class="form-control" type="password" id="Password1" name="password" placeholder="password"  autocomplete="off" required/>
                                    <span class="input-group-addon" id="Eye1"><i id="the_eye_1" class="fa fa-eye"></i></span>
                                </div>
                                <div class="form-group"><input class="form-control" type="password" name="confirm_password" placeholder="Confirm password" required/></div>
                                <div class="form-group">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <input class="form-control btn btn-info" type="submit" name="signup" value="signup" style="width: 100%;"/>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer" style="background-color: #eeeeee;">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <a href="#" data-toggle="modal" data-target="#reminderModal">Forgot password?</a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12"></div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <button class="btn btn-default btn-sm" id="signUpButton">Sign Up</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
        <!-----------Info modal----------------->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Information</h4>
                    </div>
                    <div class="modal-body" id="infoModalText"><?php echo($GLOBALS['message']) ?></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-----------reminder modal----------------->
        <div class="modal fade" id="reminderModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Forgot password</h4>
                    </div>
                    <div class="modal-body">
                        <div class="well well-sm text-info">
                            Please enter your login email on the box bellow so that we may be 
                            able to send you the password reset link.
                        </div>
                        <hr/>
                        <div>
                            <form action="index.php" method="post" class="form-inline">
                                <div class="form-group-lg">
                                    <input class="form-control" type="text" name="remindEmail" placeholder="Email" required/>
                                    <input class="form-control btn btn-lg btn-primary" name="sendEmail" value="Send Email" type="submit"/>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-------------------------------------->        
        <script src="assets/js/jquery-1.10.2.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script src="assets/js/custom.js"></script>
        <script>
            $("div[id=the_new_length]").css("height",$("#the_length_i_need").css("height").toString());
            $("div[id=the_new_length]").css("height",$("#the_length_i_need").css("height").toString());
            var password = true;
            $('#Eye').on("click",function(){
                if(password)
                {
                    $('#Password').prop("type","text");
                    $('#the_eye').prop("class","fa fa-eye-slash");
                    password = false;
                }
                else
                {
                    $('#Password').prop("type","password");
                    $('#the_eye').prop("class","fa fa-eye");
                    password = true;
                }
            });
            
            var password1 = true;
            $('#Eye1').on("click",function(){
                if(password1)
                {
                    $('#Password1').prop("type","text");
                    $('#the_eye_1').prop("class","fa fa-eye-slash");
                    password1 = false;
                }
                else
                {
                    $('#Password1').prop("type","password");
                    $('#the_eye_1').prop("class","fa fa-eye");
                    password1 = true;
                }
            });            
        </script>
        <script type="text/javascript">
            var sign = true;
            $('document').ready(function(){
                $('#signUp').hide();
                sign = false;
                if(GetQueryVariable("msg") !== "")
                {
                   $('#infoModal').modal('show'); 
                }
            });
            $('#login_button').on("click tapstart",function(){
                $('#LogInModal').modal("toggle");
            });
            $('#signUpButton').click(function()
            {
                if(sign===false)
                {
                    $('#signIn').hide('slow',function(){});
                    $('#signUp').show('slow',function(){});
                    $('#signInHeader').text("Sign Up");
                    $('#signUpButton').text("Sign in");
                    sign = true;
                }
                else
                {
                    $('#signIn').show('slow',function(){});
                    $('#signUp').hide('slow',function(){});
                    $('#signInHeader').text("Sign in");
                    $('#signUpButton').text("Sign Up");
                    sign = false;
                }
            });
            if($(window).width() <= 1200)
            {
                $("body").css("background-size","200%");
            }
            if($(window).width() <= 500)
            {
                $("body").css("background-size","340%");
            }
            $(window).resize(function(){
                if($(window).width() <= 1200)
                {
                    $("body").css("background-size","200%");
                }
                else if($(window).width() <= 485)
                {
                    $("body").css("background-size","340%");
                }
                else
                {
                    $("body").css("background-size","100%");
                }
            });
        </script>      
        <script>
            $("form[id=login_button] a").hover(function()
                {
                    $('.popover-toggle').popover('toggle');
                }
                ,function()
                {
                    $('.popover-toggle').popover('toggle');
                }
            );
        </script>
    </body>
    <script>
        Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });
    </script>
</html>