<?php
include("assets/classes/Database.php");
include("assets/classes/File.php");

$database = Connect_For_The_First_Time();
$database->Query("CREATE DATABASE school");

$file = new File();
$file->setpath("database.sql");

$database1 = connect();
if($database1->multi_query($file->read()))
{
    echo("Database has been successfully setup<br/>");
}
else 
{
    echo("Failed to create the tables<br/>");
}
echo("All done : <a href='./'>Explore site</a>");