<?php
session_start();
$GLOBALS['message'] = "";
$GLOBALS['$proceed_menu_text'] = "";

include("assets/classes/Database.php");
include("assets/classes/Sessions.php");
if(isset($_SESSION['email']) and isset($_SESSION['password']))
{
    $GLOBALS['message'] = "You are still logged on, procced to <a href='member_area/'>members area</a>";
    $GLOBALS['$proceed_menu_text'] = $_SESSION['email'];
}

$GLOBALS['message'] = @$_GET['msg'];

$database = @Connect();
if(Connect()->connect_errno >= 1)
{
    header("location:install.php");
}

//If login button is clicked
if(filter_input(INPUT_POST, "login") == "login")
{
    $MyPasswordResult = $database->Query("SELECT password FROM users WHERE email = '".filter_input(INPUT_POST, "email")."'");
    $MyEmailResult = $database->Query("SELECT email FROM users WHERE password = '".filter_input(INPUT_POST, "password")."'");
    
    $email = $MyEmailResult->fetch_array()['email'];
    $password = $MyPasswordResult->fetch_array()['password'];
    
    if(gettype($email) != "string")
    {
        $GLOBALS['message'] = "Email not found";
    }
    if(gettype($password) != "string")
    {
        $GLOBALS['message'] = "Password not found";
    }
    
    if($email == filter_input(INPUT_POST, "email") and $password == filter_input(INPUT_POST, "password"))        
    {
        $_SESSION['email'] = filter_input(INPUT_POST, "email");
        $_SESSION['password'] = filter_input(INPUT_POST, "password");
        $GLOBALS['message'] = "Redirecting to members area";
        CreateSession();
        echo("<script>document.location = 'member_area/'</script>");
    }
    else
    {
        $GLOBALS['message'] = "Email and (or) password not found";
        header("location:./?msg={$GLOBALS['message']}");
    }
}

//if sign up button is clicked
if(filter_input(INPUT_POST, "signup") == "signup")
{
    if(filter_input(INPUT_POST, "password") == filter_input(INPUT_POST, "confirm_password"))
    {
        $arr = array
        (
            filter_input(INPUT_POST, "firstname"),
            filter_input(INPUT_POST, "lastname"),
            filter_input(INPUT_POST, "email"),
            filter_input(INPUT_POST, "password"),
            "USCH". rand(1000, 99000),
            "simple_user"
        );
        $GLOBALS['message'] = $database->Insert("users", $arr) ? "Successfully registered your accound please check you email for verification code" : "$database->error Oops! sign up failed, please try again";
    }
}

//If reset password request is made
if(filter_input(INPUT_POST, "sendEmail") == "Send Email")
{
    $name = $database->Fetch("users", "email", mail(filter_input(INPUT_POST, "sendEmail"), "firstname"))['firstname'];
    $mailMessage = "Dear $name \r\n This message was send to you in response\r\n"
            . "to the password reset request that you have made on Primary.com\r\n"
            . "Bellow is a link to help you get started with resetting your password\r\n"
            . "<a href=\"Primary.com/passwordReset.php?m=USCH".rand(1000, 99000)."\">Primary.com/passwordReset.php?m=USCH". rand(1000, 99000)."\"</a>"
            . "If you do not remember sending this request, then please do not ignore\r\n"
            . "this message because someone might have tried to hack in to your account\r\n"
            . "You can contact us at <email@mail.com> if you feel like there is a suspicious\r\n"
            . "behaviour regarding regarding your aacount.\r\n"
            . "Regards\r\n"
            . "Megegethe Team";
    $GLOBALS['message'] = mail(filter_input(INPUT_POST, "sendEmail"), "Reset your password", $mailMessage) ? "Email send" : "Error sending your email";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="assets/img/logo_brand_no_bg.png" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="assets/css/custom.css" rel="stylesheet"/>
        <script src="assets/js/jquery-1.10.2.js"></script>       
        <script src="assets/js/pace.min.js"></script>        
        <link href="assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet"/>
        <!-- MORRIS CHART STYLES-->
        <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- FONTAWESOME STYLES-->
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <link href="assets/css/loading.css" type="text/css" rel="stylesheet">
        <title>Primary : School information management system</title>
    </head>
    <body id="body" style="background-repeat: no-repeat; background-image: url('assets/img/Magegethe_Banner.png');background-size: 100%;">
        <div class="cover"></div>
        <div class="load">
            <div class="loading_gif">
                <img alt="loading" src="assets/img/loading.gif"/>
            </div>
        </div>
        <div class="container">
            <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="./">
                            <u style="color: white;">Magegethe</u>
                        </a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                            <li>
                                <a href="./" class="panel-back">Home</a>
                            </li>
                            <li><a href="about.php">About us</a></li>          
                            <li><a href="contact.php">Contact us</a></li>
                            <li class="divider"></li>
                            <?php if($GLOBALS['$proceed_menu_text'] !== ""): ?>
                            <li class="active">
                                <form class="navbar-form form-inline" id="login_button">
                                    <a class="btn btn-default popover-toggle" data-container="body" 
                                       data-toggle="popover" data-placement="bottom" 
                                       data-content="Proceed as <?php echo($GLOBALS['$proceed_menu_text']); ?>" 
                                       href="member_area/"
                                       style="background-color: #9999ff;
                                       color: #E0E0E0; border: solid white 2px;">
                                        <i class="fa fa-user"></i>&nbsp;Login / Register
                                    </a>
                                </form>
                            </li>
                            <?php endif; ?>
                            <?php if($GLOBALS['$proceed_menu_text'] === ""): ?>
                            <li>
                                <form class="navbar-form form-inline" id="login_button">
                                    <a class="btn btn-default popover-toggle" id="toggleLoginPanel" 
                                       data-content="Login or sign up here" data-placement="bottom" 
                                       data-container="body" data-toggle="popover"
                                       style="background-color: #9999ff;
                                       color: #E0E0E0; border: solid white 2px;">
                                        <i class="fa fa-user"></i>&nbsp;Login / Register
                                    </a>
                                </form>
                            </li>
                            <?php endif; ?>
                        </ul>           
                    </div>
                </div>     
            </nav>
            <div class="col-lg-12 col-md-12 col-sm-12" style="padding-top: 10%">
                <div class="col-lg-5 col-md-5 col-sm-12" style="">
                    <div class="panel panel-back">
                        <div class="panel-body">
                            <img alt="logo" src="assets/img/logo.png" style="width: 100%"/>
                        </div>
                    </div>
                    <div class="text-center heading-text">
                        <h4 style="color: #3c3c3c;">
                        We not only serve schools but everyone who has a stake in education 
                        which include students/pupils, Parents/Guardians, Teachers and school administration
                        We help you manage your school by providing you with an intergrated 
                        online school management system that does not only deal with 
                        student's information. 
                        </h4>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <a href="" class="btn btn-info btn-block panel-back">Live Demo</a>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <a href="#pricing" class="btn btn-info btn-block panel-back">Pricing</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12"></div>
                <div class="col-lg-5 col-md-5 col-sm-12">
                    <img alt="colage" src="assets/img/screenshot_colage.png" width="100%"/>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 20px;">
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <div class="panel panel-default panel-back">
                        <div class="panel-heading text-center">
                            <h4>Our coolest features</h4>
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading text-center">
                                        Student Information Management
                                    </div>
                                    <div class="panel-body" id="the_length_i_need">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Enroll students to your school</li>
                                            <li>Register students to each level that they have advanced to</li>
                                            <li>Record daily school attendance</li>
                                            <li>Record assessment marks</li>
                                            <li>Produce students report</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading text-center">
                                        Staff Information Management
                                    </div>
                                    <div class="panel-body" id="the_new_length">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Enroll staff member to your school</li>
                                            <li>Register staff member to your school</li>
                                            <li>Record daily school attendance</li>
                                            <li>Save employee contracts</li>
                                            <li>Save employee CV's and Job Application Letters</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading text-center">
                                        Library Management
                                    </div>
                                    <div class="panel-body"id="the_new_length">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Add new books to the list</li>
                                            <li>Fill in the details of the books</li>
                                            <li>Request books</li>
                                            <li>Return books</li>
                                            <li>Issue Books</li>
                                            <li>Report lost books</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 20px;">
                <div class="panel panel-primary panel-back">
                    <div class="panel-body">
                        <h4 class="text-center">Who can use our service</h4>
                        <div class="custom_underline" style="height: 3px"></div>
                        <div id="myCarousel" class="carousel slide">
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <span>
                                            <h2>School staff members</h2>    
                                            School staff members can use the service
                                            to manage the student information i.e 
                                            enroll and register students, register
                                            newly recruited staff members. Manage 
                                            the library.
                                            </span>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <img style="height: 500px;" class="img-responsive" alt="staff" src="assets/img/Teacher.png"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <span>
                                            <h2>Parents and legal guardians</h2>    
                                            Parents and legal guardians, or any other person
                                            related to the student can use use the system to
                                            check the perfomance or progress of the students
                                            and check out their gradebook or reports.
                                            </span>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <img style="height: 500px;" class="img-responsive" alt="staff" src="assets/img/Parent.png"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <span>
                                            <h2>Students or learners</h2>
                                            Students or learners themselves can use the 
                                            service to check out their reports and check 
                                            out the recomendations from their teachers and 
                                            from the service in order to help them to have 
                                            an understanding of the processes that they 
                                            need to be able to have a good progress academically.
                                            </span>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                                            <img style="height: 500px;" class="img-responsive" alt="staff" src="assets/img/Student.png"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a class="carousel-control left" style="background: transparent" href="#myCarousel"data-slide="prev">
                                <span style="background-color: #686868;padding: 15px;padding-bottom: 5px">
                                    <i class="fa fa-2x fa-arrow-left" style="margin-top: 140%;"></i>
                                </span>
                            </a>
                            <a class="carousel-control right" style="background: transparent" href="#myCarousel"data-slide="next">
                                <span style="background-color: #686868;padding: 15px;padding-bottom: 5px">
                                    <i class="fa fa-2x fa-arrow-right" style="margin-top: 140%;"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 20px;" id="pricing">
                <div class="panel panel-primary panel-back">
                    <div class="panel-body">
                        <h4 class="text-center">Pricing</h4>
                        <div class="custom_underline" style="margin-bottom: 15px;"></div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back" id="the_new_length">
                                    <div class="panel-heading text-center">
                                        Trial (Free for 30 Days)
                                    </div>
                                    <div class="panel-body">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Enroll students to your school</li>
                                            <li>Register students to each level that they have advanced to</li>
                                            <li>Record daily school attendance</li>
                                            <li>Record assessment marks</li>
                                            <li>Produce students report</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back" id="the_length_i_need">
                                    <div class="panel-heading text-center">
                                        Students (Free)
                                    </div>
                                    <div class="panel-body" id="the_new_length">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Enroll staff member to your school</li>
                                            <li>Register staff member to your school</li>
                                            <li>Record daily school attendance</li>
                                            <li>Save employee contracts</li>
                                            <li>Save employee CV's and Job Application Letters</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="panel panel-default panel-back" id="the_new_length">
                                    <div class="panel-heading text-center">
                                        Premium (M30 / year)
                                    </div>
                                    <div class="panel-body"id="the_new_length">
                                        <ul class="list-group" style="padding: 25px">
                                            <li>Add new books to the list</li>
                                            <li>Fill in the details of the books</li>
                                            <li>Request books</li>
                                            <li>Return books</li>
                                            <li>Issue Books</li>
                                            <li>Report lost books</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
            
        <!------------------------------Footer-------------------------------------->
        <div class=" text-center">
            <div>&copy; 2019 - 2020 Magegethe</div>
            <div>
                <a href="about.php">About us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="contact.php">Contact us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#">Help</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#">Terms of privacy</a>
            </div>
            <div>
                <a href="#"><i class="fa fa-facebook"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#"><i class="fa fa-instagram"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="#"><i class="fa fa-twitter"></i></a>
            </div>
        </div>         
        <!----------------------------- Login / signup Modal [new] ----------------------->
        <div class="modal fade" id="LogInModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">
                            <span id="signInHeader">Sign in</span>
                        </h4>
                    </div>
                    <div class="modal-body" id="infoModalText">
                        <div id="signIn" style="padding:20px">
                            <form action="index.php" method="post" class="form-horizontal">
                                <div class="form-group"><input class="form-control" type="text" name="email" placeholder="email" required/></div>
                                <div class="form-group input-group"><input class="form-control" type="password" name="password" id="Password" placeholder="password" autocomplete="off" required/>
                                    <span class="input-group-addon" id="Eye">
                                        <i id="the_eye" class="fa fa-eye"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="Keep_me_logged_in"/>
                                    <span>Keep me logged in</span>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <input class="form-control btn btn-info btn-block" type="submit" name="login" value="login"/>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div id="signUp" style="padding:20px">
                            <form action="index.php" method="post" class="form-horizontal">
                                <div class="form-group"><input class="form-control" type="text" name="firstname" placeholder="firstname" required/></div>
                                <div class="form-group"><input class="form-control" type="text" name="lastname" placeholder="lastname" required/></div>
                                <div class="form-group"><input class="form-control" type="text" name="email" placeholder="email" required/></div>
                                <div class="form-group input-group">
                                    <input class="form-control" type="password" id="Password1" name="password" placeholder="password"  autocomplete="off" required/>
                                    <span class="input-group-addon" id="Eye1"><i id="the_eye_1" class="fa fa-eye"></i></span>
                                </div>
                                <div class="form-group"><input class="form-control" type="password" name="confirm_password" placeholder="Confirm password" required/></div>
                                <div class="form-group">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <input class="form-control btn btn-info" type="submit" name="signup" value="signup" style="width: 100%;"/>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer" style="background-color: #eeeeee;">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <a href="#" data-toggle="modal" data-target="#reminderModal">Forgot password?</a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12"></div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <button class="btn btn-default btn-sm" id="signUpButton">Sign Up</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-----------Info modal----------------->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Information</h4>
                    </div>
                    <div class="modal-body" id="infoModalText"><?php echo($GLOBALS['message']); ?></div>
                    <div class="modal-footer" style="background-color: #eeeeee;">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-----------reminder modal----------------->
        <div class="modal fade" id="reminderModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Forgot password</h4>
                    </div>
                    <div class="modal-body">
                        <div class="well well-sm text-info">
                            Please enter your login email on the box bellow so that we may be 
                            able to send you the password reset link.
                        </div>
                        <hr/>
                        <div>
                            <form action="index.php" method="post" class="form-inline">
                                <div class="form-group-lg">
                                    <input class="form-control" type="text" name="remindEmail" placeholder="Email" required/>
                                    <input class="form-control btn btn-lg btn-primary" name="sendEmail" value="Send Email" type="submit"/>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer" style="background-color: #eeeeee;">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-------------------------------------->        
        <script src="assets/js/jquery-1.10.2.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script src="assets/js/custom.js"></script>
        <script>
            $("div[id=the_new_length]").css("height",$("#the_length_i_need").css("height").toString());
            $("div[id=the_new_length]").css("height",$("#the_length_i_need").css("height").toString());
            var password = true;
            $('#Eye').on("click",function(){
                if(password)
                {
                    $('#Password').prop("type","text");
                    $('#the_eye').prop("class","fa fa-eye-slash");
                    password = false;
                }
                else
                {
                    $('#Password').prop("type","password");
                    $('#the_eye').prop("class","fa fa-eye");
                    password = true;
                }
            });
            
            var password1 = true;
            $('#Eye1').on("click",function(){
                if(password1)
                {
                    $('#Password1').prop("type","text");
                    $('#the_eye_1').prop("class","fa fa-eye-slash");
                    password1 = false;
                }
                else
                {
                    $('#Password1').prop("type","password");
                    $('#the_eye_1').prop("class","fa fa-eye");
                    password1 = true;
                }
            });            
        </script>
        <script type="text/javascript">
            var sign = true;
            $('document').ready(function(){
                $('#signUp').hide();
                sign = false;
                if(GetQueryVariable("msg") !== "")
                {
                   $('#infoModal').modal('show'); 
                }
            });
            $('#login_button').on("click tapstart",function(){
                $('#LogInModal').modal("toggle");
            });
            $('#signUpButton').click(function()
            {
                if(sign===false)
                {
                    $('#signIn').hide('slow',function(){});
                    $('#signUp').show('slow',function(){});
                    $('#signInHeader').text("Sign Up");
                    $('#signUpButton').text("Sign in");
                    sign = true;
                }
                else
                {
                    $('#signIn').show('slow',function(){});
                    $('#signUp').hide('slow',function(){});
                    $('#signInHeader').text("Sign in");
                    $('#signUpButton').text("Sign Up");
                    sign = false;
                }
            });
            if($(window).width() <= 1200)
            {
                $("body").css("background-size","200%");
            }
            if($(window).width() <= 500)
            {
                $("body").css("background-size","340%");
            }
            $(window).resize(function(){
                if($(window).width() <= 1200)
                {
                    $("body").css("background-size","200%");
                }
                else if($(window).width() <= 485)
                {
                    $("body").css("background-size","340%");
                }
                else
                {
                    $("body").css("background-size","100%");
                }
            });
        </script>      
        <script>
            $("form[id=login_button] a").hover(function()
                {
                    $('.popover-toggle').popover('toggle');
                }
                ,function()
                {
                    $('.popover-toggle').popover('toggle');
                }
            );
        </script>
    </body>
    <script>
        Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });
    </script>
</html>