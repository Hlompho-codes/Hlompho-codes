<?php
session_start();
include("../../assets/classes/Database.php");
include("../../assets/classes/Sessions.php");
include("../../assets/classes/Modal_print.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}

$database = Connect();
$GLOBALS['session_email'] = "";
$GLOBALS['message'] = "";

$save_details = trim(filter_input(INPUT_POST,"save_details"));
if(!isset($save_details) !== true && $save_details !== '')
{
    $sql = "UPDATE users "
            ."SET "
            ."firstname = '".filter_input(INPUT_POST, "firstname")."',"
            ."lastname = '".filter_input(INPUT_POST, "lastname")."',"
            ."email = '".filter_input(INPUT_POST, "email")."' "
            ."WHERE email = '".$_SESSION['email']."'";
    $database->Query($sql);
    if($database->affected_rows >= 1)
    {
        $GLOBALS['session_email'] = $_SESSION['email'];
        $sql = "UPDATE users_schools "
               ."SET "
               ."user_email = '".trim(filter_input(INPUT_POST,"email"))."' "
               ."WHERE user_email = '{$GLOBALS['session_email']}'";
        $database->Query($sql);
        if($database->affected_rows >= 1)
        {
            $GLOBALS['message'] = "Your details have been updated.";
        }
    }     
    else
    {
        $GLOBALS['message'] = "Oops! Something went wrong, your details have not been updated, please try again ".$database->error;
    }
}

$save_password = trim(filter_input(INPUT_POST,"save_password"));
if(!isset($save_password) !== true && $save_password !== '')
{
    if(trim(filter_input(INPUT_POST, "password")) !== $_SESSION['password'])
    {
        $GLOBALS['message'] = "The password that you have provided is not recognized";
    }
    else if(trim(filter_input(INPUT_POST, "new_password")) !== trim(filter_input(INPUT_POST, "confirm_password")))
    {
        $GLOBALS['message'] = "The password and password confirmation that you have entered do not match";
    }
    else 
    {    
        $sql = "UPDATE users "
                . "SET "
                . "password = '".filter_input(INPUT_POST, "new_password")."'"
                . "WHERE email = '".$_SESSION['email']."'";
        $database->Query($sql);
        if($database->affected_rows >= 1)
        {
           $GLOBALS['message'] = "Your password has been updated. "
                   ."Please remember to use the password the next time you login";
        }     
        else
        {
            $GLOBALS['message'] = "Oops! Something went wrong, your email have not been updated, please try again ".$database->error;
        }
    }
}

$UsersFirstName = $database->Query("SELECT firstname FROM users WHERE email = '".$_SESSION['email']."'");
$GLOBALS['name'] = $UsersFirstName->fetch_array()['firstname'];

$UsersEmail = $database->Query("SELECT email FROM users WHERE password = '".$_SESSION['password']."'");
$GLOBALS['email'] = $UsersEmail->fetch_array()['email'];

$UsersLastName = $database->Query("SELECT lastname FROM users WHERE email = '".$_SESSION['email']."'");
$GLOBALS['lastname'] = $UsersLastName->fetch_array()['lastname'];

$search_keywords = trim(filter_input(INPUT_POST,"search"));
if(!isset($search_keywords) !== true && $search_keywords !== '')
{
    modal_print("Warning","We are yet to make the searching work");
}
?>
<!DOCTYPE html>
<html>
    <body>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="../../assets/img/logo.png" />
        <link href="../../assets/css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../../assets/js/jquery-1.10.2.js"></script>       
        <script src="../../assets/js/pace.min.js"></script>
        <style>
            .cover {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 1999;
    background: #387ff8;/**rgb(33,33,33);**/
}
        </style>        
        <link rel="icon" href="../../assets/img/logo_brand_no_bg.png" />
        <link href="../../assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">        
        <link href="../../assets/css/font-awesome.min.css" rel="stylesheet"/>
        <link href="../../assets/css/simple-sidebar.css" rel="stylesheet">
        <link href="../../assets/css/font-awesome.css" rel="stylesheet" />
        <link href="../../assets/css/loading.css" type="text/css" rel="stylesheet">
        <link href="../../assets/css/custom.css" type="text/css" rel="stylesheet">
        <title>School management system</title>
    </head>
    <body>
    <div class="cover"></div>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav" style="margin-top: 20%">
                <li class="sidebar-brand">
                    <a href="#">
                        Menu
                    </a>
                </li>
                <li class="active">
                    <a href="../" id="Schools"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;My Schools</a>
                </li>
                <li>
                    <a href="./" id="Schools"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;My Account</a>
                </li>
                <li>
                    <a href="../messages/" id="Messages"><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Messages</a>
                </li>
                <li><a href="../notifications/" id="Notifications"><i class="fa fa-bell"></i>&nbsp;&nbsp;&nbsp;Notifications</a></li>
            </ul>
        </div>
        <div id="page-content-wrapper">        
            <div id="overlay">
                <div id="text">
                    <img style="width: 50%;height: 50%" src="../../assets/img/loading.gif" alt="loading"/>
                </div>
            </div>    
            <div class="container">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div>
                                <a class="navbar-brand" href="../../"><u style="color: white;">Magegethe</u></a>
                                <a class="navbar-brand" href="#menu-toggle" title="Toggle menu" class="btn btn-secondary" id="menu-toggle">&nbsp;&nbsp;&nbsp;<i class="fa fa-bars fa-1x"></i>&nbsp;&nbsp;Menu</a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                                <li>
                                    <div>
                                        <form class="navbar-form form-inline" method="post" action="./">
                                            <input id="searchbox" style="width:330px" class="form-control" type="text" name="search" placeholder="Type your search keywords then click enter"/>
                                        </form>
                                    </div>
                                </li>
                                <li>
                                    <a href="#" id="hide_show_search"><i class="fa fa-search"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" 
                                       data-toggle="dropdown" role="button" 
                                       aria-expanded="false">
                                           <?php echo($GLOBALS['email'])?>
                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="./">Account</a></li>
                                        <li><a href="../../logout.php">Sign out</a></li>               
                                    </ul>
                                </li>
                            </ul>           
                        </div>
                    </div>
                </nav>
            </div>        
            <ol class="breadcrumb" style="margin-top:5.5%">
                <li><a href="../">My Schools</a></li>
                <li><a href="./">My Account</a></li>
            </ol>
            <ul class="nav nav-pills panel-back" style="background-color: #F3F3F3">
                <li class="active"><a href="#Details" data-toggle="tab">My Details</a></li>
                <li><a href="#Password" data-toggle="tab">Password</a></li>
                <li><a href="#Settings" data-toggle="tab">Settings</a></li>
                <li><a href="#Subscriptions" data-toggle="tab">My Subscriptions</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade in active panel-back" id="Details">
                    <div class="panel panel-primary panel-back">
                        <div class="panel-body">
                            <h3>Change your account details here <?php echo($GLOBALS['name']) ?></h3>
                            <div class="custom_underline"></div>
                            <div class="container" style=" margin-top: 10px;">
                                <form class="form-horizontal" method="post" action="./">
                                    <div class="form-group"><input class="form-control" type="text" name="firstname" title="firstname" placeholder="first name" value="<?php echo($GLOBALS['name']); ?>" required/></div>
                                    <div class="form-group"><input class="form-control" type="text" name="lastname" title="lastname" placeholder="last name" value="<?php echo($GLOBALS['lastname']); ?>" required/></div>
                                    <div class="form-group"><input class="form-control" type="text" name="email" title="email" placeholder="email" value="<?php echo($GLOBALS['email']); ?>" required/></div>
                                    <div class="form-group"><input class="form-control btn btn-info" type="submit" name="save_details" value="Save" style="width: 50%;"/></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade panel-back" id="Password">
                    <div class="panel panel-primary panel-back">
                        <div class="panel-body">
                            <h3>Change your account password here <?php echo($GLOBALS['name']) ?></h3>
                            <div class="custom_underline"></div>
                            <div class="container" style=" margin-top: 10px;">
                                <form class="form-horizontal" method="post" action="./">
                                    <div class="form-group"><input class="form-control" type="password" name="new_password" title="New password" placeholder="New password" required/></div>
                                    <div class="form-group"><input class="form-control" type="password" name="confirm_password" title="Confirm new password" placeholder="Confirm new password" required/></div>
                                    <div class="form-group"><input class="form-control" type="password" name="password" title="password" placeholder="password" required/></div>
                                    <div class="form-group"><input class="form-control btn btn-info" type="submit" name="save_password" value="Save" style="width: 50%;"/></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade panel-back" id="Settings">
                    <div class="panel panel-primary panel-back">
                        <div class="panel-body">
                            <h3>Change your account settings here <?php echo($GLOBALS['name']) ?></h3>
                            <div class="custom_underline"></div>
                            <div class="container" style=" margin-top: 10px;">
                                <form class="form-horizontal" action="./" method="post">
                                    <div class="panel panel-default panel-back">
                                        <div class="panel-heading">Change session Timeout</div>
                                        <div class="panel-body">
                                            <div class="form-group container-fluid">
                                                <select name="timeout" class="form-control">
                                                    <option value="">Change session Timeout : Default = 10 minutes</option>
                                                    <option value="10">10 minutes</option>
                                                    <option value="15">15 minutes</option>
                                                    <option value="20">20 minutes</option>
                                                    <option value="25">25 minutes</option>
                                                    <option value="30">30 minutes</option>
                                                    <option value="60">1 Hour</option>
                                                    <option value="120">2 Hours</option>
                                                    <option value="never">Never let my sessions expire</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default panel-back">
                                        <div class="panel-heading">Choose where would you like your messages</div>
                                        <div class="panel-body">
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <div class="col-lg-3 col-md-3 col-sm-12">
                                                    <h4>Internal (Magegethe website)</h4>
                                                </div>
                                                <div class="col-lg-1 col-md-1 col-sm-12">
                                                    <div class="form-group">
                                                        <input class="form-control checkbox" checked type="checkbox" name="Internal_messages" value="Magegethe website"/>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <div class="col-lg-3 col-md-3 col-sm-12">
                                                    <h4>Email</h4>
                                                </div>
                                                <div class="col-lg-1 col-md-1 col-sm-12">
                                                    <div class="form-group">
                                                        <input class="form-control checkbox" type="checkbox" name="email" value="email"/>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-info" value="Save settings" name="Settings"/>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade panel-back" id="Subscriptions">
                    <div class="panel panel-primary panel-back">
                        <div class="panel-body">
                            <h3>My Subscriptions</h3>
                            <div class="custom_underline"></div>
                            <div class="container" style=" margin-top: 10px;">
                                <ul class="list-group">
                                    <li class="list-group-item">FREE</li>
                                    <li class="list-group-item">R20</li>
                                    <li class="list-group-item">R30</li>
                                    <li class="list-group-item">R50</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <!-----------Info modal----------------->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Information</h4>
                    </div>
                    <div class="modal-body" id="infoModalText"><?php echo($GLOBALS['message']) ?></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div> 
        <!-----------Gallery modal----------------->
        <div class="modal fade" id="galleryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Profile picture</h4>
                    </div>
                    <div class="modal-body">
                        <img alt="pro pic" src="../../assets/img/pro_pic_default.png" class="img-responsive img-thumbnail" style="height: 50%;width:50%;margin:1%"/>
                        <form action="./" method="POST" enctype="multipart/form-data" class="form-inline right">
                            <input id="file_upload_tag" class="form-control" name="pro_pic" type="file" placeholder="School's logo" required/>
                            <input class="form-control btn btn-sm btn-default" type="submit"/>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>        
    </body>
    <script src="../../assets/js/bootstrap.min.js"></script>    
    <script src="../../assets/js/Sessions.js"></script>
    <script src="../../assets/js/loading.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script>
    var hidden = true;
    $("#searchbox").hide("slow");
    $("#hide_show_search").click(function()
    {
        if(hidden)
        {
            $("input[name=search]").show("slow");//.val("Visible");
            $("input[name=search]").focus();
            hidden = false;
        }
        else
        {
            $("input[name=search]").hide("slow");//.val("Hidden");
            hidden = true;
        }
    });
    </script>
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>       
    <script>
    $('document').ready(function(){
        $('#signUp').hide();
        sign = false;
        if($('#infoModalText').text()!=="")
        {
           $('#infoModal').modal('show'); 
        }
    });    
    </script>
    <script>
        $("#file_upload_trigger_tag").click(function(){
            $('#galleryModal').modal('toggle'); 
            //$("#file_upload_tag").trigger('click');
        });
    </script>
    <script>Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });    
    </script>
</html>