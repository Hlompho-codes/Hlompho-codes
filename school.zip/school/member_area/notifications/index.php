<?php
session_start();
include("../../assets/classes/Database.php");
include("../../assets/classes/Sessions.php");
include("../../assets/classes/Modal_print.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$database = Connect();

$UserEmail = $database->Query("SELECT email FROM users WHERE password = '".$_SESSION['password']."'");
$GLOBALS['email'] = $UserEmail->fetch_array()['email'];
?>
<!DOCTYPE html>
<html>
    <body>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="../../assets/img/logo.png" />
        <link href="../../assets/css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../../assets/js/jquery-1.10.2.js"></script>       
        <script src="../../assets/js/pace.min.js"></script>
        <style>
            .cover {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 1999;
    background: #387ff8;/**rgb(33,33,33);**/
}
        </style>        
        <link rel="icon" href="../../assets/img/logo_brand_no_bg.png" />
        <link href="../../assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">        
        <link href="../../assets/css/font-awesome.min.css" rel="stylesheet"/>
        <link href="../../assets/css/simple-sidebar.css" rel="stylesheet">
        <link href="../../assets/css/font-awesome.css" rel="stylesheet" />
        <link href="../../assets/css/loading.css" type="text/css" rel="stylesheet">
        <link href="../../assets/css/custom.css" type="text/css" rel="stylesheet">
        <title>Messages</title>
    </head>
    <body>
    <div class="cover"></div>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav" style="margin-top: 20%">
                <li class="sidebar-brand">
                    <a href="#">
                        Menu
                    </a>
                </li>
                <li class="active">
                    <a href="../" id="Schools"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;My Schools</a>
                </li>
                <li>
                    <a href="../My_Account/" id="Schools"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;My Account</a>
                </li>
                <li>
                    <a href="../messages/" id="Messages"><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Messages</a>
                </li>
                <li><a href="./" id="Notifications"><i class="fa fa-bell"></i>&nbsp;&nbsp;&nbsp;Notifications</a></li>
            </ul>
        </div>
        <div id="page-content-wrapper">        
            <div id="overlay">
                <div id="text">
                    <img style="width: 50%;height: 50%" src="../../assets/img/loading.gif" alt="loading"/>
                </div>
            </div>    
            <div class="container">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div>
                                <a class="navbar-brand" href="../../"><u style="color: white;">Magegethe</u></a>
                                <a class="navbar-brand" href="#menu-toggle" title="Toggle menu" class="btn btn-secondary" id="menu-toggle">&nbsp;&nbsp;&nbsp;<i class="fa fa-bars fa-1x"></i>&nbsp;&nbsp;Menu</a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                                <li>
                                    <div>
                                        <form class="navbar-form form-inline" method="post" action="./">
                                            <input id="searchbox" style="width:330px" class="form-control" type="text" name="search" placeholder="Type your search keywords then click enter"/>
                                        </form>
                                    </div>
                                </li>
                                <li>
                                    <a href="#" id="hide_show_search"><i class="fa fa-search"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" 
                                       data-toggle="dropdown" role="button" 
                                       aria-expanded="false">
                                           <?php echo($GLOBALS['email'])?>
                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="../My_Account/">Account</a></li>
                                        <li><a href="../../logout.php">Sign out</a></li>               
                                    </ul>
                                </li>
                            </ul>           
                        </div>
                    </div>
                </nav>
            </div>        
            <div class="container-fluid" style="padding-top:3.5%">
                <ol class="breadcrumb">
                    <li><a href="../">My Schools</a></li>
                    <li><a href="./">Notifications</a></li>
                </ol>
            </div>
        </div>
    </body>
    <script src="../../assets/js/bootstrap.min.js"></script>    
    <script src="../../assets/js/Sessions.js"></script>
    <script src="../../assets/js/loading.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    Pace.stop();
    Pace.on("done", function(){
        $(".cover").fadeOut(1000);
    });
    var hidden = true;
    $("#searchbox").hide("slow");
    $("#hide_show_search").click(function()
    {
        if(hidden)
        {
            $("input[name=search]").show("slow");//.val("Visible");
            $("input[name=search]").focus();
            hidden = false;
        }
        else
        {
            $("input[name=search]").hide("slow");//.val("Hidden");
            hidden = true;
        }
    });
    </script>     
</html>    