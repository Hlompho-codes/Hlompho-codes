<?php
include("../../assets/classes/Database.php");
$database = Connect();
$submit_from_non_user_message_button = trim(filter_input(INPUT_POST,"submit_message"));
if(!isset($submit_from_non_user_message_button) !== true && $submit_from_non_user_message_button !== '')
{
    $sql = "INSERT INTO messages "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"recipient"))."',"
          ."'".trim(filter_input(INPUT_POST,"email"))."',"
          ."'".trim(filter_input(INPUT_POST,"subject"))."',"
          ."'FROM : ".trim(filter_input(INPUT_POST,"name"))."\n".trim(filter_input(INPUT_POST,"message"))."',"
          ."'".date("l, F jS, Y, g:i A")."',"
          ."'unread')";
    $database->Query($sql);

    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "You have successfully send a new message";
        echo("<div class=\"alert alert-success\">{$GLOBALS['message']}</div>");
    }
    else
    {
        $GLOBALS['message'] = $database->error;
        echo("<div class=\"alert alert-warning\">{$GLOBALS['message']}</div>");
    }
}
