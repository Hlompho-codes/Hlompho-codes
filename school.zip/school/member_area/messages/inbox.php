<?php
include("../../assets/classes/Database.php");
include("../../assets/classes/Sessions.php");
include("../../assets/classes/Modal_print.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}

$database = Connect();
$submit_message_button = trim(filter_input(INPUT_POST,"submit_message"));
if(!isset($submit_message_button) !== true && $submit_message_button !== '')
{
    $sql = "SELECT school_name FROM users_schools WHERE school_name = '".trim(filter_input(INPUT_POST,"school_name"))."'";
    
    if($database->Query($sql)->fetch_array()['school_name'] === "" or $database->Query($sql)->fetch_array()['school_name'] === null or $database->Query($sql)->fetch_array()['school_name'] === false)
    {
        $sql = "INSERT INTO school "
              ."VALUES(0,"
              ."'".trim(filter_input(INPUT_POST,"school_name"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_type"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_email"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_address"))."',"
              ."'".trim(filter_input(INPUT_POST,"physical_address"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_phone"))."',"
              ."'')";
        $database->Query($sql);

        if($database->affected_rows >= 1)
        {
            $sql = "INSERT INTO users_schools "
                   ."VALUES(0,"
                   . "'".$_SESSION['email']."',"
                   ."'".trim(filter_input(INPUT_POST,"school_name"))."')";
            $database->Query($sql);
            if($database->affected_rows >= 1)
            {
                $GLOBALS['message'] = "You have successfully registered a new school";
                echo("<div class=\"alert alert-success\">{$GLOBALS['message']}</div>");
            }
        }
        else
        {
            $GLOBALS['message'] = $database->error;
            echo("<div class=\"alert alert-warning\">{$GLOBALS['message']}</div>");
        }
    }
    else
    {
        $GLOBALS['message'] = "A school with this name has already been registered please try using a different name";
        echo("<div class=\"alert alert-warning\">{$GLOBALS['message']}</div>");
    }
}
