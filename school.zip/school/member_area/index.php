<?php
session_start();

include("../assets/classes/Database.php");
include("../assets/classes/Sessions.php");
include("../assets/classes/File.php");
include("../assets/classes/Paginator.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");

}
if(KillSession())
{
    header("location:../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$database = Connect();

$UserEmail = $database->Query("SELECT email FROM users WHERE password = '".$_SESSION['password']."'");
$GLOBALS['email'] = $UserEmail->fetch_array()['email'];

$GLOBALS['we_have_a_school'] = FALSE;
$search_keywords = trim(filter_input(INPUT_POST,"search"));
if(!isset($search_keywords) !== true && $search_keywords !== '')
{
    $GLOBALS['message'] = "We are yet to make the searching work";
}
$GLOBALS['alert'] = "";
if(isset($_GET['msg']))
{
    $GLOBALS['message'] = $_GET['msg'];
    if(isset($_GET['r']) and $_GET['r'] === "1")
    {
        $GLOBALS['alert'] = "<section id=\"sections\"><div class=\"alert alert-success\">{$_GET['msg']}</div></section>";
    }
    else
    {
        $GLOBALS['alert'] = "<section id=\"sections\"><div class=\"alert alert-warning\">{$_GET['msg']}</div></section>";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>        
        <meta charset="UTF-8">
        <link rel="icon" href="../assets/img/logo_brand_no_bg.png" />
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../assets/js/jquery-1.10.2.js"></script>       
        <script src="../assets/js/pace.min.js"></script>
        <link href="../assets/css/custom.css" rel="stylesheet"/>        
        <link href="../assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">       
        <link href="../assets/css/font-awesome.min.css" rel="stylesheet"/>
        <link href="../assets/css/simple-sidebar.css" rel="stylesheet">
        <link href="../assets/css/loading.css" type="text/css" rel="stylesheet">           
        <!-- FONTAWESOME STYLES-->
        <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <title>School management system</title>
    </head>
    <body>
    <div class="cover"></div>
    <div class="load">
        <div class="loading_gif">
            <img alt="loading" src="assets/img/loading.gif"/>
        </div>
    </div>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav" style="margin-top: 20%;">
                <li class="sidebar-brand">
                    <a href="#">
                        Menu
                    </a>
                </li>
                <li class="active">
                    <a href="./" id="Schools"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;My Schools</a>
                </li>
                <li>
                    <a href="My_Account/" id="Schools"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;My Account</a>
                </li>
                <li>
                    <a href="messages/" id="Messages"><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Messages</a>
                </li>
                <li><a href="notifications/" id="Notifications"><i class="fa fa-bell"></i>&nbsp;&nbsp;&nbsp;Notifications</a></li>
            </ul>
        </div>
        <div id="page-content-wrapper">
            <div id="overlay">
                <div id="text">
                    <img style="width: 50%;height: 50%" src="../assets/img/loading.gif" alt="loading"/>
                </div>
            </div>
                <div class="container">
                    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                        <div class="container">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="../"><u style="color: white;">Magegethe</u></a></a>
                                <a class="navbar-brand" href="#menu-toggle" title="Toggle menu" class="btn btn-secondary" id="menu-toggle">&nbsp;&nbsp;&nbsp;<i class="fa fa-bars fa-1x"></i>&nbsp;&nbsp;Menu</a>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                                <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                                    <li>
                                        <div>
                                            <form class="navbar-form form-inline" method="post" action="./">
                                                <input id="searchbox" style="width:330px" class="form-control" type="text" name="search" placeholder="Type your search keywords then click enter"/>
                                            </form>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="#" id="hide_show_search"><i class="fa fa-search"></i></a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" 
                                           data-toggle="dropdown" role="button" 
                                           aria-expanded="false">
                                               <?php echo($GLOBALS['email'])?>
                                            <b class="caret"></b>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a href="My_Account/">Account</a></li>
                                            <li><a href="../logout.php">Sign out</a></li>               
                                        </ul>
                                    </li>
                                </ul>           
                            </div>
                        </div>
                    </nav>
                </div>
                <?php echo($GLOBALS['alert']); ?>
            <section id="sections" class="panel-back">
                    <ul id="myTab" class="nav nav-pills" style="background-color: #F3F3F3;">
                        <li class="active"><a href="#list" data-toggle="tab">My Schools</a></li>
                        <li><a href="#new_school" data-toggle="tab">Register a school</a></li>
                        <li><a href="#Reports" data-toggle="tab">Reports</a></li>
                        <li><a href="#Library" data-toggle="tab">Library</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="list">
                            <div class="panel panel-primary">
                                <div class="panel-body" style="margin-top: 5px;">
                                    <h3>List of Schools</h3>
                                    <div class="custom_underline"></div>
                                        <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 5px;">
                                            <div class="panel panel-primary panel-back">
                                                <div class="panel-body">
                                                    <form class="form-inline" method="get">
                                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                                            <div class="col-lg-9 col-md-9 col-sm-12">
                                                                <input class="form-control" style="width: 100%" <?php if(trim(filter_input(INPUT_GET,"search_school")) !== null && trim(filter_input(INPUT_GET,"search_school")) !== ""){echo("value=\"".trim(filter_input(INPUT_GET,"search_school"))."\"");} ?> type="text" name="search_school" placeholder="search for your school"/>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <input class="form-control btn btn-primary" style="width: 100%" type="submit" name="search_for_a_school" value="Find a School"/>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12 col-md-12 col-sm-12" style="padding: 20px;">
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                Filter search by :
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">School name</label>
                                                                <?php if(trim(filter_input(INPUT_GET,"filter")) === null || trim(filter_input(INPUT_GET,"filter")) === ""): ?>
                                                                <input type="radio" name="filter" value="school_name" checked="checked" class="radio form-control"/>
                                                                <?php else: ?>
                                                                <input type="radio" name="filter" value="school_name" <?php echo((trim(filter_input(INPUT_GET,"filter")) !== null) && (trim(filter_input(INPUT_GET,"filter")) === "school_name") ? "checked=\"checked\"" : ""); ?> class="radio form-control"/>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">Type of school</label>
                                                                <input type="radio" name="filter" value="school_type" <?php echo((trim(filter_input(INPUT_GET,"filter")) !== null) && (trim(filter_input(INPUT_GET,"filter")) === "school_type") ? "checked=\"checked\"" : ""); ?> class="radio form-control"/>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">School's location</label>
                                                                <input type="radio" name="filter" value="physical_address" <?php echo((trim(filter_input(INPUT_GET,"filter")) !== null) && (trim(filter_input(INPUT_GET,"filter")) === "physical_address") ? "checked=\"checked\"" : ""); ?> class="radio form-control"/>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    $page = 0;
                                    $count = 0;
                                    settype($page,"integer");
                                    settype($count,"integer");

                                    $cursor = null;
                                    $construct = "";

                                    $search_for_a_school = trim(filter_input(INPUT_GET,"search_school"));
                                    if(!isset($search_for_a_school) !==  true && $search_for_a_school !== '')
                                    {
                                        if(trim(filter_input(INPUT_GET,"filter")) === "school_name")
                                        {
                                            $search_exploded = explode ( " ",trim(filter_input(INPUT_GET,"search_school")));
                                            $x = 0; 
                                            foreach( $search_exploded as $search_each ) 
                                            {
                                                  $x++;
                                                  $construct = " ";
                                                  if( $x == 1 )
                                                  {
                                                         $construct .= "school_name LIKE '%$search_each%' ";
                                                  }
                                                  else
                                                  {
                                                         $construct .= "AND school_name LIKE '%$search_each%' ";
                                                  }
                                            }
                                            $construct = "SELECT * FROM school WHERE $construct";
                                        }
                                        if(trim(filter_input(INPUT_GET,"filter")) === "school_type")
                                        {
                                            $search_exploded = explode ( " ",trim(filter_input(INPUT_GET,"search_school")));
                                            $x = 0; 
                                            foreach( $search_exploded as $search_each ) 
                                            {
                                                  $x++;
                                                  $construct = " ";
                                                  if( $x == 1 )
                                                  {
                                                         $construct .= "school_type LIKE '%$search_each%' ";
                                                  }
                                                  else
                                                  {
                                                         $construct .= "AND school_type LIKE '%$search_each%' ";
                                                  }
                                            }
                                            $construct = "SELECT school_type FROM school WHERE $construct";
                                        }
                                        if(trim(filter_input(INPUT_GET,"filter")) === "physical_address")
                                        {
                                            $search_exploded = explode ( " ",trim(filter_input(INPUT_GET,"search_school")));
                                            $x = 0; 
                                            foreach( $search_exploded as $search_each ) 
                                            {
                                                  $x++;
                                                  $construct = " ";
                                                  if( $x == 1 )
                                                  {
                                                         $construct .= "physical_address LIKE '%$search_each%' ";
                                                  }
                                                  else
                                                  {
                                                         $construct .= "AND physical_address LIKE '%$search_each%' ";
                                                  }
                                            }
                                            $construct = "SELECT * FROM school WHERE $construct";
                                        }
                                        $cursor = $database->Query($construct);
                                    }
                                    else 
                                    {
                                        $construct = "SELECT * FROM users_schools WHERE user_email = '".$GLOBALS['email']."'";
                                        $cursor = $database->Query($construct);
                                    }
                                    if($database->affected_rows > 0)
                                    {
                                        while($data = $cursor->fetch_array())
                                        {
                                            $count = $count + 1;
                                        }
                                    }
                                    if(isset($_GET['page']))
                                    {
                                        $page = (int)$_GET['page'];
                                        $construct =  $construct." LIMIT ".((intval($page)-1)*4)." , 4";
                                    }
                                    else
                                    {
                                        $construct =  $construct." LIMIT 4";
                                    }
                                    $point = $database->Query($construct);
                                    if($database->affected_rows > 0)
                                    {
                                        while($data = $point->fetch_array())
                                        {
                                            $schools_str = "";
                                            if(@count($data['school_name']) < 1)
                                            {
                                                $schools_str = "You are not connected to any school yet, click 'Register a school' tab to register a new school";
                                                $GLOBALS['we_have_a_school'] = FALSE;
                                            }
                                            else 
                                            {
                                                $file = new File();
                                                $array = $file->ListFilesInDir("../uploads/{$data['school_name']}/img/badge/");
                                                foreach ($array as $value) 
                                                {
                                                    $logo_pointer = $value;
                                                }
                                                if($logo_pointer === "-1")
                                                {
                                                    $logo_pointer = "../assets/img/badge_default.png";
                                                }
                                                $GLOBALS['we_have_a_school'] = TRUE;
                                                $GLOBALS['school_name'] = $data['school_name'];
                                                $sql = "SELECT * FROM school WHERE school_name = '{$GLOBALS['school_name']}' LIMIT 1";
                                                $info = $database->Query($sql)->fetch_array();
                                                ?>
                                                <div class="panel panel-back col-lg-12 col-md-12 col-sm-12" style=" margin-top: 10px;">
                                                        <div class="panel-body">   
                                                            <div class="panel panel-default">
                                                                <div class="panel-body">
                                                                    <div class="col-lg-1 col-md-1 col-sm-12" id="old_height">
                                                                        <img class="img-responsive" src="<?php echo($logo_pointer);?>"/>
                                                                    </div>
                                                                    <div class="col-lg-8 col-md-8 col-sm-12" id="old_height">
                                                                        <h3><?php echo($data['school_name']);?></h3>
                                                                    </div>
                                                                    <div class="col-lg-1 col-md-1 col-sm-12" id="old_height">
                                                                        <a style="margin-top: 20px;" class="btn btn-success" title="Click to manage your school" href="school/?s=<?php echo($GLOBALS['school_name']); ?>">
                                                                            Manage 
                                                                        </a>
                                                                    </div>
                                                                    <div class="col-lg-1 col-md-1 col-sm-12" id="old_height">
                                                                        <a href="school/students/?s=<?php echo($data['school_name']);?>" style="margin-top: 20px;" class="btn btn-success" title="Click to apply to be enroled">
                                                                            Apply
                                                                        </a>
                                                                    </div>
                                                                    <div class="col-lg-1 col-md-1 col-sm-12" id="old_height">
                                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo($data['id']); ?>">
                                                                            <i class="fa fa-info-circle fa-2x" style=" margin-top: 25px;" title="Click to view more information"></i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="collapse_<?php echo($data['id']); ?>" class="panel-collapse collapse">
                                                                <table class="table table-hover table-bordered table-striped">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>Name of school</td>
                                                                            <td><?php echo($info['school_name']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Type of school</td>
                                                                            <td><?php echo($info['school_type']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Email</td>
                                                                            <td><?php echo($info['email']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Postal Address</td>
                                                                            <td><?php echo($info['postal_address']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Physical Address</td>
                                                                            <td><?php echo($info['physical_address']); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Phone Numbers</td>
                                                                            <td><?php echo($info['phone_numbers']); ?></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php 
                                            }
                                        }
                                    }
                                    else
                                    {
                                       $GLOBALS['message'] = "Error occured while we searched, please try using different keywords to find what you are looking for"; 
                                    }
                                ?>
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <div class="col-lg-4 col-sm-12 col-md-4"></div>
                                        <div class="col-lg-4 col-sm-12 col-md-4">
                                        <?php 
                                        if($GLOBALS['we_have_a_school'] === TRUE)
                                        {
                                            $url_str = "";
                                            if(isset($_GET['search_school']))
                                            {
                                                $url_str = "&search_school=".trim(filter_input(INPUT_GET,"search_school")).
                                                        "&filter=".trim(filter_input(INPUT_GET,"filter"));
                                            }
                                            $pagenator = new JasonGrimes\Paginator($count,4, $page = isset($_GET['page']) ? intval($_GET['page']):1,"./?page=(:num){$url_str}");
                                            echo($pagenator);
                                        }?>
                                        </div>
                                        <div class="col-lg-4 col-sm-12 col-md-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="new_school">
                            <div class="panel panel-primary">
                                <div class="panel-body">
                                    <h3>Register new school here</h3>
                                    <div class="custom_underline"></div>
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="container-fluid">
                                                <div class="well well-sm text-center text-warning">
                                                    Please write N/A where not applicable
                                                </div>
                                                <div id="ajax_response" style="display:none" class="well well-lg">
                                                    <button type="button" class="close">&times;</button>
                                                    <div class="progress progress-striped" style="width:100%">
                                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"  aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                                            <span class="sr-only">0%</span>
                                                        </div>
                                                    </div>         
                                                    <div id="status1"></div>	
                                                </div>
                                                <?php if(isset($_GET['sch_w'])): ?>
                                                <div id="ajax_response" style="display:block" class="well well-lg">
                                                    <button type="button" class="close">&times;</button>
                                                    <div class="alert alert-warning">
                                                    <?php echo($_GET['sch_w']); ?>
                                                    </div>         
                                                </div>
                                                <?php endif; ?>
                                                <?php if(isset($_GET['sch_s'])): ?>
                                                <div id="ajax_response" style="display:block" class="well well-lg">
                                                    <button type="button" class="close">&times;</button>
                                                    <div class="alert alert-success">
                                                    <?php echo($_GET['sch_s']); ?>
                                                    </div>         
                                                </div>
                                                <?php endif; ?>
                                                <form class="form-horizontal" method="post" action="school/School.php">
                                                    <div class="form-group">
                                                        <label for="school_name">Name of the school</label>
                                                        <input class="form-control" name="school_name" type="text" placeholder="Name of the school" title="Name of the school" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="school_type">Type of school</label>
                                                        <input class="form-control" name="school_type" type="text" placeholder="Type of school" title="Type of school" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="school_email">School's Email</label>
                                                        <input class="form-control" name="school_email" type="text" placeholder="School's Email" title="School's Email" required/>
                                                    </div>   
                                                    <div class="form-group">
                                                        <label for="school_address">School's postal address</label>
                                                        <input class="form-control" name="school_address" type="text" placeholder="School's postal address" title="School's postal address" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="physical_address">School's physical address</label>
                                                        <input class="form-control" name="physical_address" type="text" placeholder="School's physical address" title="School's physical address" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="school_phone">School's phone numbers</label>
                                                        <input class="form-control" name="school_phone" type="text" placeholder="School's phone numbers" title="School's School's phone numbers" required/>
                                                    </div>
                                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                                        <div class="col-lg-3 col-md-3 col-sm-12"></div>
                                                        <div class="col-lg-5 col-md-5 col-sm-12">
                                                            <div class="form-group">
                                                                <input class="form-control btn btn-sm btn-info" name="save" type="submit" value="Register School" title="Register School" required/>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Reports">
                            <div class="panel panel-primary">
                                <div class="panel-body">
                                    <h3>Check out reports here</h3>
                                    <div class="custom_underline"></div>
                                    <div class="container" style=" margin-top: 10px;">

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Library">
                            <div class="panel panel-primary">
                                <div class="panel-body">
                                    <h3>Library</h3>
                                    <div class="custom_underline"></div>
                                    <div class="container" style=" margin-top: 10px;">
                                        <ul class="list-group">
                                            <li class="list-group-item">View Books</li>
                                            <li class="list-group-item">Borrow Book</li>
                                            <li class="list-group-item">Search Book</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
        </div>       
    </div> 
    </body>  
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/Sessions.js"></script>
    <script src="../assets/js/loading.js"></script> 
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="../assets/js/custom.js"></script>
    <script src="../assets/js/jquery.form.js"></script>
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>    
    <script>
    var hidden = true;
    $("#searchbox").hide("slow");
    $("#hide_show_search").click(function()
    {
        if(hidden)
        {
            $("input[name=search]").show("slow");//.val("Visible");
            $("input[name=search]").focus();
            hidden = false;
        }
        else
        {
            $("input[name=search]").hide("slow");//.val("Hidden");
            hidden = true;
        }
    });
    </script>
    <script>
        var param2 = GetQueryVariable("sch_s");
        var param3 = GetQueryVariable("sch_w");
        if(param2 !== null && param2 !== "" || param3 !== null && param3 !== "")
        {
            $('#myTab a[href="#new_school"]').tab('show');
        }
    </script>
    <script>
        Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });
    </script>
</html>