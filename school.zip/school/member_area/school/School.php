<?php
session_start();
include("../../assets/classes/Database.php");
include("../../assets/classes/Sessions.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$GLOBALS['message'] = "";
$database = Connect();
$save_button = trim(filter_input(INPUT_POST,"save"));
if(isset($save_button) == true && $save_button !== '')
{
        $sql = "INSERT INTO school "
              ."VALUES(0,"
              ."'".trim(filter_input(INPUT_POST,"school_name"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_type"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_email"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_address"))."',"
              ."'".trim(filter_input(INPUT_POST,"physical_address"))."',"
              ."'".trim(filter_input(INPUT_POST,"school_phone"))."',"
              ."'')";
        $database->Query($sql);
        $sql = "INSERT INTO users_schools "
               ."VALUES(0,"
               ."'".$_SESSION['email']."',"
               ."'ADMIN',"
               ."'".trim(filter_input(INPUT_POST,"school_name"))."')";
        if($database->Query($sql))
        {
            $GLOBALS['message'] = "sch_s=You have successfully registered a new school";
        }
        else
        {
            $GLOBALS['message'] = "sch_w=".$database->error;
        }
}
?>
<script>
    document.location = "../?<?php echo($GLOBALS['message']); ?>";
</script>