<?php
session_start();
include("../../assets/classes/Database.php");
include("../../assets/classes/Sessions.php");
include("../../assets/classes/File.php");
include("../../assets/classes/Paginator.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}

$database = Connect();
$register_new_coordinates = trim(filter_input(INPUT_POST,"register_new_coordinates"));
if(!isset($register_new_coordinates) !== true && $register_new_coordinates !== '')
{
    $sql = "SELECT school_name FROM school WHERE id = ".trim(filter_input(INPUT_POST,"id"));
    $cursor = $database->Query($sql);
    $old_school_name = $cursor->fetch_array()['school_name'];    

    $sql = "UPDATE school "
            . "SET coordinates = ''"
            . "WHERE school_name = '$old_school_name'";
    $database->Query($sql);
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "You have successfully saved $old_school_name's physical address";
    }
    else
    {
        $GLOBALS['message'] = $database->error;
    }
    
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}

$update_button = trim(filter_input(INPUT_POST,"update"));
if(!isset($update_button) !== true && $update_button !== '')
{
    $sql = "SELECT school_name FROM school WHERE id = ".trim(filter_input(INPUT_POST,"id"));
    $cursor = $database->Query($sql);
    $old_school_name = $cursor->fetch_array()['school_name'];
    
    $sql = "UPDATE school "
          ."SET "
          ."school_type = '".trim(filter_input(INPUT_POST,"school_type"))."',"
          ."email = '".trim(filter_input(INPUT_POST,"school_email"))."',"
          ."postal_address = '".trim(filter_input(INPUT_POST,"school_address"))."',"
          ."physical_address = '".trim(filter_input(INPUT_POST,"physical_address"))."',"
          ."phone_numbers = '".trim(filter_input(INPUT_POST,"school_phone"))."' "
          ."WHERE id = ".trim(filter_input(INPUT_POST,"id"));
    $database->Query($sql);
    
    if($database->affected_rows >= 1)
    {
        array_map('unlink', glob("../../uploads/$old_school_name"));//delete the folder
        $GLOBALS['message'] = "You have successfully upadated {$_GET['s']}'s information";
    }
    else
    {
        $GLOBALS['message'] = $database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}
$register_level_button = trim(filter_input(INPUT_POST,"register_level"));
if(!isset($register_level_button) !== true && $register_level_button !== '')
{
    $sql = "INSERT INTO levels "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"level_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"duration"))."',"
          ."'".trim(filter_input(INPUT_POST,"school"))."')";
    $database->Query($sql);
    
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "You have successfully added a level to your school";
    }
    else
    {
        $GLOBALS['message'] = $database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school"))."&msg={$GLOBALS['message']}");    
}

$update_level_button = trim(filter_input(INPUT_POST,"update_level"));
if(!isset($update_level_button) !== true && $update_level_button !== '')
{
    $sql = "UPDATE levels "
          ."SET "
          ."level_name = '".trim(filter_input(INPUT_POST,"level_name"))."', "
          ."duration = '".trim(filter_input(INPUT_POST,"level_duration"))."' "
          ."WHERE school = '".trim(filter_input(INPUT_POST,"school"))."' "
          ."AND id = '".trim(filter_input(INPUT_POST,"id"))."'";
    $database->Query($sql);
    
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "You have successfully updated the level";
    }
    else
    {
        $GLOBALS['message'] = $database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school"))."&msg={$GLOBALS['message']}");    
}

$register_staff = trim(filter_input(INPUT_POST,"register_staff"));
if(!isset($register_staff) !== true && $register_staff !== '')
{
    $sql = "INSERT INTO staff "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"firstname"))."',"
          ."'".trim(filter_input(INPUT_POST,"lastname"))."',"
          ."'".trim(filter_input(INPUT_POST,"email"))."',"
          ."'".trim(filter_input(INPUT_POST,"phone"))."',"
          ."'".trim(filter_input(INPUT_POST,"school"))."',"
          ."'".trim(filter_input(INPUT_POST,"job"))."',"
          ."'".trim(filter_input(INPUT_POST,"employed_since"))."',"
          ."'".trim(filter_input(INPUT_POST,"highest_qulifications"))."')";
    $database->Query($sql);
   
    $sql = "SELECT id FROM staff WHERE email = '".trim(filter_input(INPUT_POST,"email"))."'";
    $id = $database->Query($sql)->fetch_array()['id'];

    $new_dir = "../../uploads/".trim(filter_input(INPUT_POST,"school"))."/docs/contracts/$id/";
    if(!(is_dir($new_dir)))
    {
        mkdir($new_dir,0777,TRUE);
    }
    else 
    {
        array_map('unlink', glob("$new_dir/*.*"));//delete all contents of the folder
    }
    $target_dir = $new_dir;
    $target_file = $target_dir.@basename($_FILES["contract"]["name"]);
    
    $FileType = pathinfo($target_file,PATHINFO_EXTENSION);

    if($FileType === "pdf" or $FileType === "docx" or $FileType === "doc")
    {
        if(@move_uploaded_file($_FILES["contract"]["tmp_name"], $target_file))
        {
            $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Contract successfully saved";
        }
        else
        {
            $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Contract was not saved successfully";
        }
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Only files with extension : .doc, pdf and .docx can be uploaded";
    }    
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully saved a staff member details";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>An error occured while capturing staff memeber details : ".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school"))."&msg={$GLOBALS['message']}");
}
$register_course = trim(filter_input(INPUT_POST,"register_course"));
if(!isset($register_course) !== true && $register_course !== '')
{
    $sql = "INSERT INTO courses "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"course_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"level_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"school_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"teacher_name"))."')";
    $database->Query($sql);
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have added a course";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}
$update_course = trim(filter_input(INPUT_POST,"update_course"));
if(!isset($update_course) !== true && $update_course !== '')
{
    $sql = "UPDATE courses "
          ."SET "
          ."course_name = '".trim(filter_input(INPUT_POST,"course_name"))."' , "
          ."level_name = '".trim(filter_input(INPUT_POST,"level_name"))."' , "
          ."school_name = '".trim(filter_input(INPUT_POST,"school_name"))."' , "
          ."teacher_name = '".trim(filter_input(INPUT_POST,"teacher_name"))."' "
          ."WHERE id = '".trim(filter_input(INPUT_POST,"id"))."'";
    if($database->Query($sql))
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully updated the course";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}
$register_group = trim(filter_input(INPUT_POST,"register_group"));
if(!isset($register_group) !== true && $register_group !== '')
{
    $sql = "INSERT INTO groups "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"group_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"group_leader_teacher"))."',"
          ."'".trim(filter_input(INPUT_POST,"group_leader_student"))."',"
          ."'".trim(filter_input(INPUT_POST,"current_year"))."',"
          ."'".trim(filter_input(INPUT_POST,"school_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"level_name"))."')";
    $database->Query($sql);
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully regitered a group or class";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}
if(isset($_GET['dgc']))
{
    $sql = "DELETE FROM groups WHERE id = '{$_GET['dgc']}'";
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully deleted a group or class";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s={$_GET['s']}&msg={$GLOBALS['message']}");
}
$update_group = trim(filter_input(INPUT_POST,"update_group"));
if(!isset($update_group) !== true && $update_group !== '')
{
    $sql = "UPDATE groups "
          ."SET "
          ."group_name = '".trim(filter_input(INPUT_POST,"group_name"))."' , "
          ."group_leader_teacher = '".trim(filter_input(INPUT_POST,"group_leader_teacher"))."' , "
          ."group_leader_student = '".trim(filter_input(INPUT_POST,"group_leader_student"))."' , "
          ."current_year = '".trim(filter_input(INPUT_POST,"current_year"))."' , "
          ."school_name = '".trim(filter_input(INPUT_POST,"school_name"))."' , "
          ."level_name = '".trim(filter_input(INPUT_POST,"level_name"))."' "
          ."WHERE id = '".trim(filter_input(INPUT_POST,"id"))."'";
    $database->Query($sql);
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully updated a group or class";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_name"))."&msg={$GLOBALS['message']}");
}
$update_staff = trim(filter_input(INPUT_POST,"update_staff"));
if(!isset($update_staff) !== true && $update_staff !== '')
{
    $sql = "UPDATE staff "
          ."SET "
          ."firstname = '".trim(filter_input(INPUT_POST,"firstname"))."', "
          ."lastname = '".trim(filter_input(INPUT_POST,"lastname"))."', "
          ."email = '".trim(filter_input(INPUT_POST,"email"))."', "
          ."phone = '".trim(filter_input(INPUT_POST,"phone"))."', "
          ."school = '".trim(filter_input(INPUT_POST,"school"))."', "
          ."job = '".trim(filter_input(INPUT_POST,"job"))."', "
          ."employed_since = '".trim(filter_input(INPUT_POST,"employed_since"))."', "
          ."highest_qulifications = '".trim(filter_input(INPUT_POST,"highest_qulifications"))."' "
          ."WHERE id = '".trim(filter_input(INPUT_POST,"id"))."'";
    $database->Query($sql);
    
    $new_dir = "../../uploads/".trim(filter_input(INPUT_POST,"school"))."/docs/contracts/".trim(filter_input(INPUT_POST,"id")."/");
    if(!(is_dir($new_dir)))
    {
        mkdir($new_dir,0777,TRUE);
    }
    else 
    {
        array_map('unlink', glob("$new_dir/*.*"));//delete all contents of the folder
    }
    $target_dir = $new_dir;
    $target_file = $target_dir.@basename($_FILES["contract"]["name"]);
    
    $FileType = pathinfo($target_file,PATHINFO_EXTENSION);

    if($FileType === "pdf" or $FileType === "docx" or $FileType === "doc")
    {
        if(@move_uploaded_file($_FILES["contract"]["tmp_name"], $target_file))
        {
            $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Contract successfully updated";
        }
        else
        {
            $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Contract was not updated successfully";
        }
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>Only files with extension : .doc, pdf and .docx can be uploaded";
    }    
    if($database->affected_rows >= 1)
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>You have successfully updated a staff member details";
    }
    else
    {
        $GLOBALS['message'] = "{$GLOBALS['message']}<br/>".$database->error;
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school"))."&msg={$GLOBALS['message']}");
}
if(@basename( $_FILES["school_logo"]["name"]) != "")
{
    $sql = "SELECT school_name FROM school WHERE id = ".trim(filter_input(INPUT_POST,"id"));
    $cursor = $database->Query($sql);
    $old_school_name = $cursor->fetch_array()['school_name'];

    $new_dir = "../../uploads/$old_school_name/img/badge/";
    if(!(is_dir($new_dir)))
    {
        mkdir($new_dir,0777,TRUE);
    }
    else 
    {
        array_map('unlink', glob("$new_dir/*.*"));//delete all contents of the folder
    }
    $target_dir = $new_dir;
    $target_file = $target_dir.@basename($_FILES["school_logo"]["name"]);

    //cheking if a file is a real document
    $FileType = pathinfo($target_file,PATHINFO_EXTENSION);

    if($FileType === "png" or $FileType === "bmp" or $FileType === "jpeg" or 
            $FileType === "jpg" or $FileType === "gif" or $FileType === "tif")
    {
        if(@move_uploaded_file($_FILES["school_logo"]["tmp_name"], $target_file))
        {
            $GLOBALS['message'] = "Badge or logo successfully saved";
        }
        else
        {
            $GLOBALS['message'] = "Your school's badge or logo was not saved successfully";
        }
    }
    else
    {
        $GLOBALS['message'] = "Only files with extension : .png, bmp, jpeg, jpg, gif, tif can be uploaded";
    }
    header("location:./?s=$old_school_name&msg={$GLOBALS['message']}");
}

$GLOBALS['schools'] = "";
$GLOBALS['message'] = "";

if(isset ($_GET['d']))
{
    $str = "DELETE FROM users_schools WHERE school_name = '{$_GET['d']}' AND user_email = '{$_SESSION['email']}'";
    $result = $database->Query($str);
    
    $str = "DELETE FROM school WHERE school_name = '{$_GET['d']}'";
    $result = $database->Query($str);
    
    header("location:../?msg=Successfully deleted school");
}
if(isset($_GET['dl']))
{
    $str = "DELETE FROM levels WHERE school = '{$_GET['s']}' AND level_name = '{$_GET['dl']}'";
    $database->Query($str);
    header("location:./?s={$_GET['s']}&msg=Successfully deleted the level");    
}
if(isset($_GET['ds']))
{
    $str = "DELETE FROM staff WHERE school = '{$_GET['s']}' AND id = '{$_GET['ds']}'";
    $database->Query($str);
    header("location:./?s={$_GET['s']}&msg=Successfully deleted the staff member");    
}
$GLOBALS['email'] = $_SESSION['email'];

$file = new File();
$array = $file->ListFilesInDir("../../uploads/{$_GET['s']}/img/badge/");
foreach ($array as $value) 
{
    $logo_pointer = $value;
}
if($logo_pointer === "-1")
{
    $logo_pointer = "../../assets/img/badge_default.png";
}
if(isset($_GET['msg']))
{
    $GLOBALS['message'] = $_GET['msg'];
}

if(isset($_GET['s']))
{
    if($_GET['s'] === "non")
    {
        $logo_pointer = "../../assets/img/badge_default.png";
        $GLOBALS['schools'] = "New school registration";
    }
    else
    {
        $GLOBALS['schools'] = $_GET['s'];
    }
}
else
{
    //header("location:../");
}
$search_keywords = trim(filter_input(INPUT_POST,"search"));
if(!isset($search_keywords) !== true && $search_keywords !== '')
{
    $GLOBALS['message'] = "We are yet to make the searching work";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="../../assets/img/logo_brand_no_bg.png" />
        <link href="../../assets/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="../../assets/css/custom.css" rel="stylesheet"/>
        <script src="../../assets/js/jquery-1.10.2.js"></script>       
        <script src="../../assets/js/pace.min.js"></script>
        <link href="../../assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">        
        <link href="../../assets/css/font-awesome.min.css" rel="stylesheet"/>
        <link href="../../assets/css/simple-sidebar.css" rel="stylesheet">
        <link href="../../assets/css/loading.css" type="text/css" rel="stylesheet">
        <!-- FONTAWESOME STYLES-->
        <link href="../../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- GOOGLE FONTS-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
        <!--------------------------map----------------------------->
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css"/>
	<!-------------------------end map--------------------------->
        <title>School management system</title>
    </head>
    <body>
        <div class="cover"></div>
        <div id="wrapper">
            <div id="sidebar-wrapper">
                <ul class="sidebar-nav" style="margin-top: 20%">
                    <li class="sidebar-brand">
                        <a href="#">
                            Menu
                        </a>
                    </li>
                    <li class="active">
                        <a href="../" id="Schools"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;My Schools</a>
                    </li>
                    <li>
                        <a href="../My_Account/" id="Schools"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;My Account</a>
                    </li>
                    <li>
                        <a href="../messages/" id="Messages"><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Messages</a>
                    </li>
                    <li><a href="../notifications/" id="Notifications"><i class="fa fa-bell"></i>&nbsp;&nbsp;&nbsp;Notifications</a></li>
                </ul>
            </div>
            <div id="page-content-wrapper">
                <div id="overlay">
                    <div id="text">
                        <img style="width: 50%;height: 50%" src="../../assets/img/loading.gif" alt="loading"/>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="container">
                        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                            <div class="container">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="../../"><u style="color: white;">Magegethe</u></a>
                                    <a class="navbar-brand" href="#menu-toggle" title="Toggle menu" class="btn btn-secondary" id="menu-toggle">&nbsp;&nbsp;&nbsp;<i class="fa fa-bars fa-1x"></i>&nbsp;&nbsp;Menu</a>
                                </div>
                                <div id="navbar" class="navbar-collapse collapse">
                                    <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                                        <li>
                                            <div>
                                                <form class="navbar-form form-inline" method="post" action="./">
                                                    <input id="searchbox" style="width:330px" class="form-control" type="text" name="search" placeholder="Type your search keywords then click enter"/>
                                                </form>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#" id="hide_show_search"><i class="fa fa-search"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" 
                                               data-toggle="dropdown" role="button" 
                                               aria-expanded="false">
                                                   <?php echo($GLOBALS['email'])?>
                                                <b class="caret"></b>
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li><a href="../My_Account/">Account</a></li>
                                                <li><a href="../../logout.php">Sign out</a></li>               
                                            </ul>
                                        </li>                            
                                    </ul>           
                                </div>
                            </div>
                        </nav>
                    </div>
                    <div class="container-fluid" style="margin-top: 3%">
                        <ol class="breadcrumb">
                            <li><a href="../">My Schools</a></li>
                            <li><a href="./?s=<?php echo($_GET['s']) ?>"><?php echo($GLOBALS['schools']) ?></a></li>
                        </ol>
                    </div>
                    <div class="container-fluid">
                        <ul id="myTab" class="nav nav-tabs panel-back" style="background-color: #F3F3F3">
                            <li class="active">
                                <a href="#about" data-toggle="tab"><?php echo($GLOBALS['schools']) ?></a>
                            </li>
                            <li><a href="#levels" data-toggle="tab">Levels</a></li>
                            <li><a href="#Groups" data-toggle="tab">Groups or Classes</a></li>
                            <li><a href="#Courses" data-toggle="tab">Courses / modules or subjects</a></li>
                            <li><a href="#Students" data-toggle="tab">Students</a></li>
                            <li><a href="#staff" data-toggle="tab">Staff</a></li>
                            <li><a href="#library" data-toggle="tab">Library</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div class="tab-pane fade in active panel-back" id="about">
                                <?php if(@$_GET['s'] === "non"): ?>
                                <div class="jumbotron">This part of the page is reserved</div>
                                <?php endif; ?>
                                <?php if(@$_GET['s'] !== "non"): ?>
                                <!-------------------------------[ My school details section ]------------------------------------------------>
                                <div class="panel panel-default panel-back" id="editPanel">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <div class="container-fluid text-center">
                                                <div class="col-sm-12 col-md-1 col-lg-1">
                                                    <img class="img-responsive" src="<?php echo($logo_pointer); ?>" alt="<?php echo($GLOBALS['schools']); ?>" style="width: 30px;height: 30px;" title="School's logo"/>
                                                </div>
                                                <div class="col-sm-12 col-md-10 col-lg-10">
                                                    <h4>Edit <?php echo($GLOBALS['schools']);?>'s information</h4>
                                                </div>
                                                <div class="col-sm-12 col-md-1 col-lg-1">
                                                    <button id="closeEdit" class="btn btn-default" id="editButton">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <div class="container-fluid">
                                            <div  class="col-lg-4 col-md-4 col-sm-12" style="padding:2%">
                                                <div id="the_new_length" class="panel panel-info panel-back">
                                                    <div class="panel-heading">School's general information</div>
                                                    <div class="panel-body">
                                                        <div class="container-fluid">
                                                            <div class="well well-sm text-center text-warning">
                                                                Please write N/A where not applicable
                                                            </div>
                                                            <form id="forms" class="form-horizontal" method="post" action="">
                                                                <div class="form-group">
                                                                    <input class="form-control" name="school_name" type="text" placeholder="Name of the school" title="Name of the school" required disabled/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input class="form-control" name="school_type" type="text" placeholder="Type of school" title="Type of school" required/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input class="form-control" name="school_email" type="text" placeholder="School's Email" title="School's Email" required/>
                                                                </div>   
                                                                <div class="form-group">
                                                                    <input class="form-control" name="school_address" type="text" placeholder="School's postal address" title="School's postal address" required/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input class="form-control" name="physical_address" type="text" placeholder="School's physical address" title="School's physical address" required/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input class="form-control" name="school_phone" type="text" placeholder="School's phone numbers" title="School's School's phone numbers" required/>
                                                                </div>
                                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                                    <div class="col-lg-3 col-md-3 col-sm-12"></div>
                                                                    <div class="col-lg-5 col-md-5 col-sm-12">
                                                                        <div class="form-group">
                                                                            <?php
                                                                            $cursor = $database->Query("SELECT id FROM school WHERE school_name = '{$GLOBALS['schools']}'");
                                                                            $id = $cursor->fetch_array()['id'];
                                                                            echo("<input name=\"id\" type=\"text\" value=\"$id\" style=\"display:none;\" required/>");
                                                                            ?>
                                                                            <input class="form-control btn btn-sm btn-info" name="update" type="submit" value="Update School" title="Update School" required/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div  class="col-lg-4 col-md-4 col-sm-12 text-center" style="padding: 2%">
                                                <div id="the_new_length" class="panel panel-info panel-back">
                                                    <div class="panel-heading">School's badge / logo</div>
                                                    <div class="panel-body">
                                                        <div class="form-group">
                                                            <a href="#" id="file_upload_trigger_tag">
                                                                <img id="new_image" class="img-responsive" src="<?php echo($logo_pointer); ?>" alt="logo" style="width: 100%;height: 320px;" title="School's logo"/>
                                                            </a>
                                                            <form id="Schools_badge_form" name="badge" action="./" method="POST" enctype="multipart/form-data">
                                                                <?php
                                                                $cursor = $database->Query("SELECT id FROM school WHERE school_name = '{$GLOBALS['schools']}'");
                                                                $id = $cursor->fetch_array()['id'];
                                                                echo("<input name=\"id\" type=\"text\" value=\"$id\" style=\"display:none;\" required/>");
                                                                ?>
                                                                <input id="file_upload_tag" class="form-control" name="school_logo" type="file" placeholder="School's logo" style="display:non;visibility:hidden" required/>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div  class="col-lg-4 col-md-4 col-sm-12" style="padding: 2%">
                                                <div id="the_length_i_need" class="panel panel-info panel-back">
                                                    <div class="panel-heading">School's Physical Location</div>
                                                    <div class="panel-body">
                                                        <div>
                                                            <form class="form-inline" action="./" method="post">
                                                                <div class="form-group">
                                                                    <?php
                                                                    $cursor = $database->Query("SELECT id FROM school WHERE school_name = '{$_GET['s']}'");
                                                                    $id = $cursor->fetch_array()['id'];
                                                                    echo("<input name=\"id\" type=\"text\" value=\"$id\" style=\"display:none;\" required/>");
                                                                    ?>
                                                                    <input class="form-control" name="school_street" type="text" placeholder="School's physical address" title="School's physical address" required/>
                                                                    <input type="text" value="My coordinates" name="school_coordinates" class="hidden"/>
                                                                    <input type="submit" class="btn btn-primary" name="register_new_coordinates" value="Save Address"/>
                                                                </div>
                                                            </form>
                                                            <button class="btn btn-success" id="toggole_map" style="margin-bottom: 20px;">Use location Services</button>
                                                        </div>
                                                        <div>
                                                            <div id="mapid" style="width: 100%; height: 300px;"></div>
                                                        </div>
                                                    </div>
                                                </div>                          
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default panel-back" id="infoPanel">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <div class="container-fluid">
                                                <div class="col-lg-9 col-md-9 col-sm-12">
                                                    <h4><?php echo($GLOBALS['schools']);?></h4>
                                                </div>
                                                <div class="col-lg-3 col-md-3 col-sm-12">
                                                    <button class="btn btn-default" id="editButton">Edit</button>
                                                    <a id="deleteButton" href="#" class="btn btn-danger" id="editButton">Remove school</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <div class="col-sm-12 col-lg-2 col-md-2">
                                            <img class="img-responsive img-thumbnail" style="height:225px;" src="<?php echo($logo_pointer); ?>" alt="<?php echo($logo_pointer); ?>"/>
                                        </div>
                                        <div class="col-sm-12 col-lg-10 col-md-10">
                                            <table class="table table-responsive table-hover table-bordered">
                                                <tbody>
                                                    <tr><?php 
                                                    $dataPointer = $database->Query("SELECT * FROM school WHERE school_name = '{$GLOBALS['schools']}'");
                                                    while($data = $dataPointer->fetch_array())
                                                    {
                                                        $str = ""
                                                        ."<td>Name</td>"
                                                        ."<td>".$data['school_name']."</td>"
                                                    ."</tr>"
                                                        ."<td>Type of school</td>"
                                                        ."<td>".$data['school_type']."</td>"
                                                    ."<tr>"
                                                        ."<td>Email</td>"
                                                        ."<td>".$data['email']."</td>"
                                                    ."</tr>"
                                                    ."<tr>"
                                                        ."<td>Postal Address</td>"
                                                        ."<td>".$data['postal_address']."</td>"
                                                    ."</tr>"
                                                    ."<tr>"
                                                        ."<td>Physical Address</td>"
                                                        ."<td>".$data['physical_address']."</td>"
                                                    ."</tr>"
                                                    ."<tr>"
                                                        ."<td>Phone Numbers</td>"
                                                        ."<td>".$data['phone_numbers']."</td>";
                                                        echo($str);
                                                    }
                                                        ?>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <!-------------------------------[ Levels section ]------------------------------------------------>
                            <div class="tab-pane fade" id="levels">
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> 
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                                Add new level to <?php echo($GLOBALS['schools']); ?>
                                                <i class=" fa fa-plus"></i>
                                            </a>
                                        </a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse">
                                        <div class="panel-body container">
                                            <div class="well well-sm text-center text-warning">
                                                Please write N/A where not applicable
                                            </div>
                                            <form class="form-inline" action="./?s=<?php echo($GLOBALS['schools']); ?>" method="post">
                                                <div class="form-group">
                                                    <input class="form-control" type="text" name="level_name" placeholder="level_name" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control" type="text" name="duration" placeholder="level_duration" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input style="display: none;" type="text" name="school" value="<?php echo($GLOBALS['schools']); ?>"/>
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control btn btn-success" type="submit" name="register_level" value="Register_level"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-body">
                                <?php 
                                $sql = "SELECT id,level_name,duration FROM levels WHERE school = '{$GLOBALS['schools']}'";
                                $database->Query($sql);
                                if($database->affected_rows > 0)
                                {
                                    $sql = "SELECT * FROM levels WHERE school = '{$GLOBALS['schools']}'";
                                    $cursor = $database->Query($sql);
                                    $loop = 0;
                                    while ($data = $cursor->fetch_array()) 
                                    { ?>
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo($loop);?>">
                                                        <?php echo($data['level_name']); ?>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapse_<?php echo($loop);?>" class="panel-collapse collapse">
                                                <div class="panel-body">
                                                    <table class="table table-responsive table-hover table-bordered">
                                                        <tbody>
                                                            <form action='./' method='post' class='form-inline'>
                                                                <tr>
                                                                    <td>
                                                                        Level name
                                                                    </td>
                                                                    <td>
                                                                        <input id='levels_form_control_<?php echo($loop);?>' type='text' class='form-control' name='level_name' value='<?php echo($data['level_name']);?>' disabled/>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Level duration
                                                                    </td>
                                                                    <td>
                                                                        <input id='levels_form_control_<?php echo($loop);?>' type='text' class='form-control' name='level_duration' value='<?php echo($data['duration']);?>' disabled/>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Students
                                                                    </td>
                                                                    <td>
                                                                        <a href='students/?s=<?php echo($GLOBALS['schools']."&lv=".$data['level_name']);?>' class='btn btn-primary btn-sm'>
                                                                            Students
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Delete Level
                                                                    </td>
                                                                    <td>
                                                                        <a id='levels_form_control_delete_<?php echo($loop);?>' href='./?s=<?php echo($GLOBALS['schools']."&dl=".$data['level_name']);?>' class='btn btn-warning btn-sm disabled'>
                                                                            Delete Level
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Edit Level
                                                                    </td>
                                                                    <td>
                                                                        <a id='edit_levels' class='btn btn-primary btn-sm'>
                                                                            <span style='display:none' id='selected_pencil'><?php echo($loop);?></span>
                                                                            <i class='fa fa-pencil'></i> Edit Level
                                                                        </a>
                                                                    </td>
                                                                <tr>
                                                                </tr>
                                                                    <td>
                                                                        Update Level
                                                                    </td>
                                                                    <td>
                                                                        <input style='display:none' type='text' name='school' value='<?php echo($data['school']);?>'/>
                                                                        <input style='display:none' type='text' name='id' value='<?php echo($data['id']);?>'/>
                                                                        <input id='levels_form_control_button_<?php echo($loop);?>' type='submit' class='form-control btn btn-sm btn-primary' name='update_level' value='Update' disabled/>
                                                                    </td>
                                                                <tr>
                                                            </form>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                <?php 
                                    $loop = $loop + 1;
                                    }
                                }
                                else
                                {
                                    ?>
                                        <div class="well well-lg">There are no levels that have been added</div>
                                    <?php
                                }
                                ?>
                                    </div>
                                </div>                
                            </div>
                            <!-------------------------------[ Groups section ]------------------------------------------------>
                            <div class="tab-pane fade" id="Groups">
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> 
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseGroup">
                                                Add new group or class to <?php echo($GLOBALS['schools']); ?>'s levels
                                                <i class=" fa fa-plus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseGroup" class="panel-collapse collapse">
                                        <div class="panel-body container">
                                            <div class="well well-sm text-center text-warning">
                                                Please write N/A where not applicable
                                            </div>
                                            <form class="form-horizontal" action="./" method="post">
                                                <div class="form-group">
                                                    <label for="group_name">Name of the group</label>
                                                    <input class="form-control" type="text" name="group_name" placeholder="Name of the group" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="group_leader_teacher">Teacher who leads the group</label>
                                                    <input class="form-control" type="text" name="group_leader_teacher" placeholder="Teacher who leads the group" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="group_leader_student">Student who leads the group</label>
                                                    <input class="form-control" type="text" name="group_leader_student" placeholder="Student who leads the group" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="current_year">current_year</label>
                                                    <input class="form-control" type="text" name="current_year" placeholder="current_year" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="level_name">The level that the group is at</label>
                                                    <select name="level_name" class="form-control" required>
                                                        <option value="">Select level</option>
                                                    <?php
                                                    $sql = "SELECT level_name FROM levels WHERE school = '{$_GET['s']}'"; 
                                                    $cursor = $database->Query($sql);
                                                    if($database->affected_rows > 0)
                                                    {
                                                        while($data = $cursor->fetch_array())
                                                        {
                                                        ?>
                                                        <option value="<?php echo($data['level_name']); ?>"><?php echo($data['level_name']); ?></option>
                                                        <?php
                                                        }
                                                    }
                                                    ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <input style="display: none;" type="text" name="school_name" value="<?php echo($_GET['s']); ?>"/>
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control btn btn-success" type="submit" name="register_group" value="Register Group"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-body">
                                <?php 
                                $sql = "SELECT * FROM groups WHERE school_name = '{$_GET['s']}'";
                                $cursor = $database->Query($sql);
                                if($database->affected_rows >= 1)
                                {
                                    while($data = $cursor->fetch_array())
                                    {
                                        $GLOBALS['id'] = $data['id'];
                                    ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> 
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo($data['id']); ?>">
                                                <?php echo($data['group_name']); ?>
                                            </a>
                                        </a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo($data['id']); ?>" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <table class="table table-responsive table-hover table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <form action="./" class="form-horizontal" method="POST">
                                                            <td>
                                                                Group Name
                                                            </td>
                                                            <td>
                                                                <input id="group_form_control_<?php echo($data['id']); ?>" type='text' class='form-control' name='group_name' value='<?php echo($data['group_name']);?>' disabled/>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Teacher leading the group
                                                            </td>
                                                            <td>
                                                                <input id='group_form_control_<?php echo($data['id']); ?>' type='text' class='form-control' name='group_leader_teacher' value='<?php echo($data['group_leader_teacher']);?>' disabled/>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Student leading the group
                                                            </td>
                                                            <td>
                                                                <input id='group_form_control_<?php echo($data['id']); ?>' type='text' class='form-control' name='group_leader_student' value='<?php echo($data['group_leader_student']); ?>' disabled/>
                                                            </td>
                                                    </tr> 
                                                    <tr>
                                                            <td>
                                                                Year
                                                            </td>
                                                            <td>
                                                                <input id='group_form_control_<?php echo($data['id']); ?>' type='text' class='form-control' name='current_year' value='<?php echo($data['current_year']); ?>' disabled/>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Level
                                                            </td>
                                                            <td>
                                                                <select id='group_form_control_<?php echo($data['id']); ?>' name="level_name" class="form-control" required>
                                                                    <?php 
                                                                    $sql = "SELECT level_name FROM groups WHERE group_name = '{$data['group_name']}'";
                                                                    $level = $database->Query($sql)->fetch_array()['level_name'];
                                                                    ?>
                                                                    <option value="<?php echo($level); ?>"><?php echo($level); ?></option>
                                                                <?php
                                                                $sql = "SELECT level_name FROM levels WHERE school = '{$_GET['s']}'"; 
                                                                $cursor = $database->Query($sql);
                                                                if($database->affected_rows > 0)
                                                                {
                                                                    while($data = $cursor->fetch_array())
                                                                    {
                                                                    ?>

                                                                    <option value="<?php echo($data['level_name']); ?>"><?php echo($data['level_name']); ?></option>
                                                                    <?php
                                                                    }
                                                                }
                                                                ?>
                                                                </select>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Delete
                                                            </td>
                                                            <td>
                                                                <a style="width: 20%" id='group_form_control_delete_<?php echo($GLOBALS['id']); ?>' href='./?s=<?php echo($_GET['s']); ?>}&dgc=<?php echo($GLOBALS['id']); ?>' class='btn btn-danger btn-sm disabled'>
                                                                    Delete
                                                                </a>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Edit
                                                            </td>
                                                            <td>
                                                                <a id='edit_group' class='btn btn-primary btn-sm' style="width: 20%">
                                                                    <span style='display:none' id='selected_pencil'><?php echo($GLOBALS['id']); ?></span>
                                                                    <i class='fa fa-pencil'></i> Edit group or class
                                                                </a>
                                                            </td>
                                                    </tr>
                                                    <tr>
                                                            <td>
                                                                Update
                                                            </td>
                                                            <td>
                                                                <input style='display:none' type='text' name='school_name' value='<?php echo($_GET['s']);?>'/>
                                                                <input style='display:none' type='text' name='id' value='<?php echo($GLOBALS['id']);?>'/>
                                                                <input id='group_form_control_button_<?php echo($GLOBALS['id']); ?>' style="width: 20%" type='submit' class='form-control btn btn-sm btn-primary' name='update_group' value='Update Group/Class' disabled/>
                                                            </td>
                                                        </form>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                    <?php
                                    }
                                }
                                else
                                {
                                    ?>
                                        <div class="well well-lg">There are no groups or classes that have been added</div>
                                    <?php
                                }
                                ?>
                                    </div>
                                </div>            
                            </div>
                            <!-------------------------------[ Courses section ]------------------------------------------------>
                            <div class="tab-pane fade" id="Courses">
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> 
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseCourse">
                                                Add a course, module or subject
                                                <i class=" fa fa-plus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseCourse" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <form class="form-horizontal" action="./?s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" method="post">
                                                <div class="container">
                                                    <div class="well well-sm text-center text-warning">
                                                        Please write N/A where not applicable
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="course_name">Course name</label>
                                                        <input class="form-control" type="text" name="course_name" placeholder="Name of the course" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="level_name">Level</label>
                                                        <select name="level_name" class="form-control" required>
                                                            <option value="">Choose the level that this course is taught</option>
                                                            <?php
                                                            $sql = "SELECT level_name FROM levels WHERE school = '{$_GET['s']}'";
                                                            $cursor = $database->Query($sql);
                                                            if($database->affected_rows >= 1)
                                                            {
                                                                while($data = $cursor->fetch_array())
                                                                {
                                                                    echo("<option value=\"{$data['level_name']}\">{$data['level_name']}</option>");
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="teacher_name">Teacher of the course</label>
                                                        <input class="form-control" type="text" name="teacher_name" placeholder="Teacher of the course" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <input style="display:none;" type="text" name="school_name" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                                        <input class="form-control btn btn-success" type="submit" name="register_course" value="Add course" required/>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>    
                                </div>
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-body"> 
                                <?php
                                $sql = "SELECT * FROM courses WHERE school_name = '{$_GET['s']}'";
                                $cursor = $database->Query($sql);
                                if($database->affected_rows >= 1)
                                {
                                    $loop = 0;
                                    while($data = $cursor->fetch_array())
                                    {
                                ?>
                                <div class="panel panel-default">
                                    <div class="panel-body container">
                                        <form action="./" method="post">
                                            <table class="table-hover table-bordered table-responsive table-striped">
                                                <tbody>
                                                    <tr>
                                                        <td>Name of the course</td>
                                                        <td>
                                                            <input id="course_form_control_<?php echo($loop); ?>" name="course_name" class="form-control" type="text" value="<?php echo($data['course_name']); ?>" disabled/>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Level</td>
                                                        <td>
                                                            <select id="course_form_control_<?php echo($loop); ?>" name="level_name" class="form-control" required>
                                                                <option value="">Choose the level that this course is taught</option>
                                                                <?php
                                                                $sql = "SELECT level_name FROM levels WHERE school = '{$_GET['s']}'";
                                                                $cursor = $database->Query($sql);
                                                                if($database->affected_rows >= 1)
                                                                {
                                                                    while($data = $cursor->fetch_array())
                                                                    {
                                                                        echo("<option value=\"{$data['level_name']}\">{$data['level_name']}</option>");
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Teacher</td>
                                                        <td>
                                                            <input id="course_form_control_<?php echo($loop); ?>" name="teacher_name" class="form-control" type="text" value="<?php echo($data['teacher_name']); ?>"/>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Edit</td>
                                                        <td>
                                                            <a id='edit_course' class='btn btn-primary btn-sm'>
                                                                <span style='display:none' id='selected_pencil'><?php echo($loop);?></span>
                                                                <i class='fa fa-pencil'></i> Edit Course
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Delete</td>
                                                        <td>
                                                            <a style="width: 20%" id="delete_course_<?php echo($loop); ?>" href="./?s=<?php echo($_GET['s']); ?>}&dc=<?php echo($data['id']); ?>" class="btn btn-danger btn-sm disabled">
                                                                Delete
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Update</td>
                                                        <td>
                                                            <input id="course_form_control_<?php echo($loop); ?>" name="teacher_name" class="form-control" type="text" value="<?php echo($data['teacher_name']); ?>" disabled/>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                <?php
                                        $loop = $loop + 1;
                                    }
                                    ?>
                                    </div>
                                </div>        
                                    <?php
                                }
                                else
                                {
                                    ?>
                                        <div class="well well-lg">There are no courses that have been added</div>
                                    <?php
                                }
                                ?>
                                    </div>
                                </div> 
                            </div>
                            <!-------------------------------[ students section ]------------------------------------------------>
                            <div class="tab-pane fade" id="Students">
                                <?php
                                $page = 0;
                                settype($page,"integer");
                                $total_students = 0;
                                $sql = "";
                                $status = "";
                                $construct = "";
                                $GLOBALS['student_names'] = "";
                                if(isset($_GET['st']))
                                {
                                    if($_GET['st'] === "2")
                                    {
                                        $status = " AND status = 'applicant'";
                                    }
                                    else if($_GET['st'] === "3")
                                    {
                                        $status = " AND status = 'active'";
                                    }
                                    else if($_GET['st'] === "4")
                                    {
                                        $status = " AND status = 'graduated'";
                                    }
                                }
                                    
                                $search_for_student = trim(filter_input(INPUT_POST,"search_for_student"));
                                if(!isset($search_for_student) !== true && $search_for_student !== '')
                                {
                                    $search_exploded = explode ( " ",trim(filter_input(INPUT_POST,"search_for_student")));
                                    foreach( $search_exploded as $search_each )
                                    {
                                        $construct = $construct." AND ".trim(filter_input(INPUT_POST,"filter"))." LIKE '%$search_each%' ";
                                    }
                                    if(isset($_GET['page']))
                                    {
                                        $page = (int)$_GET['page'];
                                        $construct =  $construct." LIMIT ".((intval($page)-1)*4)." , 4";
                                    }
                                    else
                                    {
                                        $construct =  $construct." LIMIT 4";
                                    }
                                    $sql = "SELECT * FROM students WHERE school_names = '{$_GET['s']}'{$status}{$construct}";
                                }
                                else 
                                {
                                    if(isset($_GET['page']))
                                    {
                                        $page = (int)$_GET['page'];
                                        $construct =  $construct." LIMIT ".((intval($page)-1)*4)." , 4";
                                    }
                                    else
                                    {
                                        $construct =  $construct." LIMIT 4";
                                    }
                                    $sql = "SELECT * FROM students WHERE school_names = '{$_GET['s']}'{$status}{$construct}";
                                }
                                $cursor = $database->Query($sql);?>
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-body">
                                        <div class="col-lg-2 col-md-2 col-sm-12">
                                            <ul id="student_type_nav" class="list-unstyled affix">
                                                <?php if(!isset($_GET['st'])): ?>
                                                <li class="list-group-item list-group-item-info">
                                                <?php elseif(isset($_GET['st']) && ($_GET['st'] === '1')): ?>
                                                <li class="list-group-item list-group-item-info">
                                                <?php else: ?>
                                                <li class="list-group-item">
                                                <?php endif; ?>
                                                    <a href="./?s=<?php echo($_GET['s']) ?>&st=1">
                                                        All Students
                                                        <?php 
                                                        $statement = "SELECT * FROM students WHERE school_names = '{$_GET['s']}'";
                                                        $student_list_applicant_cursor = $database->Query($statement);
                                                        if($database->affected_rows >= 1) 
                                                        { 
                                                            $count_applicants = 0;
                                                            while($count_data = $student_list_applicant_cursor->fetch_array())
                                                            { 
                                                                $count_applicants = $count_applicants + 1;
                                                            }
                                                            ?>
                                                        <div class="badge"><?php echo($count_applicants) ?></div>
                                                        <?php } ?>
                                                    </a>
                                                </li>
                                                <?php if(isset($_GET['st']) && $_GET['st'] === "2"): ?>
                                                <li class="list-group-item list-group-item-info">
                                                <?php else: ?>
                                                <li class="list-group-item">
                                                <?php endif; ?>
                                                    <a href="./?s=<?php echo($_GET['s']) ?>&st=2">
                                                        Applicants
                                                        <?php 
                                                        $statement = "SELECT * FROM students WHERE status = 'applicant' and school_names = '{$_GET['s']}'";
                                                        $student_list_applicant_cursor = $database->Query($statement);
                                                        if($database->affected_rows >= 1) 
                                                        { 
                                                            $count_applicants = 0;
                                                            while($count_data = $student_list_applicant_cursor->fetch_array())
                                                            { 
                                                                $count_applicants = $count_applicants + 1;
                                                            }
                                                            ?>
                                                        <div class="badge"><?php echo($count_applicants) ?></div>
                                                        <?php } ?>
                                                    </a>
                                                </li>
                                                <?php if(isset($_GET['st']) && ($_GET['st'] === "3")): ?>
                                                <li class="list-group-item list-group-item-info">
                                                <?php else: ?>
                                                <li class="list-group-item">
                                                <?php endif; ?>
                                                    <a href="./?s=<?php echo($_GET['s']) ?>&st=3">
                                                        Active Students
                                                        <?php
                                                        $statement = "SELECT * FROM students WHERE status = 'active' and school_names = '{$_GET['s']}'";
                                                        $student_list_active_cursor = $database->Query($statement);
                                                        if($database->affected_rows >= 1) 
                                                        { 
                                                            $count_applicants = 0;
                                                            while($count_data = $student_list_active_cursor->fetch_array())
                                                            { 
                                                                $count_applicants = $count_applicants + 1;
                                                            }
                                                            ?>
                                                        <div class="badge"><?php echo($count_applicants) ?></div>
                                                        <?php } ?>
                                                    </a>
                                                </li>
                                                <?php if(isset($_GET['st']) && ($_GET['st'] === "4")): ?>
                                                <li class="list-group-item list-group-item-info">
                                                <?php else: ?>
                                                <li class="list-group-item">
                                                <?php endif; ?>
                                                    <a href="./?s=<?php echo($_GET['s']) ?>&st=4">
                                                        Graduated Students
                                                        <?php
                                                        $statement = "SELECT * FROM students WHERE status = 'graduated' and school_names = '{$_GET['s']}'";
                                                        $student_list_graduated_cursor = $database->Query($statement);
                                                        if($database->affected_rows >= 1) 
                                                        { 
                                                            $count_applicants = 0;
                                                            while($count_data = $student_list_graduated_cursor->fetch_array())
                                                            { 
                                                                $count_applicants = $count_applicants + 1;
                                                            }
                                                            ?>
                                                        <div class="badge"><?php echo($count_applicants) ?></div>
                                                        <?php } ?>    
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-10 col-md-10 col-sm-12">
                                            <div class="panel panel-success">
                                                <div class="panel-body">
                                                    <form class="form-inline" method="post">
                                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                                            <div class="col-lg-9 col-md-9 col-sm-12">
                                                                <input id="search_for_student" list="ajax_student_list" type="text" style="width: 100%" class="form-control" placeholder="Search for student" name="search_for_student" value="<?php echo(trim(filter_input(INPUT_POST,"search_for_student"))) ?>" autocomplete="off"/>
                                                                <datalist id="ajax_student_list">
                                                                </datalist>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <input type="submit" class="form-control btn btn-info btn-block" value="Find student"/>
                                                            </div>
                                                        </div>    
                                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                                            <div class="custom_underline_grey" style="margin:10px;"></div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12 text-center text-justify">
                                                                Filter search by :
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">Student's name</label>
                                                                <input type="radio" name="filter" value="student_names" checked="checked" class="radio form-control"/>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">Student's school ID</label>
                                                                <input type="radio" name="filter" value="student_school_identity" class="radio form-control"/>
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-12">
                                                                <label for="filter">Student's National ID</label>
                                                                <input type="radio" name="filter" value="student_national_identity" class="radio form-control"/>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <?php 
                                            if(is_bool($cursor))
                                            {
                                                
                                            }
                                            else
                                            {
                                                while($data = $cursor->fetch_array()) 
                                                { 
                                                    $GLOBALS['id'] = $data['id']; 
                                            ?>
                                            <?php $total_students = $total_students + 1; ?>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title"> 
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseStudent_<?php echo($GLOBALS['id']); ?>">
                                                            <?php echo($data['student_names']); $GLOBALS['student_names']=$data['student_names'];?>
                                                        </a>
                                                    </h4>
                                                </div>
                                                <div id="collapseStudent_<?php echo($GLOBALS['id']); ?>" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <div class="panel panel-info">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">Picture</h4>
                                                                    </div>
                                                                    <div class="panel-body">
                                                                        <img class="img-responsive img-thumbnail" alt="student picture" src="../../assets/img/pro_pic_default.png"/>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <div class="panel panel-info">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">Identification document</h4>
                                                                    </div>
                                                                    <div class="panel-body">
                                                                        <img class="img-responsive img-thumbnail" alt="student picture" src="../../assets/img/pdf.png"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-4 col-md-4 col-sm-12">
                                                                <div class="panel panel-info">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">Qualifications document</h4>
                                                                    </div>
                                                                    <div class="panel-body">
                                                                        <img class="img-responsive img-thumbnail" alt="student picture" src="../../assets/img/pdf.png"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="container-fluid">
                                                            <form action="./" method="post">
                                                                <table class="table table-responsive table-hover table-bordered">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>Student names</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_names" value="<?php echo($data['student_names']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>National Identity</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_national_identity" value="<?php echo($data['student_national_identity']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Type of national identity</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_national_identity_type" value="<?php echo($data['student_national_identity_type']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Student identity</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_school_identity" value="<?php echo($data['student_school_identity']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Phone numbers</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_phone" value="<?php echo($data['student_phone']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Email address</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_email" value="<?php echo($data['student_email']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Enroll date</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_enrol_date" value="<?php echo($data['student_enrol_date']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Physical address</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="student_physical_address" value="<?php echo($data['student_physical_address']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Names of the Next of kin</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="next_of_kin_names" value="<?php echo($data['next_of_kin_names']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Next of kin's relation with the applicant</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="next_of_kin_studen_relationship" value="<?php echo($data['next_of_kin_studen_relationship']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Next of kin's physical address</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="next_of_kin_address" value="<?php echo($data['next_of_kin_address']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Next of kin's email address</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="next_of_kin_email" value="<?php echo($data['next_of_kin_email']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Next of kin's phone numbers</td>
                                                                            <td>
                                                                                <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control" type="text" name="next_of_kin_phone" value="<?php echo($data['next_of_kin_phone']); ?>" required disabled/>
                                                                            </td>
                                                                        </tr>
                                                                        <?php if($data['status'] === "applicant"): ?>
                                                                        <tr>
                                                                            <td>Enroll</td>
                                                                            <td>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12">
                                                                                    <a id='enroll_student' class='btn btn-primary btn-sm btn-block'>
                                                                                        Enroll
                                                                                    </a>
                                                                                </div>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12"></div>
                                                                            </td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                                                        <tr>
                                                                            <td>Edit</td>
                                                                            <td>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12">
                                                                                    <a id='edit_student' class='btn btn-primary btn-sm btn-block'>
                                                                                        <span style='display:none' id='selected_pencil'><?php echo($GLOBALS['id']); ?></span>
                                                                                        <i class='fa fa-pencil'></i> Edit Student
                                                                                    </a>
                                                                                </div>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12"></div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Delete</td>
                                                                            <td>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12">
                                                                                    <a id="Student_form_control_<?php echo($GLOBALS['id']); ?>" href='./?s=<?php echo($_GET['s']); ?>}&dgc=<?php echo($data['id']); ?>' class='btn btn-danger btn-sm btn-block disabled'>
                                                                                        Delete
                                                                                    </a>
                                                                                </div>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12"></div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Update</td>
                                                                            <td>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12">
                                                                                    <input id="Student_form_control_<?php echo($GLOBALS['id']); ?>" class="form-control btn btn-primary btn-block" type="submit" name="Update Student" value="Update Student" required disabled/>
                                                                                </div>
                                                                                <div class="col-lg-6 col-md-6 col-sm-12"></div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php 
                                                }
                                            }
                                            ?>
                                            <?php if($GLOBALS['student_names'] === ""): ?>
                                            <div class="panel panel-default">
                                                <div class="panel-body text-center" style="color:lightslategray">
                                                    <h3>
                                                        No students here
                                                    </h3>
                                                    <br/>
                                                    Try typing the words in the seach box that might correspond to the search filter that you have selected,<br/>
                                                    Or select either one of the items from the menu on the left which has a number beside it.
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <div class="col-lg-12 col-sm-12 col-md-12">
                                                <div class="col-lg-4 col-sm-12 col-md-4"></div>
                                                <div class="col-lg-4 col-sm-12 col-md-4">
                                                <?php 
                                                echo(new JasonGrimes\Paginator($total_students,4, $page = isset($_GET['page']) ? intval($_GET['page']):1,"./?page=(:num)"));
                                                ?>
                                                </div>
                                                <div class="col-lg-4 col-sm-12 col-md-4"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-------------------------------[ staff section ]------------------------------------------------>
                            <div class="tab-pane fade" id="staff">
                                <div class="panel panel-primary panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> 
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                                Add new staff to <?php echo($GLOBALS['schools']); ?>
                                                <i class=" fa fa-plus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse">
                                        <div class="panel-body container">
                                            <div class="well well-sm text-center text-warning">
                                                Please write N/A where not applicable
                                            </div>
                                            <form action="./" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="firstname">First Name</label>
                                                    <input type='text' class='form-control' name='firstname'  placeholder="First Name" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="lastname">Last Name</label>
                                                    <input type='text' class='form-control' name='lastname'  placeholder="Last Name" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="email">Email</label>
                                                    <input type='text' class='form-control' name='email'  placeholder="Email" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="phone">Phone numbers</label>
                                                    <input type='text' class='form-control' name='phone'  placeholder="Phone numbers" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="job">Job</label>
                                                    <input type='text' class='form-control' name='job'  placeholder="Job" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="employed_since">Employment date (dd-mm-yyyy)</label>
                                                    <input type='text' class='form-control' name='employed_since'  placeholder="Employment Date" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="highest_qulifications">Highest Qualifications</label>
                                                    <input type='text' class='form-control' name='highest_qulifications'  placeholder="Highest Qualifications" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label for="contract">Contract copy (pdf files only)</label>
                                                    <input type="file" class="form-control" name="contract" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input style="display: none;" type="text" name="school" value="<?php echo($GLOBALS['schools']); ?>"/>
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control btn btn-success" style="width: 20%" type="submit" name="register_staff" value="Register_new_Staff_Member"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php 
                                $file = new File();
                                $disabled = "";
                                
                                $sql = "SELECT * FROM staff WHERE school = '{$GLOBALS['schools']}'";
                                $database->Query($sql);
                                if($database->affected_rows > 0)
                                {
                                    $loop = 0;
                                    $coursor = $database->Query($sql);?>
                                    <div class="panel panel-primary panel-back">
                                        <div class="panel-body">
                                    <?php while($data = $coursor->fetch_array())
                                    {
                                        $folder = $file->ListFilesInDir("../../uploads/{$_GET['s']}/docs/contracts/{$data['id']}/");
                                        $files = array_pop($folder);
                                        
                                        if($files === "-1" or $files === "" or $files === null)
                                        {
                                            $disabled = " disabled";
                                        }
                                        ?>
                                            <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse_staff_<?php echo($loop);?>">
                                                        <?php echo($data['firstname']." ".$data['lastname']);?>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapse_staff_<?php echo($loop);?>" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="well well-sm text-center text-warning">
                                                    Please change only the values of the fields that you would like to change and leave the rest the way they are
                                                </div>
                                                <table class="table table-responsive table-hover table-bordered">
                                                    <tbody><form action="./" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                                        <tr>
                                                            <form action="./" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                                                <td>
                                                                    Name
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='firstname' value='<?php echo($data['firstname'])?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Last Name
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='lastname' value='<?php echo($data['lastname']);?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Email
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='email' value='<?php echo($data['email']);?>' disabled/>
                                                                </td>
                                                        </tr> 
                                                        <tr>
                                                                <td>
                                                                    Phone
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='phone' value='<?php echo($data['phone']);?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Job
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='job' value='<?php echo($data['job']);?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Employed since
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='employed_since' value='<?php echo($data['employed_since'])?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Highest Qualifications
                                                                </td>
                                                                <td>
                                                                    <input id='staff_form_control_<?php echo($loop);?>' type='text' class='form-control' name='highest_qulifications' value='<?php echo($data['highest_qulifications']);?>' disabled/>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Contract copy
                                                                </td>
                                                                <td>
                                                                    <a style="width: 20%" href='<?php echo($files);?>' class='btn btn-primary btn-sm <?php echo($disabled);?>'>
                                                                        Contract
                                                                    </a>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Update Contract Copy
                                                                </td>
                                                                <td>
                                                                    <input type='file' class='form-control' name='contract'/>
                                                                </td>    
                                                        </tr>            
                                                        <tr>
                                                                <td>
                                                                    Delete
                                                                </td>
                                                                <td>
                                                                    <a style="width: 20%" id='staff_form_control_delete_<?php echo($loop);?>' href='./?s=<?php echo($GLOBALS['schools']);?>&ds=<?php echo($data['id']);?>' class='btn btn-danger btn-sm disabled'>
                                                                        Delete
                                                                    </a>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Edit
                                                                </td>
                                                                <td>
                                                                    <a id='edit_staff' class='btn btn-primary btn-sm' style="width: 20%">
                                                                        <span style='display:none' id='selected_pencil'><?php echo($loop);?></span>
                                                                        <i class='fa fa-pencil'></i> Edit Level
                                                                    </a>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td>
                                                                    Update
                                                                </td>
                                                                <td>
                                                                    <input style='display:none' type='text' name='school' value='<?php echo($data['school']);?>'/>
                                                                    <input style='display:none' type='text' name='id' value='<?php echo($data['id']);?>'/>
                                                                    <input id='staff_form_control_button_<?php echo($loop);?>' style="width: 20%" type='submit' class='form-control btn btn-sm btn-primary' name='update_staff' value='Update' disabled/>
                                                                </td>
                                                            </form>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                               </div>
                                            </div>
                                        </div>
                                        <?php $loop++; } ?>
                                    </div> 
                                </div> 
                                <?php } ?>     
                            </div>
                            <!-------------------------------[ library section ]------------------------------------------------>
                            <div class="tab-pane fade" id="library">
                                <div class="jumbotron">Library tab</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
        <!-----------Info modal----------------->
        <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Information</h4>
                    </div>
                    <div class="modal-body" id="infoModalText"><?php echo($GLOBALS['message']); ?></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default"data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>       
    </body> 
    <script src="../../assets/js/jquery-1.10.2.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/Sessions.js"></script>
    <script src="../../assets/js/loading.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js"></script>
    <script src="../../assets/js/custom.js"></script>
    <script>
        var latitude = -29.325721599999998;
        var longitude = 27.500543999999998;
        $('#toggole_map').click(function()
        {
            if (navigator.geolocation) 
            {
                navigator.geolocation.getCurrentPosition(showPosition);
            } 
            else 
            { 
                var html = "Geolocation is not supported by this browser.";
                $("#infoModalText").html(html);
                $('#infoModal').modal('show'); 
            }
            function showPosition(position) 
            {
                latitude = position.coords.latitude;
                longitude = position.coords.longitude;
            }
            L.marker([latitude, longitude]).addTo(mymap).bindPopup("<b>If you approve of<br/>this location please<br/>click 'Save Address'</a>").openPopup();//"+latitude+","+longitude+"
            $(":text[name=school_coordinates]").val(latitude+","+longitude);
            $(":text[name=school_street]").val("Street name captured");
        });
        var mymap = L.map('mapid').setView([latitude, longitude], 13);
            L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
            maxZoom: 18,
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
                    '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                    'Imagery Â© <a href="http://mapbox.com">Mapbox</a>',
            id: 'mapbox.streets'
            }).addTo(mymap);
            L.popup();
    </script>   
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>
    <script>
    $('document').ready(function(){
        var edit = false;
        $('#editPanel').hide("fast",function(){});
        $('#editButton').click(function(){
            $('#editPanel').show("slow",function(){});
            $('#infoPanel').hide("slow",function(){});
        });
        $('#closeEdit').click(function(){
            $('#editPanel').hide("slow",function(){});
            $('#infoPanel').show("slow",function(){});
        });
        
        if($('#infoModalText').text()!=="")
        {
           $('#infoModal').modal('show'); 
        }
    });    
    </script> 
    <script>
    var param = GetQueryVariable("s");
    $("#deleteButton").click(function(){
        var html = "Are you sure that you want to remove this school from your list?\n\
            &nbsp;&nbsp;&nbsp;<a href='./?d="+param+"' class='btn btn-default'>Yes</a>\n\
            &nbsp;&nbsp;&nbsp;<a href='./?s="+param+"' class='btn btn-default'>No</a>";
        $("#infoModalText").html(html);
        $('#infoModal').modal('show'); 
    });
    var param2 = GetQueryVariable("st");
    if(param2 !== null && param2 !== "")
    {
        $('#myTab a[href="#Students"]').tab('show');
    }
    </script>
    <script>
    $("#file_upload_trigger_tag").click(function(){
        $("#file_upload_tag").trigger('click');
    });
    $("#file_upload_tag").change(function(){
        if($("#file_upload_tag").val() !== "")
        {
            $("#Schools_badge_form").submit();
        }
    });
    </script>
    <script>
    var hidden = true;
    $("#searchbox").hide("slow");
    $("#hide_show_search").click(function()
    {
        if(hidden)
        {
            $("input[name=search]").show("slow");//.val("Visible");
            $("input[name=search]").focus();
            hidden = false;
        }
        else
        {
            $("input[name=search]").hide("slow");//.val("Hidden");
            hidden = true;
        }
    });
    </script> 
    <script>
    $(document).ready(function(){
        if($(window).width() <= 1255)
        {
            $("#student_type_nav").removeClass("affix");
        }
    });
    $(window).resize(function(){
        if($(window).width() <= 1255)
        {
            $("#student_type_nav").removeClass("affix");
        }
        if($(window).width() > 1254)
        {
            $("#student_type_nav").addClass("affix");
        }
    });
    </script>
    <script>
    $(document).ready(function(){
        $("div[id=the_new_length").css("height",$("#the_length_i_need").css("height").toString());       
    });
    $("a[id=edit_course]").click(function()
    {
       $("input[id=course_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=course_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("#delete_course"+$(this).children("#selected_pencil").html()).removeClass("disabled");
    });
    $("a[id=edit_levels]").click(function()
    {
       $("input[id=levels_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=levels_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("#levels_form_control_delete_"+$(this).children("#selected_pencil").html()).removeClass("disabled");
       $("input[id=levels_form_control_button_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=levels_form_control_button_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
    });
    $("a[id=edit_staff]").click(function()
    {
       $("input[id=staff_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=staff_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("#staff_form_control_delete_"+$(this).children("#selected_pencil").html()).removeClass("disabled");
       $("input[id=staff_form_control_button_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=staff_form_control_button_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
    });
    $("a[id=edit_group]").click(function()
    {
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=group_form_control_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
       $("#group_form_control_delete_"+$(this).children("#selected_pencil").html()).removeClass("disabled");
       $("input[id=group_form_control_button_"+$(this).children("#selected_pencil").html()+"]").prop("disabled",false);
       $("input[id=group_form_control_button_"+$(this).children("#selected_pencil").html()+"]").removeAttr("disabled");
    });
    </script>
    <script>
        $("#search_for_student").keyup(function(){
            My_Ajax("ajax_student_list","students/sudent_list.php?s=<?php echo($_GET['s']); ?>&st=<?php if(isset($_GET['st'])){echo($_GET['st']);}else{echo("1");} ?>&k="+$("#search_for_student").val()+"&f="+$("input[@name=filter]").val());
        });
    </script>    
    <script>
        Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });        
    </script>
</html>