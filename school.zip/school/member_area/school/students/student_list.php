<?php
session_start();
include("../../../assets/classes/Database.php");
include("../../../assets/classes/Sessions.php");
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");

}
if(KillSession())
{
    header("location:../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$database = Connect();

$sql = "SELECT school_name FROM school WHERE id = '{$_GET['s']}'";
$cursor = $database->Query($sql);
$school = $cursor->fetch_array()['school_name'];
        
$sql = "";
$status = "";
$construct = "";
$GLOBALS['student_names'] = "";
if(isset($_GET['st']))
{
    if($_GET['st'] === "2")
    {
        $status = " AND status = 'applicant'";
    }
    else if($_GET['st'] === "3")
    {
        $status = " AND status = 'active'";
    }
    else if($_GET['st'] === "4")
    {
        $status = " AND status = 'graduated'";
    }
}
$search_exploded = explode (" ",$_GET['k']);
foreach( $search_exploded as $search_each )
{
    $construct = $construct." AND ".$_GET['f']." LIKE '%$search_each%' ";
}
$sql = "SELECT * FROM students WHERE school_names = '$school'{$status}{$construct}";
$cursor = $database->Query($sql);
while($data = $cursor->fetch_array())
{?>
<option value="<?php echo($data['student_names']); ?>"><?php echo($data['student_names']); ?></option>
<?php } 