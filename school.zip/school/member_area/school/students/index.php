<?php
session_start();
include("../../../assets/classes/Database.php");
include("../../../assets/classes/Sessions.php");
$database = @Connect();
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../");
}
if(KillSession())
{
    header("location:../../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$GLOBALS['email'] = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
    <body>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="../../../assets/img/logo.png" />
        <link href="../../../assets/css/bootstrap.min.css" rel="stylesheet"/>
        <script src="../../../assets/js/jquery-1.10.2.js"></script>       
        <script src="../../../assets/js/pace.min.js"></script>
        <script src="../../../assets/js/gijgo.min.js"></script>
        <link rel="icon" href="../../../assets/img/logo_brand_no_bg.png" />
        <link href="../../../assets/css/pace/pace-theme-center-simple.css" type="text/css" rel="stylesheet">        
        <link href="../../../assets/css/font-awesome.min.css" rel="stylesheet"/>
        <link href="../../../assets/css/simple-sidebar.css" rel="stylesheet">
        <link href="../../../assets/css/font-awesome.css" rel="stylesheet" />
        <link href="../../../assets/css/loading.css" type="text/css" rel="stylesheet">
        <link href="../../../assets/css/custom.css" type="text/css" rel="stylesheet">
        <link href="../../../assets/css/gijgo.min.css" type="text/css" rel="stylesheet">
        <title>School management system</title>
    </head>
    <body>
    <div class="cover"></div>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav" style="margin-top: 20%">
                <li class="sidebar-brand">
                    <a href="#">
                        Menu
                    </a>
                </li>
                <li class="active">
                    <a href="../../" id="Schools"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;My Schools</a>
                </li>
                <li>
                    <a href="../../My_Account/" id="Account"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;My Account</a>
                </li>
                <li>
                    <a href="../../messages/" id="Messages"><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Messages</a>
                </li>
                <li><a href="../../notifications/" id="Notifications"><i class="fa fa-bell"></i>&nbsp;&nbsp;&nbsp;Notifications</a></li>
            </ul>
        </div>
        <div id="page-content-wrapper">        
            <div id="overlay">
                <div id="text">
                    <img style="width: 50%;height: 50%" src="../../../assets/img/loading.gif" alt="loading"/>
                </div>
            </div>    
            <div class="container">
                <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #9999ff">  
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div>
                                <a class="navbar-brand" href="../../../"><u style="color: white;">Magegethe</u></a>
                                <a class="navbar-brand" href="#menu-toggle" title="Toggle menu" class="btn btn-secondary" id="menu-toggle">&nbsp;&nbsp;&nbsp;<i class="fa fa-bars fa-1x"></i>&nbsp;&nbsp;Menu</a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                                <!-----------------------------------------------------------------------------------
                                <li>
                                    <div>
                                        <form class="navbar-form form-inline" method="post" action="./">
                                            <input id="searchbox" style="width:330px" class="form-control" type="text" name="search" placeholder="Type your search keywords then click enter"/>
                                        </form>
                                    </div>
                                </li>
                                <li>
                                    <a href="#" id="hide_show_search"><i class="fa fa-search"></i></a>
                                </li>
                                ----------------------------------------------------------------------------------->
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" 
                                       data-toggle="dropdown" role="button" 
                                       aria-expanded="false">
                                           <?php echo($GLOBALS['email'])?>
                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="../../My_Account/">Account</a></li>
                                        <li><a href="../../../logout.php">Sign out</a></li>               
                                    </ul>
                                </li>
                            </ul>           
                        </div>
                    </div>
                </nav>
            </div>
            <section id="sections">
                <ol class="breadcrumb">
                    <li>
                        <a href="../../">My Schools</a>
                    </li>
                    <li>
                        <a href="./?s=<?php echo($_GET['s']); ?>">Student Application</a>
                    </li>
                </ol>
            </section>
            <section>
                <div class="panel panel-default panel-back">
                    <div class="panel-body">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="well well-sm text-center text-warning">
                                Please write N/A where not applicable
                            </div>
                            <div id="ajax_response" class="panel panel-default">
                                <div class="panel-body">
                                    <button type="button" class="close">&times;</button>
                                    <div class="progress progress-striped progress-bar-info" style="width:100%">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="70"  aria-valuemin="0" aria-valuemax="100" style="width:1%">
                                            <span class="sr-only">1%</span>
                                        </div>
                                    </div>         
                                    <div id="status1" class="text-center">
                                        <?php echo((filter_input(INPUT_GET,"r") !== false) ? trim(filter_input(INPUT_GET,"r")) : "Please fill in the personal details form"); ?>
                                    </div>	
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="">
                                <ul id="student_application_nav" class="list-unstyled affix">
                                    <li class="list-group-item <?php echo((!isset($_GET['p'])) || (trim(filter_input(INPUT_GET,"p")) === "personal_details") ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=personal_details&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">Personal details</a>
                                    </li>
                                    <li class="list-group-item <?php echo((trim(filter_input(INPUT_GET,"p")) === "courses") ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=courses&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">Programme or course of study</a>
                                    </li>
                                    <li class="list-group-item <?php echo(trim(filter_input(INPUT_GET,"p")) === "qualifications" ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=qualifications&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">Academic information</a>
                                    </li>
                                    <li class="list-group-item <?php echo(trim(filter_input(INPUT_GET,"p")) === "references" ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=references&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">References</a>
                                    </li>
                                    <li class="list-group-item <?php echo(trim(filter_input(INPUT_GET,"p")) === "sponsorship" ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=sponsorship&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">Sponsorship</a>
                                    </li>
                                    <li class="list-group-item <?php echo(trim(filter_input(INPUT_GET,"p")) === "previous" ? "list-group-item-info" : ""); ?>">
                                        <a href="./?p=previous&s=<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>">Previous Applications</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12">
                            <?php if(!isset($_GET['p']) || (trim(filter_input(INPUT_GET,"p")) === "personal_details")): ?>
                            <div id="personal_details">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Personal Details</h4>
                                    </div>
                                    <div class="panel-body">
                                        <form class="form-horizontal container-fluid" method="post" action="register_student.php">
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Passport size photograph</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="col-sm-12 col-lg-12 col-md-12">
                                                        <div class="col-sm-12 col-lg-3 col-md-3">
                                                            <img class="img-thumbnail img-responsive" src="../../../assets/img/pro_pic_default.png"/>
                                                        </div>
                                                        <div class="col-sm-12 col-lg-9 col-md-9" style="margin-top:30px;color:lightslategray;">
                                                            <h4>
                                                            To attach the applicants passport sized photo to your application
                                                            please click on the picture on the left to select a picture from 
                                                            your gallery.
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Personal information</h4>
                                                </div>
                                                <div class="panel-body" style="padding:30px;">
                                                    <div class="form-group">
                                                        <label for="student_names">First name</label>
                                                        <input class="form-control" type="text" value="" name="student_first_name" placeholder="First Name" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Middle name</label>
                                                        <input class="form-control" type="text" value="" name="student_middle_name" placeholder="Middle Name" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Last name</label>
                                                        <input class="form-control" type="text" value="" name="student_last_name" placeholder="Last Name" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Maiden name</label>
                                                        <input class="form-control" type="text" value="" name="student_maiden_names" placeholder="Maiden Name" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Date of birth</label>
                                                        <input class="form-control" type="text" value="" id="datepicker" name="date_of_birth" placeholder="Date of birth" required autocomplete="off"/>
                                                        <script>
                                                        $('#datepicker').datepicker({
                                                            uiLibrary: 'bootstrap'
                                                        });
                                                        </script>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Citizenship</label>
                                                        <input class="form-control" type="text" value="" name="citizenship" placeholder="Citizenship" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Sex / Gender</label>
                                                        <select class="form-control"  name="Gender" placeholder="Sex or gender" required>
                                                            <option name="">Select the type of sex you identify with</option>
                                                            <option name="Female">Female</option>
                                                            <option name="Male">Male</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_names">Country</label>
                                                        <input class="form-control" type="text" value="" name="country" placeholder="Country" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <input style="display:none" type="text" name="school_names" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                                        <input style="display:none" type="text" name="user_that_makes_application" value="<?php echo($_SESSION['email']); ?>" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_national_identity">National id number</label>
                                                        <input class="form-control" type="text" value="" name="student_national_identity" placeholder="National id number" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="current_year">Type of identification document</label>
                                                        <select class="form-control"  name="student_national_identity_type" placeholder="student_national_identity_type" required>
                                                            <option name="">Select the type of identification document</option>
                                                            <option name="ID_card">Id card</option>
                                                            <option name="Passport">Passport</option>
                                                            <option name="Drivers license">Drivers license</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <input style="display:none" type="text" name="student_school_identity" value="N/A"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_phone">Phone number</label>
                                                        <input class="form-control" type="text" value="" name="student_phone" placeholder="Phone number" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_email">Email</label>
                                                        <input class="form-control" type="text" value="" name="student_email" placeholder="Email" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="student_physical_address">Physical address</label>
                                                        <input class="form-control" type="text" value="" name="student_physical_address" placeholder="Physical address" required/>
                                                    </div>
                                                </div>
                                            </div>    
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Next of kin</h4>
                                                </div>
                                                <div class="panel-body" style="padding:30px;">
                                                    <div class="form-group">
                                                        <label for="next_of_kin">Next of kin full names</label>
                                                        <input class="form-control" type="text" value="" name="next_of_kin_names" placeholder="Full names of next of kin" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_student_relationship">Next of kin's relationship with the student</label>
                                                        <input class="form-control" type="text" value="" name="next_of_kin_student_relationship" placeholder="Next of kin's relationship with the student" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_address">Next of kin's physical address</label>
                                                        <input class="form-control" type="text" value="" name="next_of_kin_address" placeholder="Next of kin's physical address" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_phone">Next of kin's Email address</label>
                                                        <input class="form-control" type="text" value="" name="next_of_kin_email" placeholder="Next of kin's email address" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_phone">Next of kin's phone numbers</label>
                                                        <input class="form-control" type="text" value="" name="next_of_kin_phone" placeholder="Next of kin's phone numbers" required/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Disablities</h4>
                                                </div>
                                                <div class="panel-body" style="padding:30px;">
                                                    <div class="form-group">
                                                        <label for="next_of_kin_phone">Does the applicant have disabilites?</label>
                                                        <div class="panel panel-default">
                                                            <div class="panel-body">
                                                                Yes&nbsp;&nbsp;<input type="radio" name="disablities" value="YES" />&nbsp;&nbsp;
                                                                No&nbsp;&nbsp;<input type="radio" name="disablities" value="NO" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_phone">If the applicant is disabled, please state the nature of the disablity</label>
                                                        <textarea name="disablities_nature" class="form-control"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="next_of_kin_phone">If the applicant is disabled, please state the needs of the disabled applicant</label>
                                                        <textarea name="disabled_needs" class="form-control"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                    <input class="form-control btn btn-success" type="submit" name="student_details_submit" value="Go to the next form"/>
                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php elseif(trim(filter_input(INPUT_GET,"p")) === "courses"): ?>
                            <div id="courses">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Programme or course of study</h4>
                                    </div>
                                    <div class="panel-body">
                                        <input style="display:none" type="text" name="school_names" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                        <form class="form-horizontal container-fluid" action="register_student.php">
                                            <div class="form-group">
                                                <label for="course_of_choice">Programme or course of study</label>
                                                <select class="form-control"  name="programme_of_choice">
                                                    <option value="">Select the course that you would like to do</option>
                                                    <?php
                                                    $cursor = $database->Query("SELECT course_name FROM courses WHERE school_name = '".trim(filter_input(INPUT_GET,"s"))."'");
                                                    if($database->affected_rows > 0)
                                                    {
                                                        while($data = $cursor->fetch_array())
                                                        {
                                                        ?>
                                                        <option value="<?php echo($data['course_name']) ?>"><?php echo($data['course_name']) ?></option>
                                                        <?php 
                                                        } 
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                    <input class="form-control btn btn-success" type="submit" name="student_chosen_programme_submit" value="Go to the next form"/>
                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php elseif(trim(filter_input(INPUT_GET,"p")) === "qualifications"): ?>
                            <div id="qualifications">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Academic information</h4>
                                    </div>
                                    <div class="panel-body">
                                        <form class="form-horizontal container-fluid" action="register_student.php">
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Last school attended certifcate copy</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="col-sm-12 col-lg-12 col-md-12">
                                                        <div class="col-sm-12 col-lg-3 col-md-3">
                                                            <img class="img-thumbnail img-responsive" src="../../../assets/img/pdf.png"/>
                                                        </div>
                                                        <div class="col-sm-12 col-lg-9 col-md-9" style="margin-top:30px;color:lightslategray;">
                                                            <h4>
                                                            To attach the applicants certified copy of certificate obtained at 
                                                            their last school attended to your application
                                                            please click on the picture on the left to select a picture from 
                                                            your gallery.
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Last school attended</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <label for="last_school_name">Name of the last school attended</label>
                                                        <input type="text" class="form-control" placeholder="last school name" name="last_school_name"/>
                                                        <input style="display:none" type="text" name="school_names" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="last_class">Last level or class</label>
                                                        <input type="text" class="form-control" placeholder="Last level or class" name="last_class"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="certificate_obtained">Name of the Certificate obtained</label>
                                                        <input type="text" class="form-control" placeholder="Name of the Certificate obtained" name="certificate_obtained"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                    <input class="form-control btn btn-success" type="submit" name="student_qualifications_submit" value="Go to the next form"/>
                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php elseif(trim(filter_input(INPUT_GET,"p")) === "references"): ?>
                            <div id="references">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">References</h4>
                                    </div>
                                    <div class="panel-body">
                                        <form class="form-horizontal container-fluid" action="register_student.php">
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">First reference information</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <label for="first_reference_name">Name of the first reference</label>
                                                        <input type="text" class="form-control" placeholder="Name of the first reference" name="first_reference_name"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="first_reference_Occupation">Occupation</label>
                                                        <input type="text" class="form-control" placeholder="Occupation" name="first_reference_Occupation"/>
                                                        <input style="display:none" type="text" name="school_names" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="first_reference_address">Address</label>
                                                        <input type="text" class="form-control" placeholder="Address" name="first_reference_address"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="first_reference_phone_numbers">Phone numbers</label>
                                                        <input type="text" class="form-control" placeholder="Phone numbers" name="first_reference_phone_numbers"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="first_reference_email">Email</label>
                                                        <input type="text" class="form-control" placeholder=Email" name="first_reference_email"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Second reference information</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <label for="second_reference_name">Name of the second reference</label>
                                                        <input type="text" class="form-control" placeholder="Name of the second reference" name="second_reference_name"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="second_reference_Occupation">Occupation</label>
                                                        <input type="text" class="form-control" placeholder="Occupation" name="second_reference_Occupation"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="second_reference_address">Address</label>
                                                        <input type="text" class="form-control" placeholder="Address" name="second_reference_address"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="second_reference_phone_numbers">Phone numbers</label>
                                                        <input type="text" class="form-control" placeholder="Phone numbers" name="second_reference_phone_numbers"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="second_reference_email">Email</label>
                                                        <input type="text" class="form-control" placeholder=Email" name="second_reference_email"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                    <input class="form-control btn btn-success" type="submit" name="student_references_submit" value="Go to the next form"/>
                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-12"></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php elseif(trim(filter_input(INPUT_GET,"p")) === "sponsorship"): ?>
                            <div id="sponsorship">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Sponsorship</h4>
                                    </div>
                                    <div class="panel-body">
                                        <form class="form-horizontal container-fluid" action="register_student.php">
                                            <div class="panel panel-primary">
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <label for="type_of_sponsor">Type of sponsor</label>
                                                        <select name="sponsor_type" class="form-control">
                                                            <option>Select the type of sponsor</option>
                                                            <option value="Government">Government</option>
                                                            <option value="Parent">Parent</option>
                                                            <option value="Other">Other</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="name_of_sponsor">Name of sponsor</label>
                                                        <input type="text" class="form-control" placeholder="Name of sponsor" name="sponsor_name"/>
                                                        <input style="display:none" type="text" name="school_names" value="<?php echo(trim(filter_input(INPUT_GET,"s"))); ?>" required/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sponsor_phone">Sponsor's phone</label>
                                                        <input type="text" class="form-control" placeholder="Sponsor's phone" name="sponsor_phone"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sponsor_email">Sponsor's email</label>
                                                        <input type="text" class="form-control" placeholder="Sponsor's email" name="sponsor_email"/>
                                                    </div>
                                                    <div class="form-group">
                                                        <input style="display:none" class="form-control" type="text" name="student_enrol_date" placeholder="Enroll date" value="<?php echo(date("l, F jS, Y, g:i A")); ?>" required/>
                                                        <input style="display:none" type="text" name="status" value="applicant"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-2 col-md-2 col-sm-12"></div>
                                                <div class="col-lg-8 col-md-8 col-sm-12">
                                                    <input class="form-control btn btn-success" type="submit" name="student_sponsor_submit" value="Apply for enrolment to <?php echo(trim(filter_input(INPUT_GET,"s"))); ?>"/>
                                                </div>
                                                <div class="col-lg-2 col-md-2 col-sm-12"></div>
                                            </div>
                                        </form>    
                                    </div>
                                </div>
                            </div>
                            <?php elseif(trim(filter_input(INPUT_GET,"p")) === "previous"): ?>
                            <div id="previuos">
                                <div class="panel panel-default panel-back">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Previous Applications</h4>
                                    </div>
                                    <div class="panel-body">
                                        
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
            </div>
        </div>
    </body>
    <script src="../../../assets/js/jquery-1.10.2.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>
    <script src="../../../assets/js/Sessions.js"></script>
    <script src="../../../assets/js/loading.js"></script>    
    <script src="../../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="../../../assets/js/custom.js"></script>
    <script src="../../../assets/js/jquery.form.js"></script>
    <script src="../../../assets/js/jquery.js"></script>
    <script>
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
        Pace.stop();
        Pace.on("done", function(){
            $(".cover").fadeOut(1000);
        });        
    </script>
    <script>
    $(document).ready(function(){
        if($(window).width() <= 1255)
        {
            $("#student_application_nav").removeClass("affix");
        }
    });
    $(window).resize(function(){
        if($(window).width() <= 1255)
        {
            $("#student_application_nav").removeClass("affix");
        }
        if($(window).width() > 1254)
        {
            $("#student_application_nav").addClass("affix");
        }
    });
    </script> 
</html>
