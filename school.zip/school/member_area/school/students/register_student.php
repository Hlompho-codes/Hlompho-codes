<?php
session_start();
include("../../../assets/classes/Database.php");
include("../../../assets/classes/Sessions.php");
$database = Connect();
if(!(isset($_SESSION['email'])) and !(isset($_SESSION['password'])))
{
    header("location:../../../");
}
if(KillSession())
{
    header("location:../../../logout.php?msg=You have been locked out due to low activity on this site for this session");
}
$student_details_submit_button = trim(filter_input(INPUT_POST,"student_details_submit"));
if(isset($student_details_submit_button) && $student_details_submit_button !== '')
{
    $sql = "INSERT INTO students_personal_information "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"student_first_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_middle_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_last_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_maiden_names"))."',"
          ."'".trim(filter_input(INPUT_POST,"date_of_birth"))."',"
          ."'".trim(filter_input(INPUT_POST,"citizenship"))."',"
          ."'".trim(filter_input(INPUT_POST,"country"))."',"
          ."'".trim(filter_input(INPUT_POST,"Gender"))."',"
          ."'".trim(filter_input(INPUT_POST,"user_that_makes_application"))."',"
          ."'".trim(filter_input(INPUT_POST,"school_names"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_national_identity"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_national_identity_type"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_school_identity"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_phone"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_email"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_physical_address"))."',"
          ."'".trim(filter_input(INPUT_POST,"next_of_kin_names"))."',"
          ."'".trim(filter_input(INPUT_POST,"next_of_kin_student_relationship"))."',"
          ."'".trim(filter_input(INPUT_POST,"next_of_kin_address"))."',"
          ."'".trim(filter_input(INPUT_POST,"next_of_kin_email"))."',"
          ."'".trim(filter_input(INPUT_POST,"next_of_kin_phone"))."',"
          ."'".trim(filter_input(INPUT_POST,"disablities"))."',"
          ."'".trim(filter_input(INPUT_POST,"disablities_nature"))."',"
          ."'".trim(filter_input(INPUT_POST,"disabled_needs"))."')";
    if($database->Query($sql))
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=courses&r=You have successfully added your personal information");
    }
    else
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=personal_details&r=OOPS! Somethig went wrong :( {$database->error}");
    }  
}
$student_chosen_programme_submit_button = trim(filter_input(INPUT_POST,"student_chosen_programme_submit"));
if(!isset($student_chosen_programme_submit_button) !== true && $student_chosen_programme_submit_button !== '')
{
    $sql = "INSERT INTO programmes_the_student_applied_for "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"programme_of_choice"))."')";
    if($database->Query($sql))
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=qualifications&r=You have successfully added your programme of choice to the application");
    }
    else
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=courses&r={$database->erro}");
    }  
}
$student_qualifications_submit_button = trim(filter_input(INPUT_POST,"student_qualifications_submit"));
if(!isset($student_qualifications_submit_button) !== true && $student_qualifications_submit_button !== '')
{
    $sql = "INSERT INTO qualifications_of_the_student "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"last_school_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"last_class"))."',"
          ."'".trim(filter_input(INPUT_POST,"certificate_obtained"))."')";
    if($database->Query($sql))
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=references&r=You have successfully added your academic information to the application");
    }
    else
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=qualifications&r={$database->erro}");
    }  
}
$student_references_submit_button = trim(filter_input(INPUT_POST,"student_references_submit"));
if(!isset($student_references_submit_button) !== true && $student_references_submit_button !== '')
{
    $first_ref_success_flag = false;
    $second_ref_success_flag = false;
    $message = "";
    
    $sql = "INSERT INTO students_references "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"first_reference_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"first_reference_Occupation"))."',"
          ."'".trim(filter_input(INPUT_POST,"first_reference_address"))."',"
          ."'".trim(filter_input(INPUT_POST,"first_reference_phone_numbers"))."',"
          ."'".trim(filter_input(INPUT_POST,"reference_email"))."')";
    if($database->Query($sql))
    {
        $first_ref_success_flag = true;
    }
    $sql = "INSERT INTO students_references "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"second_reference_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"second_reference_Occupation"))."',"
          ."'".trim(filter_input(INPUT_POST,"second_reference_address"))."',"
          ."'".trim(filter_input(INPUT_POST,"second_reference_phone_numbers"))."',"
          ."'".trim(filter_input(INPUT_POST,"reference_email"))."')";
    if($database->Query($sql))
    {
        $second_ref_success_flag = true;
    }
    
    if($first_ref_success_flag)
    {
        $message = $message."&p=sponsorship&r=You have successfully added your references to the application";
    }
    else
    {
        $message = $message."&p=references&r=An error occured while saving the first reference : {$database->erro}";
    }
    if($second_ref_success_flag)
    {
        $message = $message."&p=sponsorship&r=You have successfully added your references to the application";
    }
    else
    {
        $message = $message."&p=references&r=An error occured while saving the first reference : {$database->erro}";
    }
    header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=references&r={$message}");
}
$student_sponsor_submit_button = trim(filter_input(INPUT_POST,"student_sponsor_submit"));
if(!isset($student_sponsor_submit_button) !== true && $student_sponsor_submit_button !== '')
{
    $sql = "INSERT INTO students_sponsor "
          ."VALUES(0,"
          ."'".trim(filter_input(INPUT_POST,"sponsor_type"))."',"
          ."'".trim(filter_input(INPUT_POST,"sponsor_name"))."',"
          ."'".trim(filter_input(INPUT_POST,"sponsor_phone"))."',"
          ."'".trim(filter_input(INPUT_POST,"sponsor_email"))."',"
          ."'".trim(filter_input(INPUT_POST,"student_enrol_date"))."',"
          ."'".trim(filter_input(INPUT_POST,"status"))."')";
    if($database->Query($sql))
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=previous&r=You have successfully completed your application, Please be patient as the school will get back to you regarding this application");
    }
    else
    {
        header("location:./?s=".trim(filter_input(INPUT_POST,"school_names"))."&p=sponsorship&r={$database->erro}");
    }  
}