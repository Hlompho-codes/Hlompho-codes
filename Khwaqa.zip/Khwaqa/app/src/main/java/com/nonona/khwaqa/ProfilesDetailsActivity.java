package com.nonona.khwaqa;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.nonona.khwaqa.data.Database;
import com.nonona.khwaqa.data.Profiles;

import java.sql.SQLException;

public class ProfilesDetailsActivity extends AppCompatActivity {

    private boolean edit;
    TextView profiles_details_service_name_textView;
    TextView profiles_details_user_name_textView;
    TextView profiles_details_service_user_password_textView;
    EditText profilesDetailsEditTextServiceName;
    EditText profilesDetailsEditTextUserName;
    EditText profilesDetailsEditTextTextPassword;
    Button profile_details_update_profile_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles_details);

        final Database database = new Database(getBaseContext());

        edit = false;

        if(getSupportActionBar() != null)
        {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Profile details");
            getSupportActionBar().setSubtitle(getIntent().getStringExtra("listItem").toString());
        }

       Profiles profile = database.GetProfile(getIntent().getIntExtra("listItemId",0));

        ImageView delete_button = findViewById(R.id.profiles_details_delete_button);
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FrameLayout modal = findViewById(R.id.profiles_details_modal_layout);
                modal.setVisibility(View.VISIBLE);
            }
        });

        Button yes_button = findViewById(R.id.profiles_details_yes_button);
        yes_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FrameLayout modal = findViewById(R.id.profiles_details_modal_layout);
                modal.setVisibility(View.GONE);

                database.DeleteProfiles(getIntent().getIntExtra("listItemId",0));
                Toast.makeText(getBaseContext(),"Profile has been deleted from the device",Toast.LENGTH_SHORT).show();

                finish();
            }
        });

        Button no_button = findViewById(R.id.profiles_details_no_button);
        no_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FrameLayout modal = findViewById(R.id.profiles_details_modal_layout);
                modal.setVisibility(View.GONE);
            }
        });

        profiles_details_service_name_textView = findViewById(R.id.profiles_details_service_name_textView);
        profiles_details_service_name_textView.setText(profile.getService_name());

        profiles_details_user_name_textView = findViewById(R.id.profiles_details_user_name_textView);
        profiles_details_user_name_textView.setText(profile.getWeb_url());

        profiles_details_service_user_password_textView = findViewById(R.id.profiles_details_service_user_password_textView);
        profiles_details_service_user_password_textView.setText(profile.getPassword());

        profilesDetailsEditTextServiceName = findViewById(R.id.profilesDetailsEditTextServiceName);
        profilesDetailsEditTextServiceName.setText(profile.getService_name());

        profilesDetailsEditTextUserName = findViewById(R.id.profilesDetailsEditTextUserName);
        profilesDetailsEditTextUserName.setText(profile.getWeb_url());

        profilesDetailsEditTextTextPassword = findViewById(R.id.profilesDetailsEditTextTextPassword);
        profilesDetailsEditTextTextPassword.setText(profile.getPassword());

        profile_details_update_profile_button = findViewById(R.id.profile_details_update_profile_button);

        Button update_Button = findViewById(R.id.profile_details_update_profile_button);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
        {
            update_Button.setBackground(CoolBigButton());
            profilesDetailsEditTextServiceName.setBackground(CoolEditText());
            profilesDetailsEditTextTextPassword.setBackground(CoolEditText());
            profilesDetailsEditTextUserName.setBackground(CoolEditText());
        }
        update_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                boolean updated = false;
                try
                {
                    updated = database.UpdateProfiles(
                            getIntent().getIntExtra("listItemId",0),
                            profilesDetailsEditTextServiceName.getText().toString(),
                            profilesDetailsEditTextUserName.getText().toString(),
                            profilesDetailsEditTextTextPassword.getText().toString());
                }
                catch (Exception e)
                {
                    Toast.makeText(getBaseContext(), "Oops! An error occurred while updating the profile : "+e.getMessage(), Toast.LENGTH_LONG).show();
                }
                if(updated)
                {
                    Toast.makeText(getBaseContext(), "You have successfully updated the profile", Toast.LENGTH_LONG).show();
                    finish();
                }
                else
                {
                    Toast.makeText(getBaseContext(), "You did not successfully update the profile", Toast.LENGTH_LONG).show();
                }
            }
        });

        ImageView profiles_details_edit_button = findViewById(R.id.profiles_details_edit_button);
        profiles_details_edit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isEdit())
                {
                    profiles_details_service_name_textView = findViewById(R.id.profiles_details_service_name_textView);
                    profiles_details_service_name_textView.setVisibility(View.GONE);

                    profiles_details_user_name_textView = findViewById(R.id.profiles_details_user_name_textView);
                    profiles_details_user_name_textView.setVisibility(View.GONE);

                    profiles_details_service_user_password_textView = findViewById(R.id.profiles_details_service_user_password_textView);
                    profiles_details_service_user_password_textView.setVisibility(View.GONE);

                    profilesDetailsEditTextServiceName = findViewById(R.id.profilesDetailsEditTextServiceName);
                    profilesDetailsEditTextServiceName.setVisibility(View.VISIBLE);

                    profilesDetailsEditTextUserName = findViewById(R.id.profilesDetailsEditTextUserName);
                    profilesDetailsEditTextUserName.setVisibility(View.VISIBLE);

                    profilesDetailsEditTextTextPassword = findViewById(R.id.profilesDetailsEditTextTextPassword);
                    profilesDetailsEditTextTextPassword.setVisibility(View.VISIBLE);

                    profile_details_update_profile_button.setVisibility(View.VISIBLE);

                    setEdit(true);
                }
                else
                {
                    profiles_details_service_name_textView = findViewById(R.id.profiles_details_service_name_textView);
                    profiles_details_service_name_textView.setVisibility(View.VISIBLE);

                    profiles_details_user_name_textView = findViewById(R.id.profiles_details_user_name_textView);
                    profiles_details_user_name_textView.setVisibility(View.VISIBLE);

                    profiles_details_service_user_password_textView = findViewById(R.id.profiles_details_service_user_password_textView);
                    profiles_details_service_user_password_textView.setVisibility(View.VISIBLE);

                    profilesDetailsEditTextServiceName = findViewById(R.id.profilesDetailsEditTextServiceName);
                    profilesDetailsEditTextServiceName.setVisibility(View.GONE);

                    profilesDetailsEditTextUserName = findViewById(R.id.profilesDetailsEditTextUserName);
                    profilesDetailsEditTextUserName.setVisibility(View.GONE);

                    profilesDetailsEditTextTextPassword = findViewById(R.id.profilesDetailsEditTextTextPassword);
                    profilesDetailsEditTextTextPassword.setVisibility(View.GONE);

                    profile_details_update_profile_button.setVisibility(View.GONE);

                    setEdit(false);
                }
            }
        });
    }

    public boolean isEdit() {
        return edit;
    }

    public void setEdit(boolean edit) {
        this.edit = edit;
    }

    private Drawable CoolBigButton()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(50);
        //gradientDrawable.setStroke(5, Color.RED);
        gradientDrawable.setColor(ContextCompat.getColor(getBaseContext(),R.color.my_blue_background));
        return(gradientDrawable);
    }

    private Drawable CoolEditText()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(5);
        gradientDrawable.setStroke(3, Color.LTGRAY);
        gradientDrawable.setColor(Color.WHITE);
        return(gradientDrawable);
    }
}