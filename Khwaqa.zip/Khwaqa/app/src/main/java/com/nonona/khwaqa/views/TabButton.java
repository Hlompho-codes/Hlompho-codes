package com.nonona.khwaqa.views;

import android.content.Context;
import android.graphics.Color;
import android.widget.LinearLayout;

public class TabButton extends androidx.appcompat.widget.AppCompatButton
{
    private String Text;
    public TabButton(Context context,String text)
    {
        super(context);
        this.setBackgroundColor(Color.BLUE);
        this.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT));
        this.setPadding(2,2, 2, 2);
        this.setText(text);
    }

    @Override
    public String getText() {
        return Text;
    }

    public void setText(String text) {
        Text = text;
    }
}
