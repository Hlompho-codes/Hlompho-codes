package com.nonona.khwaqa.views;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ListsView extends LinearLayout
{
    public ListsView(Context context, String[] texts, OnClickListener listener) {
        super(context);
        this.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        this.setOrientation(LinearLayout.VERTICAL);
        this.setGravity(Gravity.CENTER);

        if(texts == null)
        {
            return;
        }

        for(String text : texts)
        {
            TextView divider = new TextView(getContext());
            divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1));
            divider.setBackgroundColor(Color.LTGRAY);
            divider.setGravity(Gravity.CENTER_HORIZONTAL);

            String required_text_length = text.substring(text.indexOf(">") + 1);

            TextViewControl textViewControl = new TextViewControl(getContext(), required_text_length);
            textViewControl.setOnClickListener(listener);
            textViewControl.setId(Integer.parseInt(text.substring(0,text.indexOf("<"))));

            addView(divider);
            addView(textViewControl);
        }
    }

    public void Update(String[] texts, OnClickListener listener)
    {
        this.removeAllViews();

        for(String text : texts)
        {
            TextView divider = new TextView(getContext());
            divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1));
            divider.setBackgroundColor(Color.LTGRAY);
            divider.setGravity(Gravity.CENTER_HORIZONTAL);

            TextViewControl textViewControl = new TextViewControl(getContext(),text.substring(text.indexOf(">") + 1));
            textViewControl.setOnClickListener(listener);
            textViewControl.setId(Integer.parseInt(text.substring(0,text.indexOf("<"))));
            addView(divider);
            addView(textViewControl);
        }
    }

    public void AddListItem(String string, OnClickListener listener)
    {
        TextView divider = new TextView(getContext());
        divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1));
        divider.setBackgroundColor(Color.LTGRAY);
        divider.setGravity(Gravity.CENTER_HORIZONTAL);

        TextViewControl textViewControl = new TextViewControl(getContext(),string.substring(string.indexOf(">") + 1));// splits[0]);
        textViewControl.setOnClickListener(listener);
        textViewControl.setId(Integer.parseInt(string.substring(0,string.indexOf("<"))));
        addView(divider);
        addView(textViewControl);
    }

    private static class TextViewControl extends androidx.appcompat.widget.AppCompatTextView
    {
        public TextViewControl(Context context, String text) {
            super(context);
            this.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,100));
            this.setTextSize(24);
            this.setText(text);
            this.setPadding(10, 0, 0, 0);
            this.setGravity(Gravity.CENTER_VERTICAL);
        }
    }
}
