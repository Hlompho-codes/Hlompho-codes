package com.nonona.khwaqa.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME = "khwaqa.db";

    public Database(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE hidden_files(id integer primary key, file_name text, file_path text, file_type tex, new_file_name text, status text)");
        db.execSQL("CREATE TABLE encrypted_files(id integer primary key, file_name text, file_path text,file_type text, new_file_name text, status text)");
        db.execSQL("CREATE TABLE profiles(id integer primary key, service_name text, web_url text, password text)");
        db.execSQL("CREATE TABLE user(id integer primary key,username text, password text, password_hint text)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS hidden_files");
        db.execSQL("DROP TABLE IF EXISTS encrypted_files");
        db.execSQL("DROP TABLE IF EXISTS profiles");
        db.execSQL("DROP TABLE IF EXISTS user");
        onCreate(db);
    }

    public boolean InsertHiddenFiles(HiddenFiles hiddenFiles)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("file_name", hiddenFiles.getFile_name());
        contentValues.put("file_path", hiddenFiles.getFile_path());
        contentValues.put("file_type", hiddenFiles.getFile_type());
        contentValues.put("new_file_name", hiddenFiles.getNew_file_path());
        contentValues.put("status", hiddenFiles.getStatus());
        return( db.insert("hidden_files", null, contentValues) != -1);
    }

    public boolean UpdateHiddenFiles(Integer id, HiddenFiles hiddenFiles)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("file_name", hiddenFiles.getFile_name());
        contentValues.put("file_path", hiddenFiles.getFile_path());
        contentValues.put("file_type", hiddenFiles.getFile_type());
        contentValues.put("new_file_name", hiddenFiles.getNew_file_path());
        contentValues.put("status", hiddenFiles.getStatus());
        db.update("hidden_files", contentValues, "id = ? ", new String[] {Integer.toString(id) } );
        return(true);
    }

    public int DeleteHiddenFiles(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("hidden_files", "id = ? ", new String[] { Integer.toString(id) });
    }

    public int NumberOfHiddenFiles()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            int numRows = (int) DatabaseUtils.queryNumEntries(db, "hidden_files");
            return numRows;
        }
        catch (SQLException sql)
        {
            return(-1);
        }
    }

    public HiddenFiles[] GetAllHiddenFiles()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery( "select * from hidden_files", null );
        res.moveToFirst();
        HiddenFiles hiddenFiles[] = new HiddenFiles[this.NumberOfHiddenFiles()];
        int index = 0;
        while(res.isAfterLast() == false)
        {
            hiddenFiles[index] = new HiddenFiles
                    (
                            res.getString(res.getColumnIndex("file_name")),
                            res.getString(res.getColumnIndex("file_path")),
                            res.getString(res.getColumnIndex("file_type")),
                            res.getString(res.getColumnIndex("new_file_name")),
                            res.getString(res.getColumnIndex("status"))
                    );
            res.moveToNext();
            index = index + 1;
        }
        return hiddenFiles;
    }

    public boolean InsertEncryptedFiles(EncryptedFiles encryptedFiles)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("file_name", encryptedFiles.getFile_name());
        contentValues.put("file_path", encryptedFiles.getFile_path());
        contentValues.put("file_type", encryptedFiles.getFile_type());
        contentValues.put("new_file_name", encryptedFiles.getNew_file_name());
        contentValues.put("status", encryptedFiles.getStatus());
        return(db.insert("encrypted_files", null, contentValues) != -1);
    }

    public boolean UpdateEncryptedFiles(Integer id, EncryptedFiles encryptedFiles)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("file_name", encryptedFiles.getFile_name());
        contentValues.put("file_path", encryptedFiles.getFile_path());
        contentValues.put("file_type", encryptedFiles.getFile_type());
        contentValues.put("new_file_name", encryptedFiles.getNew_file_name());
        contentValues.put("status", encryptedFiles.getStatus());
        return(db.update("encrypted_files", contentValues, "id = ? ", new String[] {Integer.toString(id) } ) != -1);
    }

    public int DeleteEncryptedFiles(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("encrypted_files", "id = ? ", new String[] { Integer.toString(id) });
    }

    public int NumberOfEncryptedFiles()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            int numRows = (int) DatabaseUtils.queryNumEntries(db, "encrypted_files");
            return numRows;
        }
        catch (SQLException sql)
        {
            return(-1);
        }
    }

    public EncryptedFiles[] GetAllEncryptedFiles()
    {
        EncryptedFiles encryptedFiles[] = new EncryptedFiles[this.NumberOfEncryptedFiles()];
        int index = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery( "select * from encrypted_files", null );
        res.moveToFirst();
        while(res.isAfterLast() == false)
        {
            encryptedFiles[index] = new EncryptedFiles
                    (
                            res.getInt(res.getColumnIndex("id")),
                            res.getString(res.getColumnIndex("file_name")),
                            res.getString(res.getColumnIndex("file_path")),
                            res.getString(res.getColumnIndex("file_type")),
                            res.getString(res.getColumnIndex("status")),
                            res.getString(res.getColumnIndex("new_file_name"))
                    );
            res.moveToNext();
            index = index + 1;
        }
        return encryptedFiles;
    }

    public boolean InsertProfiles(String service_name, String web_url, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("service_name", service_name);
        contentValues.put("web_url", web_url);
        contentValues.put("password", password);
        db.insert("profiles", null, contentValues);
        return(true);
    }

    public boolean UpdateProfiles(Integer id, String service_name, String web_url, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("service_name", service_name);
        contentValues.put("web_url", web_url);
        contentValues.put("password", password);

        db.update("profiles", contentValues, "id = ? ", new String[] {Integer.toString(id) } );
        return(true);
    }

    public int DeleteProfiles(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("profiles", "id = ? ", new String[] { Integer.toString(id) });
    }

    public int NumberOfProfiles()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            int numRows = (int) DatabaseUtils.queryNumEntries(db, "profiles");
            return numRows;
        }
        catch (SQLException sql)
        {
            return(-1);
        }
    }

    public Profiles[] GetAllProfiles()
    {
        Profiles profiles[] = new Profiles[this.NumberOfProfiles()];
        int index = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery( "select * from profiles", null );
        res.moveToFirst();
        while(res.isAfterLast() == false)
        {
            profiles[index] = new Profiles
                    (
                            res.getInt(res.getColumnIndex("id")),
                            res.getString(res.getColumnIndex("service_name")),
                            res.getString(res.getColumnIndex("web_url")),
                            res.getString(res.getColumnIndex("password"))
                    );
            res.moveToNext();
            index = index + 1;
        }
        return profiles;
    }

    public Profiles GetProfile(int id)
    {
        Profiles profiles[] = new Profiles[this.NumberOfProfiles()];
        int index = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery( "select * from profiles where id = "+id, null );
        res.moveToFirst();
        while(res.isAfterLast() == false)
        {
            profiles[index] = new Profiles
                    (
                            res.getInt(res.getColumnIndex("id")),
                            res.getString(res.getColumnIndex("service_name")),
                            res.getString(res.getColumnIndex("web_url")),
                            res.getString(res.getColumnIndex("password"))
                    );
            res.moveToNext();
            index = index + 1;
        }
        return profiles[0];
    }

    public boolean InsertUser(String username, String password, String password_hint)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("password_hint", password_hint);
        db.insert("user", null, contentValues);
        return(true);
    }

    public boolean UpdateUser(Integer id,String username, String password, String password_hint)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("password_hint", password_hint);

        db.update("user", contentValues, "id = ? ", new String[] {Integer.toString(id) } );
        return(true);
    }

    public int DeleteUser(Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("user", "id = ? ", new String[] { Integer.toString(id) });
    }

    public int NumberOfUsers()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            int numRows = (int) DatabaseUtils.queryNumEntries(db, "user");
            return numRows;
        }
        catch (SQLException sql)
        {
            return(-1);
        }
    }

    public User[] GetAllUsers()
    {
        User user[] = new User[this.NumberOfUsers()];
        int index = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery( "select * from user", null );
        res.moveToFirst();
        while(res.isAfterLast() == false)
        {
            user[index] = new User
                    (
                            res.getInt(res.getColumnIndexOrThrow("id")),
                            res.getString(res.getColumnIndex("username")),
                            res.getString(res.getColumnIndex("password")),
                            res.getString(res.getColumnIndex("password_hint"))
                    );
            res.moveToNext();
            index = index + 1;
        }
        return user;
    }

    public Cursor GetCursor(String query)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        return(db.rawQuery(query,null));
    }

    public boolean CreateAllTables()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            db.execSQL("CREATE TABLE hidden_files(id integer primary key, file_name text, file_path text, file_type tex, new_file_name text, status text)");
            db.execSQL("CREATE TABLE encrypted_files(id integer primary key, file_name text, file_path text,file_type text, new_file_name text, status text)");
            db.execSQL("CREATE TABLE profiles(id integer primary key, service_name text, web_url text, password text)");
            db.execSQL("CREATE TABLE user(id integer primary key,username text, password text, password_hint text)");
            return(true);
        }
        catch (SQLException sqlException)
        {
            return(false);
        }
    }

    public boolean DropAllTables()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        try
        {
            db.execSQL("DROP TABLE IF EXISTS hidden_files");
            db.execSQL("DROP TABLE IF EXISTS encrypted_files");
            db.execSQL("DROP TABLE IF EXISTS profiles");
            db.execSQL("DROP TABLE IF EXISTS user");
            return(true);
        }
        catch (SQLException sqlException)
        {
            return(false);
        }
    }
}

