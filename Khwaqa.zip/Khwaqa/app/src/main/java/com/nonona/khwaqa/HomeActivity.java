package com.nonona.khwaqa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.nonona.khwaqa.data.Database;
import com.nonona.khwaqa.data.EncryptedFiles;
import com.nonona.khwaqa.data.Profiles;
import com.nonona.khwaqa.data.User;
import com.nonona.khwaqa.views.ListsView;

import java.io.File;
import java.net.MalformedURLException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HomeActivity extends AppCompatActivity
{
    LinearLayout encrypt_tab;
    LinearLayout profiles_tab;
    LinearLayout more_tab;
    LinearLayout info_settings_tab;
    LinearLayout more_settings_tab;

    EditText service_name;
    EditText users_name_on_the_service;
    EditText user_password_on_the_service;

    FrameLayout setting_info_tab_switch_frameLayout;
    FrameLayout add_profile_modal;

    Button add_file;
    Button add_profile;

    ListsView encrypt_list;
    ListsView profile_list;

    Database database;
    EncryptedFiles[] encryptedFiles;
    Profiles[] profiles;

    ScrollView scroll_files;
    ScrollView scroll_profiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        if(getSupportActionBar() != null)
        {
            getSupportActionBar().setTitle(R.string.app_name);
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setCustomView(R.layout.search_app_bar_layout);
        }

        final EditText search_box = findViewById(R.id.search_text_box);
        search_box.setTextColor(Color.WHITE);

        search_box.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable)
            {
                if(editable.length() < 1)
                {
                    profiles = database.GetAllProfiles();

                    String[] profile_services = new String[profiles.length];
                    int profiles_loop = 0;
                    for(Profiles newProfile : profiles)
                    {
                        profile_services[profiles_loop] = newProfile.getId()+"<+>"+newProfile.getService_name();
                        profiles_loop = profiles_loop + 1;
                    }

                    profile_list = new ListsView(getBaseContext(),profile_services, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AppCompatTextView textView = (AppCompatTextView)view;


                            Intent intent = new Intent(getBaseContext(),ProfilesDetailsActivity.class);
                            intent.putExtra("listItem",textView.getText());
                            intent.putExtra("listItemId",textView.getId());
                            startActivity(intent);
                        }
                    });

                    encryptedFiles = database.GetAllEncryptedFiles();
                    String[] encryptedFileNames = new String[encryptedFiles.length];
                    int encrypted_loop = 0;
                    for(EncryptedFiles encrypted : encryptedFiles)
                    {
                        encryptedFileNames[encrypted_loop] = encrypted.getId()+"<+>"+encrypted.getFile_name();
                        encrypted_loop = encrypted_loop + 1;
                    }

                    encrypt_list = new ListsView(getBaseContext(), encryptedFileNames, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AppCompatTextView textView = (AppCompatTextView)view;
                            Intent intent = new Intent(getBaseContext(),FileListActivity.class);
                            intent.putExtra("name",textView.getText());
                            intent.putExtra("id",textView.getId());
                            startActivity(intent);
                        }
                    });
                    scroll_profiles.removeAllViews();
                    scroll_files.removeAllViews();

                    scroll_files.addView(encrypt_list);
                    scroll_profiles.addView(profile_list);
                }
                else if(encrypt_tab.getVisibility() == View.VISIBLE)
                {
                    Cursor cursor = database.GetCursor
                    (
                    "SELECT * FROM encrypted_files WHERE file_name LIKE '%" + editable.toString() + "%'"
                    );

                    int index = 0;

                    encryptedFiles = new EncryptedFiles[cursor.getCount()];

                    cursor.moveToFirst();
                    while (cursor.isAfterLast() == false)
                    {
                        encryptedFiles[index] = new EncryptedFiles
                        (
                                cursor.getInt(cursor.getColumnIndex("id")),
                                cursor.getString(cursor.getColumnIndex("file_name")),
                                cursor.getString(cursor.getColumnIndex("file_path")),
                                cursor.getString(cursor.getColumnIndex("file_type")),
                                cursor.getString(cursor.getColumnIndex("new_file_name")),
                                cursor.getString(cursor.getColumnIndex("status"))
                        );
                        cursor.moveToNext();
                        index = index + 1;
                    }

                    String[] encryptedFileNames = new String[encryptedFiles.length];
                    int encrypted_loop = 0;
                    for(EncryptedFiles encrypted : encryptedFiles)
                    {
                        encryptedFileNames[encrypted_loop] = encrypted.getId()+"<+>"+encrypted.getFile_name();
                        encrypted_loop = encrypted_loop + 1;
                    }

                    encrypt_list = new ListsView(getBaseContext(), encryptedFileNames, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AppCompatTextView textView = (AppCompatTextView)view;
                            Intent intent = new Intent(getBaseContext(),FileListActivity.class);
                            intent.putExtra("name",textView.getText());
                            intent.putExtra("id",textView.getId());
                            startActivity(intent);
                        }
                    });
                    scroll_files.removeAllViews();
                    scroll_files.addView(encrypt_list);
                }
                else if (profiles_tab.getVisibility() == View.VISIBLE)
                {
                    Cursor cursor = database.GetCursor
                            (
                                    "SELECT * FROM profiles WHERE service_name LIKE '%" + editable.toString() + "%'"
                            );

                    int index = 0;

                    profiles = new Profiles[cursor.getCount()];

                    cursor.moveToFirst();
                    while (cursor.isAfterLast() == false)
                    {
                        profiles[index] = new Profiles
                                (
                                        cursor.getInt(cursor.getColumnIndex("id")),
                                        cursor.getString(cursor.getColumnIndex("service_name")),
                                        cursor.getString(cursor.getColumnIndex("web_url")),
                                        cursor.getString(cursor.getColumnIndex("password"))
                                );
                        cursor.moveToNext();
                        index = index + 1;
                    }

                    String[] profile_services = new String[profiles.length];
                    int profiles_loop = 0;
                    for(Profiles newProfile : profiles)
                    {
                        profile_services[profiles_loop] = newProfile.getId()+"<+>"+newProfile.getService_name();
                        profiles_loop = profiles_loop + 1;
                    }

                    profile_list = new ListsView(getBaseContext(),profile_services, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AppCompatTextView textView = (AppCompatTextView)view;

                            Intent intent = new Intent(getBaseContext(),ProfilesDetailsActivity.class);
                            intent.putExtra("listItem",textView.getText());
                            intent.putExtra("listItemId",textView.getId());
                            startActivity(intent);
                        }
                    });
                    scroll_profiles.removeAllViews();
                    scroll_profiles.addView(profile_list);
                }
            }
        });

        ImageView clear_search_button = findViewById(R.id.clear_search_button);

        ImageView search_button = findViewById(R.id.search_button_toggle);

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout in_search = findViewById(R.id.in_search_layout);
                LinearLayout out_search = findViewById(R.id.out_search_layout);

                in_search.setVisibility(View.VISIBLE);
                out_search.setVisibility(View.GONE);
            }
        });

        clear_search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout in_search = findViewById(R.id.in_search_layout);
                LinearLayout out_search = findViewById(R.id.out_search_layout);

                EditText search_box = findViewById(R.id.search_text_box);
                search_box.setText("");

                in_search.setVisibility(View.GONE);
                out_search.setVisibility(View.VISIBLE);
            }
        });

        database = new Database(getBaseContext());
        encryptedFiles = database.GetAllEncryptedFiles();
        String[] encryptedFileNames = new String[encryptedFiles.length];
        int encrypted_loop = 0;
        for(EncryptedFiles encrypted : encryptedFiles)
        {
            encryptedFileNames[encrypted_loop] = encrypted.getId()+"<+>"+encrypted.getFile_name();
            encrypted_loop = encrypted_loop + 1;
        }

        encrypt_list = new ListsView(getBaseContext(), encryptedFileNames, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatTextView textView = (AppCompatTextView)view;
                Intent intent = new Intent(getBaseContext(),FileListActivity.class);
                intent.putExtra("name",textView.getText());
                intent.putExtra("id",textView.getId());
                startActivity(intent);
            }
        });


        profiles = database.GetAllProfiles();
        String[] profile_services = new String[profiles.length];
        int profiles_loop = 0;
        for(Profiles newProfile : profiles)
        {
            profile_services[profiles_loop] = profile_services[profiles_loop] = newProfile.getId()+"<+>"+newProfile.getService_name();
            profiles_loop = profiles_loop + 1;
        }

        profile_list = new ListsView(getBaseContext(),profile_services, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatTextView textView = (AppCompatTextView)view;

                Intent intent = new Intent(getBaseContext(),ProfilesDetailsActivity.class);
                intent.putExtra("listItem",textView.getText());
                intent.putExtra("listItemId",textView.getId());
                startActivity(intent);
            }
        });

        info_settings_tab = findViewById(R.id.info_settings_tab);;
        more_settings_tab = findViewById(R.id.more_settings_tab);

        LinearLayout add_profile_container = findViewById(R.id.add_profile_container);
        add_profile_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        Button close_add_profile_modal = findViewById(R.id.close_add_profile_modal);
        close_add_profile_modal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                service_name.setText("");
                users_name_on_the_service.setText("");
                user_password_on_the_service.setText("");
                add_profile_modal.setVisibility(View.GONE);
            }
        });

        Button save_profile = findViewById(R.id.save_profile);
        save_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(
                    !(service_name.getText().toString().isEmpty()) ||
                    !(users_name_on_the_service.getText().toString().isEmpty())  ||
                    !(user_password_on_the_service.getText().toString().isEmpty())
                    )
                {
                    String result = database.InsertProfiles(
                            service_name.getText().toString(),
                            users_name_on_the_service.getText().toString(),
                            user_password_on_the_service.getText().toString()) ? "success" : "failed to add profile";

                    scroll_profiles.removeAllViews();
                    profiles = database.GetAllProfiles();
                    String[] profile_services = new String[profiles.length];
                    int profiles_loop = 0;
                    for(Profiles newProfile : profiles)
                    {
                        profile_services[profiles_loop] = newProfile.getId()+"<+>"+newProfile.getService_name();
                        profiles_loop = profiles_loop + 1;
                    }

                    profile_list = new ListsView(getBaseContext(),profile_services, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AppCompatTextView textView = (AppCompatTextView)view;


                            Intent intent = new Intent(getBaseContext(),ProfilesDetailsActivity.class);
                            intent.putExtra("listItem",textView.getText());
                            intent.putExtra("listItemId",textView.getId());
                            startActivity(intent);
                        }
                    });
                    scroll_profiles.addView(profile_list);
                    service_name.setText("");
                    users_name_on_the_service.setText("");
                    user_password_on_the_service.setText("");
                    add_profile_modal.setVisibility(View.GONE);

                    Toast.makeText(getBaseContext(),result,Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getBaseContext(),"Please fill all the boxes",Toast.LENGTH_SHORT).show();
                }
            }
        });
        setting_info_tab_switch_frameLayout = findViewById(R.id.setting_info_tab_switch_frameLayout);

        ImageView imageView3 = findViewById(R.id.imageView3);
        ImageView imageView4 = findViewById(R.id.imageView4);
        ImageView imageView5 = findViewById(R.id.imageView5);

        encrypt_tab = findViewById(R.id.encrypt_tab);
        profiles_tab = findViewById(R.id.profiles_tab);
        more_tab = findViewById(R.id.more_tab);

        service_name = findViewById(R.id.edittext_service_name);
        users_name_on_the_service = findViewById(R.id.edittext_service_username);
        user_password_on_the_service = findViewById(R.id.editText_Service_password);

        imageView4.setOnClickListener(Switch_to_lock_tab);
        imageView5.setOnClickListener(Switch_to_profiles_tab);
        imageView3.setOnClickListener(Switch_to_more_tab);

        scroll_files = findViewById(R.id.scroll_files);
        scroll_profiles = findViewById(R.id.scroll_profiles);

        add_file = findViewById(R.id.add_file);
        add_profile = findViewById(R.id.add_profile);

        add_profile_modal = findViewById(R.id.add_profile_modal);
        add_profile_modal.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            imageView3.setBackground(CoolEditText());
            imageView4.setBackground(CoolEditText());
            imageView5.setBackground(CoolEditText());

            service_name.setBackground(CoolEditTexts());
            users_name_on_the_service.setBackground(CoolEditTexts());
            user_password_on_the_service.setBackground(CoolEditTexts());

            add_file.setBackground(CoolBigButton());
            add_profile.setBackground(CoolBigButton());
        }

        add_file.setOnClickListener(new View.OnClickListener() 
        {
            @Override
            public void onClick(View view) {
                Intent getFile = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                getFile.addCategory(Intent.CATEGORY_OPENABLE);
                getFile.setType("*/*");
                
                Uri newUri = null;
                getFile.putExtra(DocumentsContract.EXTRA_INITIAL_URI,newUri);
                startActivityForResult(getFile, 10);
            }
        });

        add_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_profile_modal.setVisibility(View.VISIBLE);
            }
        });

        ImageView info_switch_button = findViewById(R.id.info_switch_button);
        info_switch_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                more_settings_tab.setVisibility(View.GONE);
                info_settings_tab.setVisibility(View.VISIBLE);
            }
        });

        ImageView settings_tab_switch_button = findViewById(R.id.settings_tab_switch_button);
        settings_tab_switch_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                more_settings_tab.setVisibility(View.VISIBLE);
                info_settings_tab.setVisibility(View.GONE);
            }
        });

        Date date = new Date();
        TextView date_textView = findViewById(R.id.date_textView);
        date_textView.setText(date.toString().substring(date.toString().length() - 5));

        final EditText change_password_current_password_editText = findViewById(R.id.change_password_current_password_editText);
        final EditText change_password_editText = findViewById(R.id.change_password_editText);
        final EditText change_password_confirm_editText = findViewById(R.id.change_password_confirm_editText);
        final EditText change_password_hint_editText = findViewById(R.id.change_password_hint_editText);

        Button change_password_ok_button = findViewById(R.id.change_password_ok_button);
        change_password_ok_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if
                (
                        !(change_password_current_password_editText.getText().toString().isEmpty()) ||
                                !(change_password_editText.getText().toString().isEmpty()) ||
                                !(change_password_confirm_editText.getText().toString().isEmpty()) ||
                                !(change_password_hint_editText.getText().toString().isEmpty())
                )
                {
                    try
                    {
                        User user = database.GetAllUsers()[0];
                        if(!(change_password_editText.getText().toString().equals(change_password_confirm_editText.getText().toString())))
                        {
                            Toast.makeText(getBaseContext(),"Password field and password confirm field do not match",Toast.LENGTH_LONG).show();
                            change_password_current_password_editText.setText("");
                            change_password_editText.setText("");
                            change_password_confirm_editText.setText("");
                            change_password_hint_editText.setText("");
                            return;
                        }
                        if(user.getPassword().equals(change_password_current_password_editText.getText().toString()))
                        {
                            boolean update = database.UpdateUser
                                    (
                                            user.getId(),
                                            user.getUsername(),
                                            change_password_editText.getText().toString(),
                                            change_password_hint_editText.getText().toString()
                                    );
                            if(update == true)
                            {
                                Toast.makeText(getBaseContext(),"Password update was a success",Toast.LENGTH_LONG).show();
                                change_password_current_password_editText.setText("");
                                change_password_editText.setText("");
                                change_password_confirm_editText.setText("");
                                change_password_hint_editText.setText("");
                            }
                            else
                            {
                                Toast.makeText(getBaseContext(),"Password update failed",Toast.LENGTH_LONG).show();
                                change_password_current_password_editText.setText("");
                                change_password_editText.setText("");
                                change_password_confirm_editText.setText("");
                                change_password_hint_editText.setText("");
                            }
                        }
                        else
                        {
                            Toast.makeText(getBaseContext(),"I do not recognise this password!",Toast.LENGTH_LONG).show();
                        }
                    }
                    catch(Exception e)
                    {
                        Toast.makeText(getBaseContext(),"Oops! Something went wrong while updating your password",Toast.LENGTH_LONG).show();
                        change_password_current_password_editText.setText("");
                        change_password_editText.setText("");
                        change_password_confirm_editText.setText("");
                        change_password_hint_editText.setText("");
                    }
                }
                else
                {
                    Toast.makeText(getBaseContext(),"Fill all fields please",Toast.LENGTH_LONG).show();
                }
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
        {
            change_password_ok_button.setBackground(CoolBigButton());
            change_password_current_password_editText.setBackground(CoolEditTexts());
            change_password_editText.setBackground(CoolEditTexts());
            change_password_confirm_editText.setBackground(CoolEditTexts());
            change_password_hint_editText.setBackground(CoolEditTexts());
        }

        scroll_files.addView(encrypt_list);
        scroll_profiles.addView(profile_list);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == 10 && resultCode == Activity.RESULT_OK)
        {
            Uri uri = data.getData();
            grantUriPermission("com.sec.android.provider.badge.permission",uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            File file = new File(uri.getPath());

            String[] proj = {MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.DISPLAY_NAME};
            Cursor cursor = getBaseContext().getContentResolver().query(uri,proj,null,null,null);
            cursor.moveToFirst();

            EncryptedFiles encryptedFile = null;
            try {
                encryptedFile = new EncryptedFiles
                (
                    0,
                    cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)),
                    file.toURL().getPath(),
                    cursor.getString
                    (
                            cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                    ).substring
                    (
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)).lastIndexOf(".") + 1
                    ),
                    ".data_"+ new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()),
                    "unlocked"
                );
            }
            catch (MalformedURLException e)
            {
                e.printStackTrace();
            }

            if(database.InsertEncryptedFiles(encryptedFile))
            {
                Toast.makeText(getBaseContext(),"The file has been added successfully to this app records",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getBaseContext(),"We have encountered a problem while recording the file ",Toast.LENGTH_LONG).show();
            }

            database = new Database(getBaseContext());
            encryptedFiles = database.GetAllEncryptedFiles();

            String[] encryptedFileNames = new String[encryptedFiles.length];
            int encrypted_loop = 0;
            for(EncryptedFiles encrypted : encryptedFiles)
            {
                encryptedFileNames[encrypted_loop] = encrypted.getId()+"<+>"+encrypted.getFile_name();
                encrypted_loop = encrypted_loop + 1;
            }

            encrypt_list = new ListsView(getBaseContext(), encryptedFileNames, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AppCompatTextView textView = (AppCompatTextView)view;
                    Intent intent = new Intent(getBaseContext(),FileListActivity.class);
                    intent.putExtra("name",textView.getText());
                    intent.putExtra("id",textView.getId());
                    startActivity(intent);
                }
            });

            scroll_files.removeAllViews();
            scroll_files.addView(encrypt_list);
        }
    }

    View.OnClickListener Switch_to_lock_tab = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            encrypt_tab.setVisibility(View.VISIBLE);
            profiles_tab.setVisibility(View.GONE);
            more_tab.setVisibility(View.GONE);

            TextView encrypt_tab_pointer = findViewById(R.id.encrypt_tab_pointer);
            TextView profiles_tab_pointer = findViewById(R.id.profiles_tab_pointer);
            TextView more_tab_pointer = findViewById(R.id.more_tab_pointer);

            encrypt_tab_pointer.setVisibility(View.VISIBLE);
            profiles_tab_pointer.setVisibility(View.GONE);
            more_tab_pointer.setVisibility(View.GONE);

            setting_info_tab_switch_frameLayout.setVisibility(View.GONE);
            more_settings_tab.setVisibility(View.GONE);
            info_settings_tab.setVisibility(View.GONE);
        }
    };

    View.OnClickListener Switch_to_profiles_tab = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            encrypt_tab.setVisibility(View.GONE);
            profiles_tab.setVisibility(View.VISIBLE);
            more_tab.setVisibility(View.GONE);

            TextView encrypt_tab_pointer = findViewById(R.id.encrypt_tab_pointer);
            TextView profiles_tab_pointer = findViewById(R.id.profiles_tab_pointer);
            TextView more_tab_pointer = findViewById(R.id.more_tab_pointer);

            encrypt_tab_pointer.setVisibility(View.GONE);
            profiles_tab_pointer.setVisibility(View.VISIBLE);
            more_tab_pointer.setVisibility(View.GONE);
            more_settings_tab.setVisibility(View.GONE);

            setting_info_tab_switch_frameLayout.setVisibility(View.GONE);
            info_settings_tab.setVisibility(View.GONE);
        }
    };

    View.OnClickListener Switch_to_more_tab = new View.OnClickListener()
    {
        @Override
        public void onClick(View view)
        {
            encrypt_tab.setVisibility(View.GONE);
            profiles_tab.setVisibility(View.GONE);
            more_tab.setVisibility(View.VISIBLE);

            TextView encrypt_tab_pointer = findViewById(R.id.encrypt_tab_pointer);
            TextView profiles_tab_pointer = findViewById(R.id.profiles_tab_pointer);
            TextView more_tab_pointer = findViewById(R.id.more_tab_pointer);

            encrypt_tab_pointer.setVisibility(View.GONE);
            profiles_tab_pointer.setVisibility(View.GONE);
            more_tab_pointer.setVisibility(View.VISIBLE);

            setting_info_tab_switch_frameLayout.setVisibility(View.VISIBLE);
            more_settings_tab.setVisibility(View.VISIBLE);
            info_settings_tab.setVisibility(View.GONE);
        }
    };

    private Drawable CoolEditTexts()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(5);
        gradientDrawable.setStroke(3,Color.LTGRAY);
        gradientDrawable.setColor(Color.WHITE);
        return(gradientDrawable);
    }

    private Drawable CoolEditText()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(300);
        gradientDrawable.setStroke(5, Color.LTGRAY);
        //gradientDrawable.setColor(Color.WHITE);
        return(gradientDrawable);
    }

    private Drawable CoolBigButton()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(50);
        //gradientDrawable.setStroke(5, Color.RED);
        gradientDrawable.setColor(ContextCompat.getColor(getBaseContext(),R.color.my_blue_background));
        return(gradientDrawable);
    }
}