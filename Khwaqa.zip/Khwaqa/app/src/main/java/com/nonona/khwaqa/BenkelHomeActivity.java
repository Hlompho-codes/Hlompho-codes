package com.nonona.khwaqa;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.nonona.khwaqa.views.RoundedShadowedLayout;

public class BenkelHomeActivity extends AppCompatActivity
{
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        /*************************** Go fullscreen **************************
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        decorView.forceLayout();
        if(getSupportActionBar() != null){getSupportActionBar().hide();}
        /*************************************************************************/

        FrameLayout root = new FrameLayout(getApplicationContext());
        root.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView backgroundBanner = new ImageView(getBaseContext());
        backgroundBanner.setAdjustViewBounds(true);
        backgroundBanner.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        backgroundBanner.setBackgroundColor(Color.parseColor("#6200EE"));

        EditText search_box = new EditText(getBaseContext());
        search_box.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        search_box.setPadding(10,10,10,10);

        RoundedShadowedLayout roundedShadowedLayout = new RoundedShadowedLayout(getBaseContext());
        roundedShadowedLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(backgroundBanner);

        roundedShadowedLayout.addView(search_box);

        root.addView(roundedShadowedLayout);
        setContentView(root);

    }
}
