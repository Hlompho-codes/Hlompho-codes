package com.nonona.khwaqa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FullscreenActivity extends AppCompatActivity {

    private static final int READ_STORAGE_REQUEST_CODE = 101;
    private static final int WRITE_STORAGE_REQUEST_CODE = 102;

    TextView write_errors_textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        write_errors_textView6 = findViewById(R.id.write_errors_textView6);

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        decorView.forceLayout();
        if(getSupportActionBar() != null)
        {
            getSupportActionBar().hide();
        }

        SetUpPermissions();

        Button navigate_to_benkel_app_button2 = findViewById(R.id.navigate_to_benkel_app_button2);
        navigate_to_benkel_app_button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent nav_to_benkel = new Intent(getBaseContext(), BenkelHomeActivity.class);
                startActivity(nav_to_benkel);
            }
        });

        ExitActivity quit = new ExitActivity();
        quit.start();
    }

    private class ExitActivity extends Thread
    {
        public void run() {
            try
            {
                Thread.sleep(2000);
                Intent logInIntent = new Intent(getBaseContext(), LogInActivity.class);
                startActivity(logInIntent);
                finish();
            }
            catch (InterruptedException e)
            {
            }
        }
    }
    private void SetUpPermissions()
    {
        int read_storage_permission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int write_storage_permission = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        /**
        if(read_storage_permission != PackageManager.PERMISSION_GRANTED)
        {
            write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to read files on the device denied");
        }
        else
        {
            write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to read files on the device granted");
        }

        if(write_storage_permission != PackageManager.PERMISSION_GRANTED)
        {
            write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to write files to the device denied");
        }
        else
        {
            write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to write files to the device granted");
        }
         **/
        makePermissionRequest();
    }

    private void makePermissionRequest()
    {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},READ_STORAGE_REQUEST_CODE);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},WRITE_STORAGE_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode)
        {
            case READ_STORAGE_REQUEST_CODE:
            {
                /**
                if(grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)
                {
                    write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to read files on the device denied by the user");
                }
                else
                {
                    write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to read files on the device granted by the user");
                }
                 **/
            }
            case WRITE_STORAGE_REQUEST_CODE:
            {
                /**
                if(grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)
                {
                    write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to write files on the device denied by the user");
                }
                else
                {
                    write_errors_textView6.setText(write_errors_textView6.getText()+"\nPermission to write files on the device granted by the user");
                }
                 **/
            }
        }
    }
}