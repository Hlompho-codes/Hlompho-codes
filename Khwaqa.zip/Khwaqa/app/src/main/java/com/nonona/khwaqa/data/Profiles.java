package com.nonona.khwaqa.data;

public class Profiles
{
    private int id;
    private String service_name;
    private String web_url;
    private String password;

    public Profiles(int id, String service_name, String web_url, String password) {
        this.id = id;
        this.service_name = service_name;
        this.web_url = web_url;
        this.password = password;
    }

    public int getId() {  return id; }

    public void setId(int id) {  this.id = id; }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getWeb_url() {
        return web_url;
    }

    public void setWeb_url(String web_url) {
        this.web_url = web_url;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
