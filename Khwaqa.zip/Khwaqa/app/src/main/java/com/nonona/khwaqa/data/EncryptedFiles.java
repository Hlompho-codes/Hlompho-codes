package com.nonona.khwaqa.data;

public class EncryptedFiles
{
    private String file_type;
    private String file_name;
    private String file_path;
    private String new_file_name;
    private String status;
    private int id;
    public EncryptedFiles(int id,String file_name, String file_path,String file_type, String new_file_name, String status) {
        this.id = id;
        this.file_type = file_type;
        this.file_name = file_name;
        this.file_path = file_path;
        this.new_file_name = new_file_name;
        this.status = status;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getFile_path() {
        return file_path;
    }

    public void setFile_path(String file_path) {
        this.file_path = file_path;
    }

    public String getNew_file_name() {
        return new_file_name;
    }

    public void setNew_file_name(String new_file_name) {
        this.new_file_name = new_file_name;
    }

    public String getFile_type() {
        return file_type;
    }

    public void setFile_type(String file_type) {
        this.file_type = file_type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
