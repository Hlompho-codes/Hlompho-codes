package com.nonona.khwaqa.views;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class Tabs extends ScrollView
{
    private LinearLayout Root;
    private LinearLayout TabsContainer;
    private TabsContent[] Tabscontent;
    private int TabId;
    private int loop;

    public Tabs(Context context, final TabsContent[] tabsContent)
    {
        super(context);

        this.Root = new LinearLayout(getContext());
        this.Root.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));
        this.Root.setOrientation(LinearLayout.VERTICAL);
        this.Root.setGravity(Gravity.CENTER);
        this.Root.setBackgroundColor(Color.YELLOW);

        this.TabsContainer = new LinearLayout(getContext());
        this.TabsContainer.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT));
        this.TabsContainer.setOrientation(LinearLayout.HORIZONTAL);
        this.TabsContainer.setGravity(Gravity.CENTER);
        this.Root.setBackgroundColor(Color.RED);

        this.loop = 0;
        this.Tabscontent = tabsContent;
        this.Root.addView(TabsContainer);
        this.loop = 0;
        /**
        for(TabsContent content : tabsContent)
        {
            content = new TabsContent(context,tabsContent.length);

            final TabButton button = new TabButton(context,tabsContent[loop].tabHeading);
            button.setOnClickListener(new OnClickListener()
            {
                 @Override
                 public void onClick(View view)
                 {
                     for(TabsContent control : getTabscontent())
                     {
                        if(button.getText().equals(control.getTabHeading()))
                        {
                            control.setVisibility(VISIBLE);
                        }
                        else
                        {
                            control.setVisibility(GONE);
                        }
                     }
                 }
            });
            this.TabsContainer.addView(button);
            content.setID(this.loop);
            content.setVisibility(GONE);
            this.setTabId(content.getID());
            this.Root.addView(content);
            this.loop = this.loop + 1;
        }
        tabsContent[0].setVisibility(VISIBLE);
        if(tabsContent[0].getVisibility() == VISIBLE)
        {
            Toast.makeText(context,"We can see you tab {0}", Toast.LENGTH_SHORT).show();
        }
         **/
        this.addView(this.Root);
    }

    public TabsContent[] getTabscontent() {
        return Tabscontent;
    }

    public int getTabId()
    {
        return TabId;
    }

    public void setTabId(int tabId) {
        TabId = tabId;
    }
}
