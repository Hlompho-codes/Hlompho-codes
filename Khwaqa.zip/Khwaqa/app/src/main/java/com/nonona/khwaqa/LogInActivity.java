package com.nonona.khwaqa;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.nonona.khwaqa.data.Database;
import com.nonona.khwaqa.data.User;

public class LogInActivity extends AppCompatActivity {
    public boolean sign_in_visible;
    public LinearLayout sign_in;
    public LinearLayout sign_up;
    public Button toggle;

    public Database database;
    EditText log_in_username;
    EditText log_in_password;
    EditText sign_up_username;
    EditText sign_up_password;
    EditText sign_up_password_hint;

    public int login_tries;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        database = new Database(getBaseContext());

        //database.CreateAllTables();

        login_tries = 0;

        sign_in_visible = true;
        sign_in = findViewById(R.id.sign_in_root_container);
        sign_up = findViewById(R.id.sign_up_root_container);
        sign_up.setVisibility(View.GONE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
        {
            sign_in.setBackground(getDrawableWithRadius());
            sign_up.setBackground(getDrawableWithRadius());
        }

        toggle = findViewById(R.id.button_sign_up);
        toggle.setBackground(CoolEditText());
        toggle.setOnClickListener(Toggle_sign);

        Button ok = findViewById(R.id.button_ok);
        ok.setBackground(CoolEditText());
        ok.setOnClickListener(Ok_Button);

        log_in_username = findViewById(R.id.log_in_username);
        log_in_username.setBackground(CoolEditText());

        log_in_password = findViewById(R.id.log_in_password);
        log_in_password.setBackground(CoolEditText());

        sign_up_username = findViewById(R.id.sign_up_username);
        sign_up_username.setBackground(CoolEditText());

        sign_up_password = findViewById(R.id.sign_up_password);
        sign_up_password.setBackground(CoolEditText());

        sign_up_password_hint = findViewById(R.id.sign_up_password_hint);
        sign_up_password_hint.setBackground(CoolEditText());
    }

    private Drawable getDrawableWithRadius()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(20);
        gradientDrawable.setColor(Color.WHITE);
        return(gradientDrawable);
    }

    private Drawable CoolEditText()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(5);
        gradientDrawable.setStroke(3,Color.LTGRAY);
        gradientDrawable.setColor(Color.WHITE);
        return(gradientDrawable);
    }

    View.OnClickListener Ok_Button = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            Database database = new Database(getBaseContext());
            if(sign_in_visible)
            {
                if(database.NumberOfUsers() < 1)
                {
                    Toast.makeText(getBaseContext(),"Please sign up first", Toast.LENGTH_SHORT).show();
                    return;
                }

                User users[] = database.GetAllUsers();
                if(users[0].getUsername().equals(log_in_username.getText().toString()) &&
                        users[0].getPassword().equals(log_in_password.getText().toString()))
                {
                    Intent goHomeIntent = new Intent(getBaseContext(), HomeActivity.class);
                    startActivity(goHomeIntent);
                    finish();
                }
                else
                {
                    if((getLogin_tries() < 3))
                    {
                        Toast.makeText(getBaseContext(),"I do not recognise either your username or password", Toast.LENGTH_SHORT).show();
                        setLogin_tries(getLogin_tries() + 1);
                    }
                    else
                    {
                        Toast.makeText(getBaseContext(),"Password hint : "+users[0].getPassword_hint(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            else
            {
                if(database.NumberOfUsers() > 0)
                {
                    Toast.makeText(getBaseContext(),"You cannot have many accounts, " +
                            "please log in an change your account details", Toast.LENGTH_SHORT).show();
                    return;
                }

                User users[] = database.GetAllUsers();

                if((!sign_up_username.getText().toString().equals(""))
                        && (!sign_up_password.getText().toString().equals(""))
                        && (!sign_up_password_hint.getText().toString().equals("")))
                {
                    if(database.InsertUser(sign_up_username.getText().toString(),
                            sign_up_password.getText().toString(),
                            sign_up_password_hint.getText().toString()) == true)
                    {
                        Toast.makeText(getBaseContext(),"Successfully signed up with Lepata", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(getBaseContext(),"Oops! Something went wrong, please try again", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(getBaseContext(),"No blanks please", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };
    View.OnClickListener Toggle_sign = new View.OnClickListener()
    {
        @Override
        public void onClick(View v)
        {
            if(sign_in_visible)
            {
                sign_in.setVisibility(View.GONE);
                sign_up.setVisibility(View.VISIBLE);
                toggle.setText(R.string.sign_in);
                sign_in_visible = false;
            }
            else
            {
                sign_in.setVisibility(View.VISIBLE);
                sign_up.setVisibility(View.GONE);
                toggle.setText(R.string.sign_up);
                sign_in_visible = true;
            }
        }
    };

    public int getLogin_tries()
    {
        return login_tries;
    }

    public void setLogin_tries(int login_tries) {
        this.login_tries = login_tries;
    }
}