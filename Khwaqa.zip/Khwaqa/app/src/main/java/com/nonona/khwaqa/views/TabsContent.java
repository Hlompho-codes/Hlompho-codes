package com.nonona.khwaqa.views;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TabsContent extends LinearLayout
{
    String tabHeading;

    int ID;
    public TabsContent(Context context, int id)
    {
        super(context);
        this.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT));
        this.setOrientation(LinearLayout.VERTICAL);
        this.setGravity(Gravity.CENTER);

        TextView text = new TextView(context);
        text.setText("We have a tab");
        this.addView(text);
        this.tabHeading = "";
        this.ID = ID;
    }

    public String getTabHeading() {
        return tabHeading;
    }

    public void setTabHeading(String tabHeading) {
        this.tabHeading = tabHeading;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
