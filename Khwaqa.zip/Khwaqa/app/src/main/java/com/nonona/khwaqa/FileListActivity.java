package com.nonona.khwaqa;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.nonona.khwaqa.data.AESCrypt;
import com.nonona.khwaqa.data.Database;
import com.nonona.khwaqa.data.EncryptedFiles;
import com.nonona.khwaqa.views.ListsView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.channels.FileChannel;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class FileListActivity extends AppCompatActivity
{
    FrameLayout rootLayout;
    TextView FileListEncryptedFileTextView_FileName;
    TextView FileListEncryptedFileTextView_OldFilePath;
    TextView FileListEncryptedFileTextView_FileType;
    TextView FileListEncryptedFileTextView_NewFilePath;
    TextView FileListEncryptedFileTextView_status;

    Button open_file_button;
    Button cancel_delete_file_button;
    Button delete_file_button_ok;

    LinearLayout lock_file_button;
    LinearLayout unlock_file_button;
    LinearLayout delete_file_button;

    FrameLayout delete_file_confirm_modal;

    int IMPORT_FLAG = 1;
    int EXPORT_FLAG = 2;
    int id;

    Database database;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_list);

        if(getSupportActionBar() != null)
        {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("File details");
            getSupportActionBar().setSubtitle(getIntent().getStringExtra("name"));
        }

        rootLayout = findViewById(R.id.file_list_root);

        FileListEncryptedFileTextView_FileName = findViewById(R.id.FileListEncryptedFileTextView_FileName);
        FileListEncryptedFileTextView_OldFilePath = findViewById(R.id.FileListEncryptedFileTextView_OldFilePath);
        FileListEncryptedFileTextView_FileType = findViewById(R.id.FileListEncryptedFileTextView_FileType);
        FileListEncryptedFileTextView_NewFilePath = findViewById(R.id.FileListEncryptedFileTextView_NewFilePath);
        FileListEncryptedFileTextView_status = findViewById(R.id.FileListEncryptedFileTextView_status);

        delete_file_confirm_modal = findViewById(R.id.delete_file_confirm_modal);

        cancel_delete_file_button = findViewById(R.id.cancel_delete_file_button);
        cancel_delete_file_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete_file_confirm_modal.setVisibility(View.GONE);
            }
        });

        delete_file_button = findViewById(R.id.delete_file_button);
        delete_file_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                delete_file_confirm_modal.setVisibility(View.VISIBLE);
            }
        });

        id = 0;
        database = new Database(getBaseContext());
        Cursor cursor = database.GetCursor("SELECT * FROM encrypted_files WHERE file_name = '"+getIntent().getStringExtra("name")+"'");
        cursor.moveToFirst();
        while(cursor.isAfterLast() == false)
        {
            id = cursor.getInt(cursor.getColumnIndex("id"));
            FileListEncryptedFileTextView_FileName.setText(cursor.getString(cursor.getColumnIndex("file_name")));
            FileListEncryptedFileTextView_OldFilePath.setText(cursor.getString(cursor.getColumnIndex("file_path")));
            FileListEncryptedFileTextView_FileType.setText(cursor.getString(cursor.getColumnIndex("file_type")));
            FileListEncryptedFileTextView_NewFilePath.setText(cursor.getString(cursor.getColumnIndex("new_file_name")));
            FileListEncryptedFileTextView_status.setText(cursor.getString(cursor.getColumnIndex("status")));

            cursor.moveToNext();
        }

        open_file_button = findViewById(R.id.open_file_button);
        open_file_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                String mimeType = mimeTypeMap.getMimeTypeFromExtension
                (
                        FileExtension(FileListEncryptedFileTextView_NewFilePath.getText().toString().substring(1))
                );
                intent.setDataAndType
                (
                        Uri.fromFile(new File(FileListEncryptedFileTextView_NewFilePath.getText().toString())),mimeType
                );
                try
                {
                    startActivity(intent);
                }
                catch(ActivityNotFoundException e)
                {
                    Toast.makeText(getBaseContext(),"Oops! No app can open this file",Toast.LENGTH_LONG).show();
                }
            }
        });


        lock_file_button = findViewById(R.id.lock_file_button);
        lock_file_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                try
                {
                    File file = new File(FileListEncryptedFileTextView_OldFilePath.getText().toString());

                    if(!(file.renameTo(new File(FileListEncryptedFileTextView_NewFilePath.getText().toString()))))
                    {
                        Toast.makeText(
                                getBaseContext(),
                                "An error occurred while locking this file \n",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    database.UpdateEncryptedFiles
                    (
                            id,
                            new EncryptedFiles
                            (
                                    id,
                                    FileListEncryptedFileTextView_FileName.getText().toString(),
                                    FileListEncryptedFileTextView_OldFilePath.getText().toString(),
                                    FileListEncryptedFileTextView_FileType.getText().toString(),
                                    FileListEncryptedFileTextView_OldFilePath.getText().toString(),
                                    "locked"
                            )
                    );
                    Toast.makeText(getBaseContext(),"You have locked this file",Toast.LENGTH_SHORT).show();
                }
                catch(SQLException e)
                {
                    Toast.makeText(
                            getBaseContext(),
                            "An error occurred while locking this file_1 \n "+e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        unlock_file_button = findViewById(R.id.unlock_file_button);
        unlock_file_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    File file = new File(FileListEncryptedFileTextView_NewFilePath.getText().toString());

                    if(!(file.renameTo(new File(FileListEncryptedFileTextView_OldFilePath.getText().toString()))))
                    {
                        Toast.makeText(
                                getBaseContext(),
                                "An error occurred while unlocking this file \n",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    database.UpdateEncryptedFiles
                    (
                        id,
                        new EncryptedFiles
                                (
                                        id,
                                        FileListEncryptedFileTextView_FileName.getText().toString(),
                                        FileListEncryptedFileTextView_OldFilePath.getText().toString(),
                                        FileListEncryptedFileTextView_FileType.getText().toString(),
                                        FileListEncryptedFileTextView_OldFilePath.getText().toString(),
                                        "unlocked"
                                )
                    );

                    Toast.makeText(getBaseContext(),"You have unlocked this file",Toast.LENGTH_SHORT).show();
                }
                catch(SQLException e)
                {
                    Toast.makeText(
                            getBaseContext(),
                            "An error occurred while unlocking this file_1 \n"+e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
        {
            open_file_button.setBackground(CoolBigButton());
        }

        delete_file_button_ok = findViewById(R.id.delete_file_button_ok);
        delete_file_button_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(database       .DeleteEncryptedFiles(id) > 0)
                {
                    Toast.makeText(getBaseContext(),"File successfully deleted",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getBaseContext(),HomeActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(getBaseContext(),"An error occurred while deleting a file",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean import_or_export_File(int IMPORT_OR_EXPORT_FLAG, File src, File dst) throws IOException
    {
        FileChannel inChannel = null;
        FileChannel outChannel = null;

        try
        {
            inChannel = new FileInputStream(src).getChannel();
            outChannel = new FileOutputStream(dst).getChannel();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

        try
        {
            if(inChannel == null)
            {
                Toast.makeText(getBaseContext(),"in channel is null",Toast.LENGTH_SHORT).show();
            }
            if(outChannel == null)
            {
                Toast.makeText(getBaseContext(),"out channel is null",Toast.LENGTH_SHORT).show();
            }
            if(IMPORT_OR_EXPORT_FLAG == IMPORT_FLAG)
            {
                outChannel.transferTo(0, outChannel.size(), inChannel);
            }
            else
            {
                inChannel.transferTo(0, inChannel.size(), outChannel);
            }
        }
        catch(Exception e)
        {
            Toast.makeText(
                    getBaseContext(),
                    e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        finally
        {
            if (inChannel != null)
                inChannel.close();
            if (outChannel != null)
                outChannel.close();
        }

        return true;
    }

    private String FileExtension(String url)
    {
        if(url.indexOf("?") > -1)
        {
            url = url.substring(0,url.indexOf("?"));
        }
        if(url.lastIndexOf(".") == -1)
        {
            return("");
        }
        else
        {
            String extension = url.substring(url.lastIndexOf(".") + 1);
            if(extension.indexOf("%") > -1)
            {
                extension = extension.substring(0,extension.indexOf("%"));
            }
            if(extension.indexOf("/") > -1)
            {
                extension = extension.substring(0,extension.indexOf("/"));
            }
            return(extension);
        }
    }

    private Drawable CoolBigButton()
    {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(50);
        //gradientDrawable.setStroke(5, Color.RED);
        gradientDrawable.setColor(ContextCompat.getColor(getBaseContext(),R.color.my_blue_background));
        return(gradientDrawable);
    }
}